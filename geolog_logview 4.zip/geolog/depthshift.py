"""Fenêtre « Depth shift » (décalage en profondeur d'une ou plusieurs variables par rapport à une référence).

Colonnes, de gauche à droite :
    Original  |  (zone jaune : lignes de décalage)  |  Reference  |  Reference + shifted  |  Original / shifted

Utilisation :
    - maintenir  Shift  : une ligne rouge suit la souris sur tous les tracks ;
    - Shift + glisser (de haut en bas) : on crée un point de décalage. La ligne de gauche reste à la profondeur
      d'origine, la ligne de droite suit la souris (= nouvelle profondeur) ; les courbes décalées se mettent à jour ;
    - clic droit sur une ligne : supprimer ce point ;
    - à la fermeture : « Do you want to save the depth shift table before close the window ? ».
"""
import copy
import csv
import dataclasses

import numpy as np
from PySide6.QtCore import Qt, QRectF, QLineF, QPointF, Signal
from PySide6.QtGui import QPen, QColor, QBrush, QLinearGradient, QFont, QFontMetrics
from PySide6.QtWidgets import QMessageBox, QInputDialog, QMenu, QApplication, QFileDialog

import processing
from logview import LogCanvas, LogViewWidget, REF_W
from logview_model import Track

BLUE_C, ORANGE_C, RED_C = "#1a2fd0", "#e08a00", "#d91e18"


# --------------------------------------------------------------------- utilitaires
def clone(curve, **style):
    """Copie d'une courbe (mêmes données, style indépendant)."""
    n = copy.copy(curve)
    n.history = []
    n._aux = {}
    n.loader = None
    n.style = dataclasses.replace(curve.style)
    for k, v in style.items():
        setattr(n.style, k, v)
    return n


def curve_label(c):
    ds = getattr(c, "dataset", "")
    return f"{c.name}  ({ds})" if ds else str(c.name)


def pick_reference(parent, curves):
    """curves : au moins 2 CurveItem. Retourne (référence, [variables à décaler]) ou None si annulé."""
    labels = [curve_label(c) for c in curves]
    for i, lab in enumerate(labels):
        if labels.count(lab) > 1:
            labels[i] = f"{lab} #{i + 1}"
    item, ok = QInputDialog.getItem(parent, "Depth shift",
                                    "Reference variable (the other variables will be shifted):",
                                    labels, 0, False)
    if not ok:
        return None
    i = labels.index(item)
    return curves[i], [c for k, c in enumerate(curves) if k != i]


class GapTrack(Track):
    """Colonne jaune entre « Original » et « Reference » : on y voit les lignes de décalage."""
    gap = True

    def __init__(self, width=72):
        super().__init__("")
        self.width = width


# --------------------------------------------------------------------- canvas
class DepthShiftCanvas(LogCanvas):
    anchorsChanged = Signal()

    def __init__(self):
        super().__init__()
        self.anchors = []            # [(profondeur d'origine, nouvelle profondeur)], triés
        self.originals, self.shifted = [], []
        self.hover = None            # index du point survolé
        self._adrag = None           # point en cours de création / déplacement
        self.setAcceptDrops(False)

    # -- mise en place des colonnes
    def setup(self, ref, variables):
        orig_tr, ref_tr = Track("Original"), Track("Reference")
        cmp_tr, both_tr = Track("Reference + shifted"), Track("Original / shifted")
        self.originals, self.shifted = [], []
        cmp_tr.curves.append(clone(ref, color=BLUE_C, line_style="dash", fill_mode="none", thickness=1.3))
        ref_tr.curves.append(clone(ref, color=BLUE_C, line_style="dash", fill_mode="none", thickness=1.3))
        for v in variables:
            col = v.style.color
            if QColor(col) == QColor("#000000"):
                col = ORANGE_C
            o = clone(v, color=col, fill_mode="none", thickness=1.2, line_style="solid")
            g = clone(v, color="#9a9a9a", fill_mode="none", thickness=1.0, line_style="solid")
            s = clone(v, color="#000000", fill_mode="none", thickness=1.5, line_style="solid",
                      title=f"{v.display_name()}_sft")
            self.originals.append(o)
            self.shifted.append(s)
            orig_tr.curves.append(o)
            cmp_tr.curves.append(s)
            both_tr.curves.extend([g, s])
        for t in (orig_tr, ref_tr, cmp_tr, both_tr):
            t.width = 150
        self.tracks = [orig_tr, GapTrack(), ref_tr, cmp_tr, both_tr]
        self.selection, self.selected = [], None
        self.top = self.data_range()[0]
        self.recompute(self.anchors)
        self.view_changed()

    # -- points de décalage
    def live_anchors(self):
        a = [list(x) for x in self.anchors]
        d = self._adrag
        if d is not None:
            if d["k"] is None:
                a.append([d["src"], d["tgt"]])
            elif 0 <= d["k"] < len(a):
                a[d["k"]] = [d["src"], d["tgt"]]
        return processing.normalize_anchors(a)

    def recompute(self, anchors):
        for o, s in zip(self.originals, self.shifted):
            s.depth = processing.shift_depth(o.depth, anchors)
        self.update()

    def set_anchors(self, anchors):
        self.anchors = processing.normalize_anchors(anchors)
        self.hover = None
        self.recompute(self.anchors)
        self.anchorsChanged.emit()

    def remove_anchor(self, k):
        a = list(self.anchors)
        if 0 <= k < len(a):
            del a[k]
            self.set_anchors(a)

    def _anchor_near(self, y, tol=5.0):
        best, bd = None, tol
        for k, (s, t) in enumerate(self.anchors):
            for d in (s, t):
                dist = abs(self.y_of(d) - y)
                if dist < bd:
                    best, bd = k, dist
        return best

    def _cursor_for(self, active):
        if active:
            self.setCursor(Qt.SizeVerCursor)
        else:
            self.setCursor({"zoom": Qt.CrossCursor, "hand": Qt.OpenHandCursor}.get(self.mode, Qt.ArrowCursor))

    # -- drag & drop désactivé
    def dragEnterEvent(self, e):
        e.ignore()

    dragMoveEvent = dragEnterEvent
    dropEvent = dragEnterEvent

    # -- souris / clavier
    def enterEvent(self, e):
        self.setFocus()
        super().enterEvent(e)

    def mousePressEvent(self, e):
        self.setFocus()
        pos = e.position()
        if e.button() == Qt.LeftButton and pos.x() > REF_W and pos.y() > self.header_h():
            k = self._anchor_near(pos.y())
            shift = bool(e.modifiers() & Qt.ShiftModifier)
            if k is not None or shift:
                m0 = self.depth_at_y(pos.y())
                if k is None:
                    self._adrag = dict(k=None, src=m0, t0=m0, m0=m0, tgt=m0)
                else:
                    s, t = self.anchors[k]
                    self._adrag = dict(k=k, src=s, t0=t, m0=m0, tgt=t)
                self.mouse = pos
                self.update()
                return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        a = self._adrag
        if a is not None:
            self.mouse = e.position()
            m = self.depth_at_y(e.position().y())
            a["tgt"] = a["t0"] + (m - a["m0"])
            self.recompute(self.live_anchors())
            return
        super().mouseMoveEvent(e)
        y = e.position().y()
        shift = bool(e.modifiers() & Qt.ShiftModifier)
        hov = self._anchor_near(y) if y > self.header_h() else None
        if shift or hov != self.hover:
            self.hover = hov
            self.update()
        self._cursor_for(shift or hov is not None)

    def mouseReleaseEvent(self, e):
        a = self._adrag
        if a is not None and e.button() == Qt.LeftButton:
            new = self.live_anchors()
            self._adrag = None
            self.set_anchors(new)
            return
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Shift:
            self._cursor_for(True)
            self.update()
        elif e.key() == Qt.Key_Escape and self._adrag is not None:
            self._adrag = None
            self.recompute(self.live_anchors())
        elif e.key() == Qt.Key_Delete or (e.key() == Qt.Key_A and e.modifiers() & Qt.ControlModifier):
            e.ignore()                      # pas de suppression / sélection globale de courbes ici
        else:
            super().keyPressEvent(e)

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key_Shift:
            self._cursor_for(self.hover is not None)
            self.update()
        else:
            super().keyReleaseEvent(e)

    def contextMenuEvent(self, e):
        y = e.pos().y()
        k = self._anchor_near(y) if y > self.header_h() else None
        if k is None:
            return
        s, t = self.anchors[k]
        m = QMenu(self)
        m.addAction(f"Delete this depth shift point  ({s:.2f}  ->  {t:.2f})", lambda: self.remove_anchor(k))
        m.exec(e.globalPos())

    # -- dessin
    def _paint_track(self, p, idx, t, r, hdr, H):
        if not getattr(t, "gap", False):
            super()._paint_track(p, idx, t, r, hdr, H)
            return
        p.save()
        left = max(r.left(), REF_W)
        p.setClipRect(QRectF(left, 0, r.right() - left + 1, H))
        g = QLinearGradient(0, hdr, 0, H)
        g.setColorAt(0.0, QColor("#ffe7a0")); g.setColorAt(1.0, QColor("#fff5d2"))
        p.fillRect(QRectF(r.left(), hdr, r.width(), H - hdr), QBrush(g))
        p.fillRect(QRectF(r.left(), 0, r.width(), hdr), QColor("#fff0c0"))
        p.setPen(QPen(QColor("#333"), 1)); p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(r.left(), 0, r.width(), hdr))
        p.drawRect(QRectF(r.left(), hdr, r.width(), H - hdr))
        p.restore()

    def _tip(self, p, lines):
        m = self.mouse
        f = QFont("Arial", 8)
        p.setFont(f)
        fm = QFontMetrics(f)
        w = max(fm.horizontalAdvance(t) for t in lines) + 12
        h = len(lines) * (fm.height() + 1) + 8
        x = min(m.x() + 16, self.width() - w - 2)
        y = min(m.y() + 16, self.height() - h - 2)
        p.setPen(QPen(QColor("#555"), 1)); p.setBrush(QColor(255, 255, 225, 240))
        p.drawRect(QRectF(x, y, w, h))
        p.setPen(QColor("#111"))
        for k, txt in enumerate(lines):
            p.drawText(QPointF(x + 6, y + 6 + fm.ascent() + k * (fm.height() + 1)), txt)

    def _paint_overlay(self, p, hdr, H):
        rects = self.track_rects()
        W = self.width()
        # ---- lignes de décalage : horizontale à gauche, oblique dans la zone jaune, horizontale à droite
        p.save()
        p.setClipRect(QRectF(REF_W, hdr, max(0.0, W - REF_W), max(0.0, H - hdr)))
        if len(rects) >= 5:
            p.setPen(QPen(QColor(RED_C), 1.7))
            for s, t in self.live_anchors():
                y0, y1 = self.y_of(s), self.y_of(t)
                p.drawLine(QLineF(rects[0].left(), y0, rects[0].right(), y0))
                p.drawLine(QLineF(rects[1].left(), y0, rects[1].right(), y1))
                p.drawLine(QLineF(rects[2].left(), y1, rects[4].right(), y1))
        # ---- Shift maintenu : ligne rouge à la profondeur de la souris
        m = self.mouse
        shift = bool(QApplication.keyboardModifiers() & Qt.ShiftModifier)
        show_line = shift and m is not None and m.y() > hdr and self._adrag is None
        if show_line:
            p.setPen(QPen(QColor(RED_C), 1.4))
            p.drawLine(QLineF(REF_W, m.y(), W, m.y()))
        p.restore()
        if show_line:
            p.setPen(QPen(QColor(RED_C), 1)); p.setBrush(QColor("#fffbd0"))
            p.drawRect(QRectF(2, m.y() - 9, REF_W - 6, 18))
            f = QFont("Arial", 8); f.setBold(True); p.setFont(f); p.setPen(QColor("#a00"))
            p.drawText(QRectF(2, m.y() - 9, REF_W - 6, 18), Qt.AlignCenter, f"{self.depth_at_y(m.y()):.2f}")
        # ---- info-bulle : Depth / Relative shift / Absolute shift
        tip = None
        if self._adrag is not None:
            tip = (self._adrag["src"], self._adrag["tgt"])
        elif self.hover is not None and self.hover < len(self.anchors) and m is not None and m.y() > hdr:
            tip = self.anchors[self.hover]
        if tip is not None and m is not None:
            s, t = tip
            self._tip(p, [f"Depth: {s:.2f}", f"Relative shift: {t - s:.2f}", f"Absolute shift: {abs(t - s):.2f}"])
        super()._paint_overlay(p, hdr, H)         # Values / Position lines du ruban


# --------------------------------------------------------------------- widget
class DepthShiftWidget(LogViewWidget):
    def __init__(self, main, ref, variables):
        super().__init__(None, DepthShiftCanvas, "depth")
        self.main = main
        self.ref = ref
        self.vars = list(variables)
        self.table_name = ""
        self.saved = []                       # points au dernier enregistrement
        self.canvas.ref_unit = main.depth_unit_label(ref.key).upper()
        self.canvas.anchorsChanged.connect(self.sync_bars)
        self.canvas.setup(ref, self.vars)
        self.sync_bars()

    def title(self):
        return f"Depth shift [{self.ref.name}]"

    @property
    def modified(self):
        return [tuple(a) for a in self.canvas.anchors] != [tuple(a) for a in self.saved]

    # -- actions du ruban
    def go_to_reference(self):
        c = self.canvas
        c.top = float(self.ref.depth[0])
        c.hscroll = 0
        c.view_changed()

    def remove_all(self):
        self.canvas.set_anchors([])

    def set_values(self, on):
        self.act_values.setChecked(on)
        self._toggle("show_values", self.act_values)

    def set_poslines(self, on):
        self.act_poslines.setChecked(on)
        self._toggle("show_poslines", self.act_poslines)

    def choose_reference(self):
        allc = [self.ref] + self.vars
        got = pick_reference(self, allc)
        if got:
            self.ref, self.vars = got
            self.canvas.setup(self.ref, self.vars)
            self.sync_bars()

    def auto_define(self):
        if not self.vars:
            return
        v = self.vars[0]
        mx, ok = QInputDialog.getDouble(self, "Automatic definition of the depth shift",
                                        f"Maximum shift (+/-, in {self.main.depth_unit_label(v.key)}) "
                                        f"for {v.name}:", 10.0, 0.1, 1000.0, 2)
        if not ok:
            return
        s, c = processing.auto_shift(self.ref.depth, self.ref.values, v.depth, v.values, mx)
        d0, d1 = float(v.depth[0]), float(v.depth[-1])
        self.canvas.set_anchors([(d0, d0 + s), (d1, d1 + s)])
        self.main.statusBar().showMessage(f"Automatic depth shift: {s:+.2f} (correlation {c:.2f})", 6000)

    # -- table de décalage
    def table_data(self):
        return {"reference": f"{self.ref.dataset}.{self.ref.name}",
                "variables": [f"{v.dataset}.{v.name}" for v in self.vars],
                "anchors": [[float(s), float(t)] for s, t in self.canvas.anchors]}

    def save_table(self):
        """Enregistre la table dans le projet. Retourne False si annulé."""
        proj = self.main.project
        if proj is None:
            return False
        if not self.canvas.anchors:
            QMessageBox.information(self, "Depth shift", "The depth shift table is empty.")
            return False
        name, ok = QInputDialog.getText(self, "Depth shift table", "Table name:",
                                        text=self.table_name or f"DepthShift_{len(proj.depth_shifts) + 1}")
        name = name.strip()
        if not ok or not name:
            return False
        proj.depth_shifts[name] = self.table_data()
        self.table_name = name
        self.saved = list(self.canvas.anchors)
        self.main.set_dirty()
        self.main.statusBar().showMessage(f"Depth shift table '{name}' saved in the project", 4000)
        return True

    def load_table(self):
        proj = self.main.project
        names = list(proj.depth_shifts) if proj else []
        file_item = "(from a CSV file...)"
        item, ok = QInputDialog.getItem(self, "Load an existing depth shift", "Depth shift table:",
                                        names + [file_item], 0, False)
        if not ok:
            return
        if item == file_item:
            path, _ = QFileDialog.getOpenFileName(self, "Depth shift table", "", "CSV (*.csv *.txt)")
            if not path:
                return
            pts = []
            try:
                with open(path, newline="") as f:
                    for row in csv.reader(f, delimiter=";" if ";" in open(path).read(2000) else ","):
                        try:
                            pts.append((float(row[0]), float(row[1])))
                        except (ValueError, IndexError):
                            continue          # ligne d'en-tête
            except OSError as e:
                QMessageBox.warning(self, "Depth shift", f"Cannot read the file:\n{e}")
                return
            if not pts:
                QMessageBox.warning(self, "Depth shift", "No (depth, new depth) pair found in the file.")
                return
            self.canvas.set_anchors(pts)
        else:
            self.canvas.set_anchors(proj.depth_shifts[item]["anchors"])
            self.table_name = item
            self.saved = list(self.canvas.anchors)

    def save_modified(self):
        """« Modified variables » : crée <variable>_sft dans le dataset d'origine."""
        anchors = list(self.canvas.anchors)
        if not anchors:
            QMessageBox.information(self, "Depth shift",
                                    "Define at least one depth shift point first\n(hold Shift and drag in the log).")
            return
        made = []
        for v in self.vars:
            df = self.main.wells.get(v.key)
            if df is None or v.name not in df.columns:
                continue
            vals = processing.on_valid_depth(
                df.index.values, df[v.name].values,
                lambda d, x, a=anchors: processing.resample_shifted(d, x, processing.shift_depth(d, a), d))
            made.append(self.main.add_derived(v.key, f"{v.name}_sft", vals, v.name,
                                              f"Depth shift ({len(anchors)} point(s)) of {v.name}"))
        if made:
            QMessageBox.information(self, "Depth shift", "Saved in the project:\n" + "\n".join(made))

    # -- fermeture de la fenêtre
    def closeEvent(self, e):
        if self.canvas.anchors and self.modified:
            box = QMessageBox(QMessageBox.Question, "Close",
                              "Do you want to save the depth shift table\nbefore close the window?",
                              QMessageBox.NoButton, self)
            yes = box.addButton("Yes", QMessageBox.YesRole)
            box.addButton("No", QMessageBox.NoRole)
            cancel = box.addButton("Cancel", QMessageBox.RejectRole)
            box.setDefaultButton(yes)
            box.exec()
            clicked = box.clickedButton()
            if clicked is None or clicked is cancel or (clicked is yes and not self.save_table()):
                e.ignore()
                return
        e.accept()
