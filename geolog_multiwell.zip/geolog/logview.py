"""Fenêtre LogView : tracks, référence de profondeur, en-têtes, courbes, remplissage."""
import json
import math

import numpy as np
from PySide6.QtCore import Qt, QRectF, QPointF, QLineF, Signal, QSize
from PySide6.QtGui import (QPainter, QPen, QColor, QPolygonF, QPainterPath, QFont, QFontMetrics, QBrush,
                           QAction, QActionGroup)
from PySide6.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QGridLayout, QScrollBar, QToolBar,
                               QMenu, QMessageBox, QSizePolicy)

import logview_icons as ic
from logview_model import Track, CurveItem, WellSettings, default_grids

MIME_PREFIX = "geolog-curves:"
REF_W, TITLE_H, WELL_H, BLOCK_H = 78, 22, 18, 54
PX_PER_M_AT_1 = 96 / 0.0254                      # 96 dpi : 1 m papier = 3779 px
PEN_STYLES = {"solid": Qt.SolidLine, "dash": Qt.DashLine, "dot": Qt.DotLine,
              "dash dot": Qt.DashDotLine, "dash dot dot": Qt.DashDotDotLine}
SEL_RED = "#e5231b"


def fmt(v):
    return f"{v:.4g}"


def _seg_dist(p, a, b):
    ax, ay, bx, by, px, py = a.x(), a.y(), b.x(), b.y(), p.x(), p.y()
    dx, dy = bx - ax, by - ay
    L = dx * dx + dy * dy
    t = 0 if L == 0 else max(0, min(1, ((px - ax) * dx + (py - ay) * dy) / L))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


class LogCanvas(QWidget):
    selectionChanged = Signal(object)       # CurveItem | "reference" | None
    viewChanged = Signal()
    styleChanged = Signal()
    curvesDropped = Signal(list, int)
    contentChanged = Signal()
    intervalChanged = Signal(object)

    def __init__(self):
        super().__init__()
        self.tracks = []
        self.scale = 200.0
        self.top = 0.0
        self.hscroll = 0
        self.selected = None
        self.ref_selected = False
        self.mode = "select"
        self.show_values = False
        self.show_poslines = False
        self.auto_h = False
        self.mouse = None
        self._drag = None
        self._blocks = []
        self.ref_unit = "M"
        self.grids = default_grids("M")      # grilles par défaut du layout
        self.wells = {}                       # nom du puits -> WellSettings
        self.show_layout_header = True
        self.show_well_header = True
        self.sel_interval = None              # (profondeur haute, basse) de la sélection interactive
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setMinimumSize(300, 300)

    # ------------------------------------------------------------ géométrie
    def unit_factor(self):
        return 0.3048 if str(self.ref_unit).lower().startswith("f") else 1.0

    def ppm(self):
        """Pixels par unité de profondeur (échelle 1:N en mètres papier ; ft converti)."""
        return PX_PER_M_AT_1 / self.scale * self.unit_factor()

    def header_h(self):
        n = max([1] + [len(t.curves) for t in self.tracks])
        return ((TITLE_H if self.show_layout_header else 0) + (WELL_H if self.show_well_header else 0)
                + n * BLOCK_H)

    # ---- puits / limitation de référence
    def track_well(self, t):
        for c in t.curves:
            if c.well:
                return c.well
        return ""

    def well_names(self):
        out = []
        for t in self.tracks:
            w = self.track_well(t)
            if w not in out:
                out.append(w)
        return out

    def well_settings(self, name):
        ws = self.wells.get(name)
        if ws is None:
            ws = self.wells[name] = WellSettings(self.grids)
        return ws

    def well_real(self, name):
        """Limites 'Real' : profondeur min / max des données du puits."""
        lo = hi = None
        for t in self.tracks:
            if self.track_well(t) != name:
                continue
            for c in t.curves:
                lo = c.depth[0] if lo is None else min(lo, c.depth[0])
                hi = c.depth[-1] if hi is None else max(hi, c.depth[-1])
        return (float(lo), float(hi)) if lo is not None else (0.0, 0.0)

    def track_extent(self, t):
        name = self.track_well(t)
        ws = self.well_settings(name)
        return (ws.top, ws.bottom) if ws.ref_limit else self.well_real(name)

    def plot_h(self):
        return max(1, self.height() - self.header_h())

    def visible_span(self):
        return self.plot_h() / self.ppm()

    def y_of(self, d):
        return self.header_h() + (d - self.top) * self.ppm()

    def depth_at_y(self, y):
        return self.top + (y - self.header_h()) / self.ppm()

    def track_rects(self):
        out, x = [], REF_W - self.hscroll
        for t in self.tracks:
            out.append(QRectF(x, 0, t.width, self.height()))
            x += t.width
        return out

    def content_width(self):
        return REF_W + sum(t.width for t in self.tracks)

    def all_curves(self):
        return [c for t in self.tracks for c in t.curves]

    def data_range(self):
        cs = self.all_curves()
        if not cs:
            return 0.0, 100.0
        return min(c.depth[0] for c in cs), max(c.depth[-1] for c in cs)

    def clamp_view(self):
        dmin, dmax = self.data_range()
        vis = self.visible_span()
        self.top = max(dmin - vis * 0.1, min(self.top, max(dmin, dmax - vis * 0.9)))
        maxh = max(0, self.content_width() - self.width())
        self.hscroll = max(0, min(self.hscroll, maxh))

    def view_changed(self):
        self.clamp_view()
        if self.auto_h:
            self.adjust_horizontal(self.all_curves(), emit=False)
        self.viewChanged.emit()
        self.update()

    # --------------------------------------------------------- contenu
    def add_curve(self, curve, track_index=None):
        first = not self.all_curves()
        if first:
            self.ref_unit = getattr(curve, "depth_unit", "M")
            self.grids = default_grids(self.ref_unit)
            self.wells = {}
        if track_index is None or not (0 <= track_index < len(self.tracks)):
            self.tracks.append(Track())
            track_index = len(self.tracks) - 1
        self.tracks[track_index].curves.append(curve)
        self.well_settings(self.track_well(self.tracks[track_index]))
        if first:
            self.top = self.data_range()[0]
        self.view_changed()
        self.contentChanged.emit()

    def remove_curve(self, curve):
        for t in self.tracks:
            if curve in t.curves:
                t.curves.remove(curve)
        self.tracks = [t for t in self.tracks if t.curves]
        if self.selected is curve:
            self.select(None)
        self.view_changed()
        self.contentChanged.emit()

    def remove_track_of(self, curve):
        for t in list(self.tracks):
            if curve in t.curves:
                self.tracks.remove(t)
        if self.selected is curve:
            self.select(None)
        self.view_changed()
        self.contentChanged.emit()

    def select(self, obj):
        self.selected = obj if isinstance(obj, CurveItem) else None
        self.ref_selected = obj == "reference"
        self.selectionChanged.emit(self.selected if self.selected else (obj if obj == "reference" else None))
        self.update()

    # ---------------------------------------------------- ajustements
    def set_scale(self, new_scale, anchor_y=None):
        anchor_y = self.header_h() if anchor_y is None else anchor_y
        d = self.depth_at_y(anchor_y)
        self.scale = max(1.0, min(new_scale, 200000.0))
        self.top = d - (anchor_y - self.header_h()) / self.ppm()
        self.view_changed()

    def vertical_adjust(self):
        dmin, dmax = self.data_range()
        self.scale = max(1.0, PX_PER_M_AT_1 * self.unit_factor() * (dmax - dmin) / self.plot_h())
        self.top = dmin
        self.view_changed()

    def adjust_horizontal(self, curves, emit=True):
        d0, d1 = self.depth_at_y(self.header_h()), self.depth_at_y(self.height())
        for c in curves:
            i0, i1 = np.searchsorted(c.depth, [d0, d1])
            v = c.values[max(0, i0 - 1):i1 + 1]
            v = v[np.isfinite(v)]
            if v.size:
                c.style.axis_type = "user"
                c.style.user_lo, c.style.user_hi = float(v.min()), float(v.max())
        if emit:
            self.styleChanged.emit()
            self.update()

    def reset_scale(self):
        self.scale = 200.0
        self.hscroll = 0
        self.view_changed()

    # --------------------------------------------------------- mapping
    def x_of(self, c, vals, rect):
        s = c.style
        lo, hi = c.effective_limits()
        vals = np.asarray(vals, float)
        with np.errstate(all="ignore"):
            if s.scale == "log" and lo > 0 and hi > 0:
                v = np.log10(np.where(vals > 0, vals, np.nan))
                a, b = math.log10(lo), math.log10(hi)
            else:
                v, a, b = vals, lo, hi
            f = (v - a) / (b - a)
        if s.inverted:
            f = 1 - f
        ps, pe = s.part_start / 100.0, s.part_end / 100.0
        f = np.clip(ps + f * (pe - ps), -2, 3)
        return rect.left() + f * rect.width()

    # ------------------------------------------------------------ dessin
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#ffffff"))
        self._blocks = []
        hdr, H = self.header_h(), self.height()
        for i, (t, r) in enumerate(zip(self.tracks, self.track_rects())):
            if r.right() < REF_W or r.left() > self.width():
                continue
            self._paint_track(p, i, t, r, hdr, H)
        self._paint_reference(p, hdr, H)
        self._paint_overlay(p, hdr, H)
        if self._drag and self._drag[0] == "zoom":
            y0, y1 = self._drag[1], self._drag[2]
            p.setPen(QPen(QColor("#1b7fd0"), 1, Qt.DashLine)); p.setBrush(QColor(27, 127, 208, 40))
            p.drawRect(QRectF(REF_W, min(y0, y1), self.width() - REF_W, abs(y1 - y0)))
        p.end()

    def _paint_track(self, p, idx, t, r, hdr, H):
        d_top, d_bot = self.track_extent(t)
        ws = self.well_settings(self.track_well(t))
        y0, y1 = max(hdr, self.y_of(d_top)), min(H, self.y_of(d_bot))
        left = max(r.left(), REF_W)
        p.save()
        p.setClipRect(QRectF(left, 0, r.right() - left + 1, H))
        if y1 > y0:
            data = QRectF(r.left(), y0, r.width(), y1 - y0)
            p.fillRect(data, QColor("#ffffff"))
            n = max(1, t.grid_lines)
            p.setPen(QPen(QColor("#d4d4d4"), 1))
            for k in range(n + 1):
                x = data.left() + data.width() * k / n
                p.drawLine(QLineF(x, y0, x, y1))
            ppm = self.ppm()
            a, b = max(self.depth_at_y(hdr), d_top), min(self.depth_at_y(H), d_bot)
            for g in reversed(ws.grids):                 # tertiaire -> secondaire -> principale
                if not g.visible or g.spacing <= 0 or g.spacing * ppm < 4:
                    continue
                p.setPen(QPen(QColor(g.color), g.thickness))
                for k in range(math.ceil(a / g.spacing - 1e-9), math.floor(b / g.spacing + 1e-9) + 1):
                    y = self.y_of(k * g.spacing)
                    p.drawLine(QLineF(data.left(), y, data.right(), y))
            p.setClipRect(data.intersected(QRectF(REF_W, 0, self.width() - REF_W, H)))
            for c in t.curves:
                self._paint_curve(p, c, data, hdr, H)
            if self.sel_interval:                        # sélection interactive : zone bleue pointillée
                ya, yb = self.y_of(self.sel_interval[0]), self.y_of(self.sel_interval[1])
                rr = QRectF(data.left(), max(ya, y0), data.width(), min(yb, y1) - max(ya, y0))
                if rr.height() > 0:
                    p.fillRect(rr, QColor(110, 185, 235, 80))
                    p.fillRect(rr, QBrush(QColor(40, 120, 200, 150), Qt.Dense6Pattern))
        p.restore()
        if y1 > y0:
            p.setPen(QPen(QColor("#333"), 1)); p.setBrush(Qt.NoBrush)
            p.drawRect(QRectF(r.left(), y0, r.width(), y1 - y0))
        p.save()
        p.setClipRect(QRectF(REF_W, 0, self.width() - REF_W, hdr + 1))
        self._paint_track_header(p, idx, t, r, hdr)
        p.restore()

    def _paint_track_header(self, p, idx, t, r, hdr):
        x, w, y = r.left(), r.width(), 0
        f = QFont("Arial", 9); f.setBold(True); p.setFont(f)
        p.setPen(QPen(QColor("#333"), 1))
        if self.show_layout_header:
            p.setBrush(QColor("#e6ee2a")); p.drawRect(QRectF(x, y, w, TITLE_H))
            p.drawText(QRectF(x, y, w, TITLE_H), Qt.AlignCenter, t.title or f"Track {idx + 1}")
            y += TITLE_H
        if self.show_well_header:
            wells = []
            for c in t.curves:
                if c.well and c.well not in wells:
                    wells.append(c.well)
            p.setBrush(QColor("#7ac943")); p.drawRect(QRectF(x, y, w, WELL_H))
            f.setBold(False); f.setPointSize(8); p.setFont(f)
            p.drawText(QRectF(x, y, w, WELL_H), Qt.AlignCenter, ", ".join(wells))
            y += WELL_H
        for c in t.curves:
            self._paint_block(p, c, QRectF(x, y, w, BLOCK_H))
            y += BLOCK_H
        if y < hdr:
            p.setBrush(QColor("#fafafa")); p.setPen(QPen(QColor("#999"), 1))
            p.drawRect(QRectF(x, y, w, hdr - y))

    def line_pen(self, c, selected=None, width_extra=0.0):
        s = c.style
        sel = (self.selected is c) if selected is None else selected
        col = QColor(s.color)
        if sel and col == QColor("#000000"):
            col = QColor(SEL_RED)
        pen = QPen(col, max(0.5, s.thickness + (0.4 if sel else 0) + width_extra),
                   PEN_STYLES.get(s.line_style, Qt.SolidLine))
        if sel:
            pen.setStyle(Qt.DashLine)
        return pen

    def _paint_block(self, p, c, r):
        s = c.style
        sel = self.selected is c
        pen = self.line_pen(c)
        col = pen.color()
        self._blocks.append((QRectF(r), c))
        p.setPen(QPen(QColor("#555"), 1)); p.setBrush(QColor("#ffffff")); p.drawRect(r)
        x, w, y = r.left(), r.width(), r.top()
        # palette de remplissage
        f = QFont("Arial", 7); p.setFont(f)
        if s.fill_mode != "none":
            bar = QRectF(x + 3, y + 3, w - 6, 13)
            if s.fill_mode == "baseline":
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(s.fill_a)); p.drawRect(QRectF(bar.left(), bar.top(), bar.width() / 2, bar.height()))
                p.setBrush(QColor(s.fill_b)); p.drawRect(QRectF(bar.center().x(), bar.top(), bar.width() / 2, bar.height()))
                txt = f"{c.display_name()}/Baseline"
            else:
                p.setPen(Qt.NoPen); p.setBrush(QColor(s.fill_a)); p.drawRect(bar)
                txt = c.display_name()
            p.setPen(QColor("#222")); p.drawText(bar, Qt.AlignCenter, txt)
        # nom
        f = QFont("Arial", 9); f.setBold(True); f.setItalic(c.modified); p.setFont(f); p.setPen(col)
        p.drawText(QRectF(x, y + 17, w, 15), Qt.AlignCenter, c.display_name() + (" *" if sel else ""))
        # échantillon de ligne
        p.setPen(pen); yy = y + 35
        p.drawLine(QLineF(x + 3, yy, x + w - 3, yy))
        # limites / unité
        lo, hi = c.effective_limits()
        f = QFont("Arial", 8); p.setFont(f); p.setPen(col)
        p.drawText(QRectF(x + 3, y + 37, w * 0.3, 15), Qt.AlignLeft | Qt.AlignVCenter, fmt(lo))
        p.drawText(QRectF(x, y + 37, w, 15), Qt.AlignCenter, c.style.unit)
        p.drawText(QRectF(x + w * 0.7 - 3, y + 37, w * 0.3, 15), Qt.AlignRight | Qt.AlignVCenter, fmt(hi))

    # ---- une courbe
    def _paint_curve(self, p, c, rect, hdr, H):
        s = c.style
        ppm = self.ppm()
        d0, d1 = self.depth_at_y(hdr), self.depth_at_y(H)
        if s.ref_limit:
            d0, d1 = max(d0, s.ref_top), min(d1, s.ref_bottom)
            if d1 <= d0:
                return
        i0 = max(0, int(np.searchsorted(c.depth, d0, "left")) - 1)
        i1 = min(len(c.depth), int(np.searchsorted(c.depth, d1, "right")) + 1)
        if i1 - i0 < 2:
            return
        sl = slice(i0, i1)
        dep, val = c.depth[sl], c.values[sl]
        n = i1 - i0
        stride = 1
        if (s.decimation and n > H) or (s.optimized and n > 20000):
            stride = max(1, n // max(1, int(H * 2)))
        dep, val = dep[::stride], val[::stride]
        xs = self.x_of(c, val, rect)
        ys = hdr + (dep - self.top) * ppm
        ok = np.isfinite(xs) & np.isfinite(ys)
        if ok.sum() < 1:
            return
        idx = np.flatnonzero(ok)
        groups = np.split(idx, np.flatnonzero(np.diff(idx) > 1) + 1)
        if s.vthr_on:
            groups = [g2 for g in groups for g2 in np.split(g, np.flatnonzero(np.diff(dep[g]) > s.vthr) + 1)]
        # ---- remplissage
        if s.fill_mode != "none":
            self._paint_fill(p, c, rect, xs, ys, groups, hdr, H)
        # ---- ligne
        if s.show_line and not s.only_fill:
            p.setOpacity(s.opacity / 100.0)
            pen = self.line_pen(c)
            by_var = s.color_mode == "variable" and s.color_var and s.line_coloration and c.aux(s.color_var) is not None
            if by_var:
                cols = self._var_colors(c, sl, stride, s.color_var)
                sel = self.selected is c
                for g in groups:
                    for a, b in zip(g[:-1], g[1:]):
                        pp = QPen(pen); pp.setColor(cols[a]); p.setPen(pp)
                        p.drawLine(QLineF(xs[a], ys[a], xs[b], ys[b]))
            else:
                p.setPen(pen); p.setBrush(Qt.NoBrush)
                for g in groups:
                    if len(g) >= 2:
                        p.drawPolyline(QPolygonF([QPointF(xs[i], ys[i]) for i in g]))
            p.setOpacity(1.0)
        # ---- points
        if s.show_points:
            self._paint_points(p, c, sl, stride, xs, ys, ok)

    def _var_colors(self, c, sl, stride, name):
        a = c.aux(name)[sl][::stride]
        fin = a[np.isfinite(a)]
        lo, hi = (np.percentile(fin, 2), np.percentile(fin, 98)) if fin.size else (0, 1)
        t = np.clip((a - lo) / ((hi - lo) or 1.0), 0, 1)
        return [QColor.fromHsvF(float((1 - (0 if np.isnan(v) else v)) * 0.66), 0.9, 0.9) for v in t]

    def _paint_fill(self, p, c, rect, xs, ys, groups, hdr, H):
        s = c.style
        lo, hi = c.effective_limits()
        base_x = float(self.x_of(c, [s.base_value], rect)[0]) if s.fill_mode == "baseline" else 0
        lower_left = (hi > lo) != s.inverted
        p.setPen(Qt.NoPen)
        p.setOpacity(s.fill_opacity / 100.0)
        for g in groups:
            if len(g) < 2:
                continue
            if s.fill_mode == "baseline":
                edge = base_x
            else:
                edge = rect.left() if s.fill_mode == "left" else rect.right()
            path = QPainterPath(QPointF(edge, ys[g[0]]))
            for i in g:
                path.lineTo(xs[i], ys[i])
            path.lineTo(edge, ys[g[-1]]); path.closeSubpath()
            if s.fill_mode == "baseline":
                left_part = QRectF(rect.left() - 5000, hdr, base_x - rect.left() + 5000, H - hdr)
                right_part = QRectF(base_x, hdr, rect.right() - base_x + 5000, H - hdr)
                a_part, b_part = (left_part, right_part) if lower_left else (right_part, left_part)
                for part, colr in ((a_part, s.fill_a), (b_part, s.fill_b)):
                    p.save(); p.setClipRect(part, Qt.IntersectClip)
                    p.setBrush(QColor(colr)); p.drawPath(path); p.restore()
            else:
                p.setBrush(QColor(s.fill_a)); p.drawPath(path)
        p.setOpacity(1.0)

    def _paint_points(self, p, c, sl, stride, xs, ys, ok):
        s = c.style
        r = max(1.0, s.point_size / 2.0)
        cols = None
        if s.point_var_on and s.point_var and c.aux(s.point_var) is not None:
            cols = self._var_colors(c, sl, stride, s.point_var)
        base = QColor(s.color)
        if base == QColor("#000000") and self.selected is c:
            base = QColor(SEL_RED)
        for i in np.flatnonzero(ok):
            col = cols[i] if cols else base
            p.setPen(QPen(col, 1.4)); p.setBrush(col)
            x, y = float(xs[i]), float(ys[i])
            t = s.point_type
            if t == "circle":
                p.drawEllipse(QPointF(x, y), r, r)
            elif t == "square":
                p.drawRect(QRectF(x - r, y - r, 2 * r, 2 * r))
            elif t == "triangle":
                p.drawPolygon(QPolygonF([QPointF(x, y - r), QPointF(x - r, y + r), QPointF(x + r, y + r)]))
            elif t == "cross":
                p.drawLine(QLineF(x - r, y - r, x + r, y + r)); p.drawLine(QLineF(x - r, y + r, x + r, y - r))
            else:
                p.drawLine(QLineF(x - r, y, x + r, y)); p.drawLine(QLineF(x, y - r, x, y + r))

    # ---- colonne de référence
    def _paint_reference(self, p, hdr, H):
        ppm = self.ppm()
        p.fillRect(QRectF(0, 0, REF_W, H), QColor("#ffffff"))
        if self.tracks:
            ext = [self.track_extent(t) for t in self.tracks]
            a, b = min(e[0] for e in ext), max(e[1] for e in ext)
        else:
            a, b = self.depth_at_y(hdr), self.depth_at_y(H)
        y0, y1 = max(hdr, self.y_of(a)), min(H, self.y_of(b))
        bg = QColor("#f9cccc") if self.ref_selected else QColor("#e8f5fb")
        if y1 > y0:
            p.fillRect(QRectF(0, y0, REF_W, y1 - y0), bg)
        # en-tête : Reference / (unité) / échelle
        p.setPen(QPen(QColor("#333"), 1)); p.setBrush(QColor("#ffffff"))
        p.drawRect(QRectF(0, 0, REF_W, hdr))
        yb = max(0, hdr - 66)
        f = QFont("Arial", 9); f.setBold(True); p.setFont(f); p.setPen(QColor("#111"))
        p.drawText(QRectF(0, yb, REF_W, 18), Qt.AlignCenter, "Reference")
        f.setBold(False); f.setPointSize(8); p.setFont(f)
        p.drawText(QRectF(0, yb + 15, REF_W, 15), Qt.AlignCenter, f"({self.ref_unit})")
        f.setBold(True); f.setPointSize(11); p.setFont(f)
        p.drawText(QRectF(0, yb + 30, REF_W, 22), Qt.AlignCenter, f"1:{self.scale:g}")
        if y1 <= y0:
            return
        p.setPen(QPen(QColor("#333"), 1)); p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(0, y0, REF_W, y1 - y0))
        p.save(); p.setClipRect(QRectF(0, y0, REF_W, y1 - y0))
        va, vb = max(self.depth_at_y(hdr), a), min(self.depth_at_y(H), b)
        lens = (3, 6, 10)
        for lvl in (2, 1, 0):                              # tertiaire, secondaire, principale
            g = self.grids[lvl]
            if not g.visible or g.spacing <= 0 or g.spacing * ppm < 4:
                continue
            p.setPen(QPen(QColor("#555" if lvl else "#111"), 1))
            for k in range(math.ceil(va / g.spacing - 1e-9), math.floor(vb / g.spacing + 1e-9) + 1):
                y = self.y_of(k * g.spacing)
                p.drawLine(QLineF(REF_W - lens[lvl] - (2 if lvl == 0 else 0), y, REF_W, y))
        # étiquettes : multiples de la grille principale, espacées d'au moins 42 px
        main = self.grids[0].spacing if self.grids[0].spacing > 0 else 1.0
        mult = 1
        for m in (1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000):
            mult = m
            if main * m * ppm >= 42:
                break
        step = main * mult
        f = QFont("Arial", 10); f.setBold(True); p.setFont(f); p.setPen(QColor("#111"))
        for k in range(math.ceil(va / step - 1e-9), math.floor(vb / step + 1e-9) + 1):
            y = self.y_of(k * step)
            p.drawLine(QLineF(REF_W - 10, y, REF_W, y))
            p.drawText(QRectF(0, y - 9, REF_W - 12, 18), Qt.AlignRight | Qt.AlignVCenter, f"{k * step:g}")
        p.restore()

    def _paint_overlay(self, p, hdr, H):
        if self.mouse is None or self.mouse.y() < hdr:
            return
        m = self.mouse
        d = self.depth_at_y(m.y())
        if self.show_poslines:
            p.setPen(QPen(QColor("#d9382b"), 1, Qt.DashLine))
            p.drawLine(QLineF(0, m.y(), self.width(), m.y()))
            p.setPen(QPen(QColor("#d9382b"), 1)); p.setBrush(QColor("#fffbd0"))
            p.drawRect(QRectF(2, m.y() - 9, REF_W - 6, 18))
            f = QFont("Arial", 8); f.setBold(True); p.setFont(f); p.setPen(QColor("#a00"))
            p.drawText(QRectF(2, m.y() - 9, REF_W - 6, 18), Qt.AlignCenter, f"{d:.2f}")
        if self.show_values:
            lines = [f"Depth: {d:.2f} {self.ref_unit}"]
            for c in self.all_curves():
                i = int(np.searchsorted(c.depth, d))
                if 0 < i < len(c.depth):
                    v = c.values[i]
                    lines.append(f"{c.display_name()}: {'-' if np.isnan(v) else fmt(float(v))} {c.style.unit}")
            f = QFont("Arial", 8); p.setFont(f); fm = QFontMetrics(f)
            w = max(fm.horizontalAdvance(t) for t in lines) + 12
            h = len(lines) * (fm.height() + 1) + 8
            x = min(m.x() + 14, self.width() - w - 2); y = min(m.y() + 14, H - h - 2)
            p.setPen(QPen(QColor("#555"), 1)); p.setBrush(QColor(255, 255, 225, 235))
            p.drawRect(QRectF(x, y, w, h)); p.setPen(QColor("#111"))
            for k, t in enumerate(lines):
                p.drawText(QPointF(x + 6, y + 6 + fm.ascent() + k * (fm.height() + 1)), t)

    # --------------------------------------------------------- souris
    def curve_at(self, pos):
        hdr, ppm = self.header_h(), self.ppm()
        d = self.depth_at_y(pos.y())
        tol = 8 / ppm
        for t, r in zip(self.tracks, self.track_rects()):
            if not (r.left() <= pos.x() <= r.right()):
                continue
            for c in reversed(t.curves):
                i0 = max(0, int(np.searchsorted(c.depth, d - tol)) - 1)
                i1 = min(len(c.depth), int(np.searchsorted(c.depth, d + tol)) + 1)
                if i1 - i0 < 2:
                    continue
                xs = self.x_of(c, c.values[i0:i1], r)
                ys = hdr + (c.depth[i0:i1] - self.top) * ppm
                for a in range(len(xs) - 1):
                    if np.isfinite(xs[a]) and np.isfinite(xs[a + 1]):
                        if _seg_dist(pos, QPointF(xs[a], ys[a]), QPointF(xs[a + 1], ys[a + 1])) <= 7:
                            return c
        return None

    def track_at_x(self, x):
        for i, r in enumerate(self.track_rects()):
            if r.left() <= x <= r.right() and x >= REF_W:
                return i
        return None

    def mousePressEvent(self, e):
        self.setFocus()
        pos = e.position()
        if e.button() != Qt.LeftButton:
            return
        if self.mode == "select":
            if pos.x() < REF_W:
                self.select("reference"); return
            for r, c in self._blocks:
                if r.contains(pos):
                    self.select(c); return
            self.select(self.curve_at(pos))
        elif self.mode == "interactive" and pos.y() > self.header_h():
            self.sel_interval = None
            self._drag = ("sel", pos.y(), pos.y())
            self.update()
        elif self.mode == "zoom" and pos.y() > self.header_h():
            self._drag = ("zoom", pos.y(), pos.y())
        elif self.mode == "hand":
            self._drag = ("hand", pos, self.top, self.hscroll)
            self.setCursor(Qt.ClosedHandCursor)

    def mouseMoveEvent(self, e):
        self.mouse = e.position()
        d = self._drag
        if d and d[0] == "hand":
            dp = e.position() - d[1]
            self.top = d[2] - dp.y() / self.ppm()
            self.hscroll = int(d[3] - dp.x())
            self.view_changed()
        elif d and d[0] == "zoom":
            self._drag = ("zoom", d[1], e.position().y())
            self.update()
        elif d and d[0] == "sel":
            y = e.position().y()
            self.sel_interval = (tuple(sorted((self.depth_at_y(d[1]), self.depth_at_y(y))))
                                 if abs(y - d[1]) > 2 else None)
            self.update()
        elif self.show_values or self.show_poslines:
            self.update()

    def mouseReleaseEvent(self, e):
        d = self._drag
        self._drag = None
        if d and d[0] == "zoom" and abs(d[2] - d[1]) > 8:
            da, db = sorted((self.depth_at_y(d[1]), self.depth_at_y(d[2])))
            self.scale = max(1.0, PX_PER_M_AT_1 * self.unit_factor() * (db - da) / self.plot_h())
            self.top = da
            self.view_changed()
        elif d and d[0] == "hand":
            self.setCursor(Qt.OpenHandCursor)
        elif d and d[0] == "sel":
            self.intervalChanged.emit(self.sel_interval)
        self.update()

    def leaveEvent(self, _):
        self.mouse = None
        self.update()

    def wheelEvent(self, e):
        dy = e.angleDelta().y()
        if e.modifiers() & Qt.ControlModifier:
            self.set_scale(self.scale * (0.8 if dy > 0 else 1.25), e.position().y())
        elif e.modifiers() & Qt.ShiftModifier:
            self.hscroll -= int(dy / 2); self.view_changed()
        else:
            self.top -= (dy / 120.0) * 80 / self.ppm()
            self.view_changed()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.view_changed()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Delete and self.selected:
            self.remove_curve(self.selected)
        else:
            super().keyPressEvent(e)

    def contextMenuEvent(self, e):
        c = self.selected
        for r, cc in self._blocks:
            if r.contains(e.pos()):
                c = cc
        c = self.curve_at(e.pos()) or c
        if not c:
            return
        m = QMenu(self)
        m.addAction(f"Remove {c.display_name()}", lambda: self.remove_curve(c))
        m.addAction("Remove track", lambda: self.remove_track_of(c))
        m.exec(e.globalPos())

    # ------------------------------------------------------ drag & drop
    def dragEnterEvent(self, e):
        if e.mimeData().hasText() and e.mimeData().text().startswith(MIME_PREFIX):
            e.acceptProposedAction()

    dragMoveEvent = dragEnterEvent

    def dropEvent(self, e):
        try:
            refs = json.loads(e.mimeData().text()[len(MIME_PREFIX):])
        except ValueError:
            return
        idx = self.track_at_x(e.position().x())
        self.curvesDropped.emit(refs, -1 if idx is None else idx)
        e.acceptProposedAction()


# ====================================================================== widget
class LogViewWidget(QWidget):
    """Barre d'outils verticale + canvas + barres de défilement."""
    curveSelected = Signal(object)
    styleChanged = Signal()

    def __init__(self, provider=None):
        super().__init__()
        self.provider = provider          # provider(key, name, color_index) -> CurveItem | None
        self.index = 0                    # numéro du layout (UnknownMW:n)
        self.canvas = LogCanvas()
        self.vbar = QScrollBar(Qt.Vertical)
        self.hbar = QScrollBar(Qt.Horizontal)
        self.toolbar = self._build_toolbar()

        grid = QGridLayout(); grid.setContentsMargins(0, 0, 0, 0); grid.setSpacing(0)
        grid.addWidget(self.canvas, 0, 0); grid.addWidget(self.vbar, 0, 1); grid.addWidget(self.hbar, 1, 0)
        lay = QHBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        lay.addWidget(self.toolbar); lay.addLayout(grid, 1)

        self.canvas.selectionChanged.connect(self.curveSelected)
        self.canvas.styleChanged.connect(self.styleChanged)
        self.canvas.viewChanged.connect(self.sync_bars)
        self.canvas.viewChanged.connect(lambda: self.styleChanged.emit() if self.canvas.auto_h else None)
        self.canvas.curvesDropped.connect(self.add_refs)
        self.vbar.valueChanged.connect(self._vbar_moved)
        self.hbar.valueChanged.connect(self._hbar_moved)

    # -- barre d'outils (Table 1 : Toolbar Common Functionalities)
    def _build_toolbar(self):
        tb = QToolBar(); tb.setOrientation(Qt.Vertical); tb.setIconSize(QSize(24, 24))
        tb.setStyleSheet("QToolBar { background:#f1f1f1; border-right:1px solid #bbb; spacing:1px; }"
                         "QToolButton { padding:2px; border:1px solid transparent; }"
                         "QToolButton:checked { background:#cde4f7; border:1px solid #6aa9dc; }"
                         "QToolButton:hover { background:#e2eefa; }")
        grp = QActionGroup(self); grp.setExclusive(True)

        def mode(icon, tip, name, checked=False):
            a = QAction(icon(), tip, self); a.setToolTip(tip); a.setCheckable(True); a.setChecked(checked)
            a.triggered.connect(lambda: self.set_mode(name)); grp.addAction(a); tb.addAction(a); return a

        def tool(icon, tip, slot=None, checkable=False):
            a = QAction(icon(), tip, self); a.setToolTip(tip); a.setCheckable(checkable)
            a.triggered.connect(slot or (lambda: self._soon(tip))); tb.addAction(a); return a

        mode(ic.i_select, "Object selection", "select", True)
        mode(ic.i_interactive, "Interactive selection (drag over a depth interval)", "interactive")
        mode(ic.i_eraser, "Interactive eraser", "eraser")
        mode(ic.i_zoom, "Zoom (drag over a depth interval)", "zoom")
        mode(ic.i_hand, "Hand move", "hand")
        tool(ic.i_graph_mod, "Graphical variable modification")
        tool(ic.i_annot, "Annotation creation")
        tool(ic.i_zones, "Create zones")
        tool(ic.i_zone_editor, "Graphical Zone Editor")
        tool(ic.i_markers, "Create markers over LogView")
        tool(ic.i_split, "Split/Merge variables")
        tool(ic.i_depth_inter, "Depth interaction: inserts a depth interaction baseline")
        tool(ic.i_regression, "Custom regression creation")
        a = tool(ic.i_values, "Display the values", lambda: self._toggle("show_values", a), True)
        b = tool(ic.i_poslines, "Display the position lines", lambda: self._toggle("show_poslines", b), True)
        tool(ic.i_vadj, "Vertical adjustment", self.canvas.vertical_adjust)
        tool(ic.i_hadj, "Horizontal adjustment", self._hadj)
        tool(ic.i_gadj, "Global adjustment: adjusts the LogView display horizontally",
             lambda: self.canvas.adjust_horizontal(self.canvas.all_curves()))
        c = tool(ic.i_auto_h, "Automatic horizontal adjustment (lock)", lambda: self._toggle("auto_h", c), True)
        tool(ic.i_one_one, "1:1 return to scale 1 display", self.canvas.reset_scale)
        return tb

    def _toggle(self, attr, action):
        setattr(self.canvas, attr, action.isChecked())
        if attr == "auto_h" and action.isChecked():
            self.canvas.adjust_horizontal(self.canvas.all_curves(), emit=True)
        self.canvas.update()

    def _hadj(self):
        cs = [self.canvas.selected] if self.canvas.selected else self.canvas.all_curves()
        self.canvas.adjust_horizontal(cs)

    def _soon(self, name):
        QMessageBox.information(self, "GeoLog", f"{name}\n\nNot available yet.")

    def set_mode(self, name):
        self.canvas.mode = name
        self.canvas.setCursor({"zoom": Qt.CrossCursor, "interactive": Qt.CrossCursor,
                               "hand": Qt.OpenHandCursor}.get(name, Qt.ArrowCursor))

    # -- contenu
    def add_refs(self, refs, track_index=-1):
        """refs = [[key, curve], ...] ; chaque courbe vient dans le track visé (ou un nouveau)."""
        for key, name in refs:
            n = len(self.canvas.all_curves())
            c = self.provider(key, name, n) if self.provider else None
            if c is None:
                continue
            self.canvas.add_curve(c, None if track_index < 0 else track_index)
        self.sync_bars()

    # -- barres de défilement
    def sync_bars(self):
        cv = self.canvas
        dmin, dmax = cv.data_range()
        vis = cv.visible_span()
        for bar in (self.vbar, self.hbar):
            bar.blockSignals(True)
        self.vbar.setRange(int((dmin - vis * 0.1) * 100), int(max(dmin, dmax - vis * 0.9) * 100))
        self.vbar.setPageStep(int(vis * 100)); self.vbar.setValue(int(cv.top * 100))
        self.hbar.setRange(0, max(0, cv.content_width() - cv.width()))
        self.hbar.setPageStep(cv.width()); self.hbar.setValue(cv.hscroll)
        self.hbar.setVisible(cv.content_width() > cv.width())
        for bar in (self.vbar, self.hbar):
            bar.blockSignals(False)

    def _vbar_moved(self, v):
        self.canvas.top = v / 100.0
        self.canvas.update()

    def _hbar_moved(self, v):
        self.canvas.hscroll = v
        self.canvas.update()

    def window_title(self):
        wells = [w for w in self.canvas.well_names() if w]
        return f"UnknownMW:{self.index}" + (f" [Well: {', '.join(wells)}]" if wells else "")
