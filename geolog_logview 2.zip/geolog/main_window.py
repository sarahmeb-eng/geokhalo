"""Fenêtre principale GeoLog : ruban à onglets, Project browser, zone MDI."""
import os
from pathlib import Path

from PySide6.QtCore import Qt, QSize, QSettings, QUrl, QMimeData
from PySide6.QtGui import (QAction, QKeySequence, QBrush, QColor, QPainter, QFont, QIcon,
                           QDesktopServices)
from PySide6.QtWidgets import (QMainWindow, QTabWidget, QWidget, QHBoxLayout,
                               QVBoxLayout, QToolButton, QLabel, QFrame, QStyle,
                               QMdiArea, QMdiSubWindow, QDockWidget, QTreeWidget,
                               QTreeWidgetItem, QMessageBox, QFileDialog, QMenu,
                               QInputDialog, QApplication, QAbstractItemView, QHeaderView, QTabBar, QStackedWidget, QLineEdit,
                               QFontComboBox, QComboBox, QGridLayout, QButtonGroup,
                               QTableWidget, QTableWidgetItem, QColorDialog, QSizePolicy)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT

import plots
from project import Project, EXT
from new_project_wizard import NewProjectWizard
import json
import las_info
import logview_icons as pi
import home_icons as hi
from logview import LogViewWidget, MIME_PREFIX
from logview_model import CurveItem
from properties_panel import PropertiesPanel
from import_panel import (ImportPanel, fill_groups, paths_of, filter_tree, _tool,
                          arrow_left_icon, close_icon, trash_icon)

APP = "GeoLog"
TABS = ["Home", "Plot", "Data", "Utility", "Petrophysics", "Geology",
        "Geomechanics", "Drilling", "Reservoir", "Geophysics"]
DEFAULT_FOLDER = str(Path.home() / "GeoLog-Projects")


class CurveTree(QTreeWidget):
    """Project browser : on peut glisser des variables (ou un dataset) vers un LogView."""
    resolver = None

    def mimeTypes(self):
        return ["text/plain"]

    def mimeData(self, items):
        refs, seen = [], set()
        for it in items:
            for r in (self.resolver(it) if self.resolver else []):
                if tuple(r) not in seen:
                    seen.add(tuple(r)); refs.append(r)
        md = QMimeData()
        md.setText(MIME_PREFIX + json.dumps(refs))
        return md


class MdiArea(QMdiArea):
    """Zone centrale grise avec le logo quand aucune fenêtre n'est ouverte."""
    def paintEvent(self, e):
        super().paintEvent(e)
        if not self.subWindowList():
            p = QPainter(self.viewport())
            f = QFont("Arial Narrow", 60); f.setBold(True)
            p.setFont(f); p.setPen(QColor("#8c8c8c"))
            p.drawText(self.viewport().rect(), Qt.AlignCenter, "GeoLog")
            f2 = QFont("Times New Roman", 18); p.setFont(f2); p.setPen(QColor("#222"))
            r = self.viewport().rect().adjusted(14, 0, 0, -14)
            p.drawText(r, Qt.AlignLeft | Qt.AlignBottom, "Created by\nYour name")


class MainWindow(QMainWindow):
    windows = []          # toutes les fenêtres ouvertes

    def __init__(self, project=None):
        super().__init__()
        self.project = None
        self.dirty = False
        self.wells = {}   # clé -> DataFrame
        self.meta = {}    # chemin LAS -> info (well/dataset, clé, courbes)
        self.settings = QSettings("GeoLogApp", "GeoLog")
        MainWindow.windows.append(self)
        self.resize(1300, 780)

        self.mdi = MdiArea()
        self.mdi.setBackground(QBrush(QColor("#4a4a4a")))
        self.setCentralWidget(self.mdi)
        self._create_actions()
        self._build_ribbon()
        self._build_browser()
        self._build_properties()
        self.set_project(project)
        

    # ------------------------------------------------------------ actions
    def _act(self, text, icon, slot, shortcut=None, checkable=False):
        a = QAction(icon if isinstance(icon, QIcon) else self.style().standardIcon(icon), text, self)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        a.setCheckable(checkable)
        a.triggered.connect(slot)
        self.addAction(a)
        return a

    def _create_actions(self):
        S = QStyle
        J = "Ctrl+Shift+J, "
        self.a_new = self._act("New...", S.SP_FileIcon, self.new_project, J + "N")
        self.a_open = self._act("Open...", S.SP_DirOpenIcon, self.open_project, J + "O")
        self.a_save = self._act("Save...", hi.i_save(), self.save, J + "S")
        self.a_saveas = self._act("Save as...", S.SP_DialogSaveButton, self.save_as, "Ctrl+Shift+S")
        self.a_close = self._act("Close...", S.SP_DialogCloseButton, self.close_project, J + "C")
        self.a_import = self._act("Import...", hi.i_import(), self.import_las, J + "I")
        self.a_export = self._act("Export...", hi.i_export(), self.export_csv, J + "E")
        self.a_print = self._act("Print...", hi.i_print(), self._todo, "Ctrl+P, P")
        self.a_options = self._act("Options...", S.SP_FileDialogDetailedView, self._todo, J + "P")
        self.a_exit = self._act("Exit", S.SP_DialogCancelButton, self.exit_app, "Alt+F4")
        self.a_info = self._act("Project information", S.SP_MessageBoxInformation, self.project_info)
        self.a_folder = self._act("Open project folder", S.SP_DirIcon, self.open_folder)
        self.a_about = self._act("About GeoLog", S.SP_MessageBoxInformation, self.about)

        # Plot
        self.a_logview = self._act("LogView", pi.i_logview(), self.new_logview)
        self.a_cross = self._act("Cross-plot", pi.i_scatter(), self.plot_cross)
        self.a_lineplot = self._act("Line-plot", pi.i_lineplot(), self.plot_log)
        self.a_hist = self._act("Histogram", pi.i_hist(), self.plot_hist)
        self.a_xarray = self._act("Cross-plot array", pi.i_scatter_array(), self._todo)
        self.a_box = self._act("Box-plot", pi.i_boxplot(), self._todo)
        self.a_star = self._act("Star-plot", pi.i_star(), self._todo)
        self.a_mw_cross = self._act("Cross-plot ", pi.i_scatter(), self._todo)
        self.a_mw_hist = self._act("Histogram ", pi.i_hist(), self._todo)
        self.a_mw_box = self._act("Box-plot ", pi.i_boxplot(), self._todo)
        self.a_mx_cross = self._act("Cross-plot  ", pi.i_scatter(), self._todo)
        self.a_mx_hist = self._act("Histogram  ", pi.i_hist(), self._todo)

        # Home
        self.a_screenshot = self._act("Window\nscreenshot", hi.i_camera(), self.screenshot)
        self.a_composer = self._act("Composer", hi.i_composer(), self._todo)
        self.a_header = self._act("Header editor", hi.i_header(), self._todo)
        self.a_batch = self._act("Batch printing", hi.i_batch(), self._todo)
        self.a_report = self._act("Report\neditor", hi.i_report(), self._todo)
        self.a_patterns = self._act("Patterns", hi.i_patterns(), self._todo)
        self.a_symbols = self._act("Symbols", hi.i_symbols(), self._todo)
        self.a_zones = self._act("Zones", hi.i_zones(), self._todo)
        self.a_menus = self._act("Menus", hi.i_menus(), self._todo)
        self.a_full = self._act("Full\nscreen", hi.i_fullscreen(), self.toggle_fullscreen, "F11", True)
        self.a_props = self._act("Properties editor", hi.i_props(), self.toggle_props, None, True)
        self.a_actions = self._act("Actions widget", hi.i_actions(), self._todo, None, True)
        self.a_dash = self._act("Dashboard\nmode", hi.i_dashboard(), self._todo, None, True)
        self.a_tile = self._act("Tile", hi.i_tile(), self.mdi_tile)
        self.a_casc = self._act("Cascade", hi.i_cascade(), self.mdi_cascade)
        self.a_closeall = self._act("Close all windows", S.SP_DialogCloseButton, self.close_subwindows)
        self.a_tileh = self._act("Tile horizontally", hi.i_tile(), lambda: self.mdi_tile("h"))
        self.a_tilev = self._act("Tile vertically", hi.i_tile(), lambda: self.mdi_tile("v"))

    # ------------------------------------------------------------- ruban
    STYLE = """
    #ribbon { background:#f4f4f4; }
    #ribbonPage { background:white; border-top:1px solid #c8c8c8; border-bottom:1px solid #c8c8c8; }
    QTabBar::tab { padding:3px 12px; background:#2b2b2b; color:white; }
    QTabBar::tab:selected { background:white; color:black; }
    QTabBar::tab:disabled { color:#777; }
    #projBtn { background:#c8102e; color:white; font-weight:bold; padding:3px 12px; border:none; }
    #projBtn::menu-indicator { image:none; }
    #projBtn:pressed, #projBtn:hover { background:#e0233f; }
    QMenu::item { padding:5px 30px 5px 28px; }
    QMenu::item:selected { background:#cfe3f7; color:black; }
    """

    def _icon_btn(self, a, big):
        b = QToolButton()
        b.setDefaultAction(a)
        b.setAutoRaise(True)
        if big:
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setIconSize(QSize(28, 28)); b.setMinimumWidth(max(52, 7 * max(len(l) for l in a.text().split("\n")) + 14))
        else:
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            b.setIconSize(QSize(16, 16))
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        if a.menu():
            b.setPopupMode(QToolButton.InstantPopup)
            if big:
                lines = a.text().split("\n")
                b.setText("\n".join(lines[:1] + ["\u25be"]) if len(lines) == 1 else a.text() + " \u25be")
            else:
                b.setText(a.text() + " \u25be")
        return b

    def big(self, *acts):
        return [self._icon_btn(a, True) for a in acts]

    def col(self, *acts, icons_only=False):
        w = QWidget(); v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        for a in acts:
            b = self._icon_btn(a, False)
            if icons_only:
                b.setToolButtonStyle(Qt.ToolButtonIconOnly); b.setIconSize(QSize(18, 18))
                b.setToolTip(a.text())
            v.addWidget(b)
        v.addStretch()
        return w

    def _group(self, title, widgets):
        box = QWidget()
        v = QVBoxLayout(box); v.setContentsMargins(4, 1, 4, 0); v.setSpacing(0)
        row = QHBoxLayout(); row.setSpacing(2)
        for w in widgets:
            row.addWidget(w)
        v.addLayout(row)
        lbl = QLabel(title); lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet("color:#666; font-size:9px;")
        v.addWidget(lbl)
        return box

    def _page(self, groups):
        w = QWidget(); w.setObjectName("ribbonPage")
        h = QHBoxLayout(w); h.setContentsMargins(4, 2, 4, 2); h.setSpacing(0)
        for i, g in enumerate(groups):
            if i:
                sep = QFrame(); sep.setFrameShape(QFrame.VLine); sep.setFrameShadow(QFrame.Sunken)
                h.addWidget(sep)
            h.addWidget(g)
        h.addStretch()
        w.setFixedHeight(84)
        return w

    def _more_menu(self):
        m = QMenu(self)
        for t in ("Cross-plot 3D", "Polar plot", "Ternary plot"):
            m.addAction(t, self._todo)
        self._keep = getattr(self, "_keep", []) + [m]
        return self._make_menu_action("More", pi.i_more(), m)

    def _adv_menu(self):
        m = QMenu(self)
        for t in ("3D viewer", "Stereonet", "Map view"):
            m.addAction(t, self._todo)
        self._keep = getattr(self, "_keep", []) + [m]
        return self._make_menu_action("", pi.i_cube(), m)

    def _make_menu_action(self, text, icon, menu):
        a = QAction(icon if isinstance(icon, QIcon) else self.style().standardIcon(icon), text, self)
        a.setMenu(menu)
        return a

    def _font_group(self):
        S = QStyle
        w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 2, 0, 0); g.setSpacing(3)
        self.font_box = QFontComboBox(); self.font_box.setCurrentFont(QFont("Verdana"))
        self.font_box.setFixedWidth(150)
        self.size_box = QComboBox(); self.size_box.setEditable(True)
        self.size_box.addItems([str(s) for s in (8, 9, 10, 11, 12, 14, 16, 18, 20)])
        self.size_box.setCurrentText("10"); self.size_box.setFixedWidth(55)
        g.addWidget(self.font_box, 0, 0, 1, 4); g.addWidget(self.size_box, 0, 4, 1, 3)
        self.btn_b, self.btn_i, self.btn_u = (QToolButton() for _ in range(3))
        for b, t, st in ((self.btn_b, "B", "font-weight:bold"), (self.btn_i, "I", "font-style:italic"),
                         (self.btn_u, "U", "text-decoration:underline")):
            b.setText(t); b.setCheckable(True); b.setStyleSheet(st); b.setAutoRaise(True)
            b.toggled.connect(self.apply_font)
        grp = QButtonGroup(w); grp.setExclusive(True)
        aligns = []
        for t in ("⯇", "≡", "⯈", "☰"):
            b = QToolButton(); b.setText(t); b.setCheckable(True); b.setAutoRaise(True)
            grp.addButton(b); aligns.append(b)
        aligns[0].setChecked(True)
        self.btn_color = QToolButton(); self.btn_color.setText("A"); self.btn_color.setAutoRaise(True)
        self.btn_color.setStyleSheet("font-weight:bold; text-decoration:underline; color:#c8102e")
        self.btn_color.clicked.connect(self.pick_color)
        for i, b in enumerate([self.btn_b, self.btn_i, self.btn_u] + aligns + [self.btn_color]):
            g.addWidget(b, 1, i)
        self.font_box.currentFontChanged.connect(self.apply_font)
        self.size_box.currentTextChanged.connect(self.apply_font)
        return w

    def _build_ribbon(self):
        # ---- menu du bouton Project (liste de commandes + raccourcis)
        S = QStyle
        m = QMenu(self)
        for a in (self.a_new, self.a_open, self.a_save, self.a_saveas, self.a_close):
            m.addAction(a)
        m.addSeparator()
        self.recent_menu = m.addMenu(self.style().standardIcon(S.SP_FileDialogDetailedView),
                                     "Recent projects")
        self.recent_menu.aboutToShow.connect(self._fill_recent)
        m.addSeparator(); m.addAction(self.a_import); m.addAction(self.a_export)
        m.addSeparator()
        mu = m.addMenu(self.style().standardIcon(S.SP_DirIcon), "Project utilities")
        mu.addAction(self.a_info); mu.addAction(self.a_folder)
        ml = m.addMenu(self.style().standardIcon(S.SP_MessageBoxInformation), "Licensing")
        ml.addAction(self.a_about)
        m.addSeparator(); m.addAction(self.a_print)
        m.addSeparator(); m.addAction(self.a_options)
        m.addSeparator(); m.addAction(self.a_exit)

        btn = QToolButton(); btn.setText("Project"); btn.setObjectName("projBtn")
        btn.setMenu(m); btn.setPopupMode(QToolButton.InstantPopup)

        # ---- menus des boutons du ruban
        dock_menu = QMenu(self)
        tile_menu = QMenu(self)
        for a in (self.a_tile, self.a_tileh, self.a_tilev):
            tile_menu.addAction(a)
        misc_menu = QMenu(self); misc_menu.addAction(self.a_casc); misc_menu.addAction(self.a_closeall)
        self.win_menu = QMenu(self); self.win_menu.aboutToShow.connect(self._fill_windows)
        batch_menu = QMenu(self); batch_menu.addAction("Print all layouts", self._todo)
        self._dock_menu = dock_menu

        self.a_batch.setMenu(batch_menu)
        a_dock = self._make_menu_action("Dock windows", hi.i_dock(), dock_menu)
        a_tilem = self._make_menu_action("Tile", hi.i_tile(), tile_menu)
        a_misc = self._make_menu_action("Miscellaneous", hi.i_cascade(), misc_menu)
        a_win = self._make_menu_action("Windows", hi.i_windows(), self.win_menu)
        a_s1 = self._act("Save layout", hi.i_save_layout(), self._todo)
        a_s2 = self._act("Reset layout", hi.i_reset_layout(), self._todo)
        a_s3 = self._act("Layout manager", hi.i_layout_mgr(), self._todo)

        home = [
            self._group("Project", self.big(self.a_save, self.a_import, self.a_export, self.a_print)),
            self._group("Techreport", self.big(self.a_screenshot) +
                        [self.col(self.a_composer, self.a_header, self.a_batch)] + self.big(self.a_report)),
            self._group("Font", [self._font_group()]),
            self._group("Tools", self.big(self.a_patterns, self.a_symbols, self.a_zones, self.a_menus)),
            self._group("View", self.big(self.a_full) +
                        [self.col(self.a_props, self.a_actions, a_dock), self.col(a_s1, a_s2, a_s3, icons_only=True)]),
            self._group("Window", self.big(self.a_dash, a_tilem, a_misc, a_win)),
        ]
        pages = {
            "Home": home,
            "Plot": [
                self._group("Layout", self.big(self.a_logview)),
                self._group("Single well", self.big(self.a_cross, self.a_lineplot, self.a_hist) +
                            [self.col(self.a_xarray, self.a_box, self.a_star)] + self.big(self._more_menu())),
                self._group("Multi-well", self.big(self.a_mw_cross, self.a_mw_hist, self.a_mw_box,
                                                   self._more_menu())),
                self._group("Matrix-plot", self.big(self.a_mx_cross, self.a_mx_hist, self._more_menu())),
                self._group("Advanced plotting", self.big(self._adv_menu())),
            ],
            "Data": [self._group("Data", self.big(self.a_import, self.a_export))],
        }

        self.tabbar = QTabBar(); self.tabbar.setExpanding(False); self.tabbar.setDrawBase(False)
        self.stack = QStackedWidget()
        for name in TABS:
            self.tabbar.addTab(name)
            if name in pages:
                self.stack.addWidget(self._page(pages[name]))
            else:
                ph = QLabel(f"   {name}: à venir"); ph.setObjectName("ribbonPage"); ph.setFixedHeight(84)
                self.stack.addWidget(ph)
        self.tabbar.currentChanged.connect(self.stack.setCurrentIndex)

        top = QWidget(); top.setObjectName("ribbon"); top.setStyleSheet(self.STYLE)
        v = QVBoxLayout(top); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        bar = QWidget(); bar.setStyleSheet("background:#2b2b2b;")
        h = QHBoxLayout(bar); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(0)
        h.addWidget(btn); h.addWidget(self.tabbar); h.addStretch()
        v.addWidget(bar); v.addWidget(self.stack)
        dock = QDockWidget(); dock.setTitleBarWidget(QWidget())
        dock.setWidget(top); dock.setFeatures(QDockWidget.NoDockWidgetFeatures)
        self.addDockWidget(Qt.TopDockWidgetArea, dock)

    def _build_browser(self):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(2, 2, 2, 2); h.setSpacing(2)

        # --- colonne gauche : le projet
        left = QWidget(); v = QVBoxLayout(left); v.setContentsMargins(0, 0, 0, 0)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search")
        self.search.textChanged.connect(lambda t: filter_tree(self.tree, t))
        self.tree = CurveTree(); self.tree.resolver = self.curve_refs
        self.tree.setDragEnabled(True); self.tree.setDragDropMode(QAbstractItemView.DragOnly)
        self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Name", "Family"])
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(self._tree_double_click)
        self.btn_trash = _tool(trash_icon(), "Delete selected from project", 20)
        self.btn_trash.clicked.connect(self.delete_selected)
        v.addWidget(self.search); v.addWidget(self.tree)
        v.addWidget(self.btn_trash, 0, Qt.AlignLeft)

        # --- colonne milieu : X (fermer l'import) et flèche (transférer)
        self.mid = QWidget(); m = QVBoxLayout(self.mid); m.setContentsMargins(0, 0, 0, 0)
        bx = _tool(close_icon(), "Close import panel", 20); bx.clicked.connect(self.close_import)
        self.btn_transfer = _tool(arrow_left_icon(), "Transfer to project", 28)
        self.btn_transfer.clicked.connect(self.transfer_import)
        m.addWidget(bx); m.addStretch(); m.addWidget(self.btn_transfer); m.addStretch()

        # --- colonne droite : le container d'import
        self.import_panel = ImportPanel()
        self.import_panel.is_known = lambda p: bool(self.project) and p in {
            os.path.normpath(x) for x in self.project.datasets}

        h.addWidget(left, 1); h.addWidget(self.mid); h.addWidget(self.import_panel, 1)
        self.mid.hide(); self.import_panel.hide()

        self.browser_dock = QDockWidget("Project browser")
        self.browser_dock.setWidget(w)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.browser_dock)
        self._dock_menu.addAction(self.browser_dock.toggleViewAction())

    def curve_refs(self, item):
        """[[dataset_key, courbe], ...] porté par un item du Project browser."""
        key = item.data(0, Qt.UserRole)
        if key in self.wells:                                  # un dataset entier
            return [[key, str(c)] for c in self.wells[key].columns]
        par = item.parent()
        if par is not None:
            k = par.data(0, Qt.UserRole)
            if k in self.wells and item.text(0) in self.wells[k].columns:
                return [[k, item.text(0)]]
        return []

    def _tree_double_click(self, item, _col):
        key = item.data(0, Qt.UserRole)
        if key in self.wells:                                  # dataset -> LogView automatique
            self.open_dataset_logview(key)
            return
        refs = self.curve_refs(item)
        if refs:                                               # courbe -> ajoutée au LogView actif
            lv = self.active_logview() or self.new_logview()
            if lv:
                lv.add_refs(refs, -1)

    def _build_properties(self):
        self.props = QTableWidget(0, 2)
        self.props.horizontalHeader().setVisible(False); self.props.verticalHeader().setVisible(False)
        self.props.horizontalHeader().setStretchLastSection(True)
        self.var_panel = PropertiesPanel()
        self.props_stack = QStackedWidget()
        self.props_stack.addWidget(self.props)          # page 0 : infos du projet
        self.props_stack.addWidget(self.var_panel)      # page 1 : variable sélectionnée
        self.props_dock = QDockWidget("Properties")
        self.props_dock.setWidget(self.props_stack)
        self.addDockWidget(Qt.RightDockWidgetArea, self.props_dock)
        self.props_dock.hide()
        self.props_dock.visibilityChanged.connect(self.a_props.setChecked)
        self._dock_menu.addAction(self.props_dock.toggleViewAction())

    def _refresh_props(self):
        p = self.project
        rows = [] if not p else [("Name", p.name), ("Folder", p.folder), ("Status", p.status),
                                 ("Mode", p.mode), ("Units", p.units), ("Wells", str(len(self.wells)))]
        self.props.setRowCount(len(rows))
        for i, (k, val) in enumerate(rows):
            self.props.setItem(i, 0, QTableWidgetItem(k)); self.props.setItem(i, 1, QTableWidgetItem(val))

    def _refresh_tree(self):
        self.tree.clear()
        if not self.project:
            return
        root = QTreeWidgetItem([self.project.name])
        self.tree.addTopLevelItem(root)
        ds = None
        for n in ("Datasets", "Layouts", "Cross-plots", "Python scripts"):
            node = QTreeWidgetItem(root, [n])
            if n == "Datasets":
                ds = node
                infos = [self.meta[p] for p in self.project.datasets if p in self.meta]
                fill_groups(node, infos, with_curves=True)
        root.setExpanded(True)
        ds.setExpanded(True)

    # ------------------------------------------- fonctions du ruban Home
    def apply_font(self, *_):
        f = QFont(self.font_box.currentFont())
        try:
            f.setPointSize(int(self.size_box.currentText()))
        except ValueError:
            pass
        f.setBold(self.btn_b.isChecked()); f.setItalic(self.btn_i.isChecked())
        f.setUnderline(self.btn_u.isChecked())
        self.tree.setFont(f)

    def pick_color(self):
        c = QColorDialog.getColor(parent=self)
        if c.isValid():
            self.tree.setStyleSheet(f"QTreeWidget {{ color:{c.name()}; }}")

    def screenshot(self):
        path, _ = QFileDialog.getSaveFileName(self, "Window screenshot", "screenshot.png", "PNG (*.png)")
        if path:
            self.grab().save(path)

    def toggle_fullscreen(self):
        self.showFullScreen() if self.a_full.isChecked() else self.showNormal()

    def toggle_props(self):
        self.props_dock.setVisible(self.a_props.isChecked())

    def _fill_windows(self):
        self.win_menu.clear()
        subs = self.mdi.subWindowList()
        if not subs:
            self.win_menu.addAction("(no window)").setEnabled(False)
        for s in subs:
            self.win_menu.addAction(s.windowTitle(), lambda s=s: self.mdi.setActiveSubWindow(s))

    def close_subwindows(self):
        for s in self.mdi.subWindowList():
            s.close()

    def project_info(self):
        p = self.project
        if p:
            QMessageBox.information(self, APP, f"Name: {p.name}\nFile: {p.path}\nStatus: {p.status}\n"
                                    f"Mode: {p.mode}\nUnits: {p.units}\nDatasets: {len(p.datasets)}")

    def open_folder(self):
        if self.project:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.project.project_dir))

    def about(self):
        QMessageBox.about(self, APP, "GeoLog 1.0\nGeophysics / petrophysics desktop software.")

    def export_csv(self):
        if not self._need_wells():
            return
        well = self._pick("Well to export", list(self.wells))
        if well:
            path, _ = QFileDialog.getSaveFileName(self, "Export", f"{well}.csv", "CSV (*.csv)")
            if path:
                self.wells[well].to_csv(path)

# ----------------------------------------------------- état du projet
    def set_project(self, project):
        self.project = project
        self.dirty = False
        self.wells = {}
        self.meta = {}
        if project:
            project.datasets = [os.path.normpath(p) for p in project.datasets]
        for sub in self.mdi.subWindowList():
            sub.close()
        self.var_panel.set_curve(None); self.props_stack.setCurrentIndex(0); self._panel_owner = None
        if project:
            for p in project.datasets:
                self._load_las(p, register=False)
            self._add_recent(project.path)
        self.stack.setEnabled(project is not None)
        for a in (self.a_save, self.a_saveas, self.a_close, self.a_import, self.a_export,
                  self.a_print, self.a_info, self.a_folder):
            a.setEnabled(project is not None)
        self._refresh_tree()
        self._refresh_props()
        self.update_title()

    def update_title(self):
        if not self.project:
            self.setWindowTitle(f"{APP} - no project")
            return
        p = self.project
        star = " *" if self.dirty else ""
        self.setWindowTitle(f"{APP} 1.0 | Project: {p.name}{star} | Status: {p.status} "
                            f"| Workspace: {APP} workspace")

    def set_dirty(self, d=True):
        self.dirty = d
        self.update_title()

    def maybe_save(self):
        """True si on peut continuer (sauvé ou ignoré), False si annulé."""
        if not (self.project and self.dirty):
            return True
        box = QMessageBox(QMessageBox.Question, APP,
                          f'Do you want to save changes to the project "{self.project.name}"?',
                          parent=self)
        save = box.addButton("Save", QMessageBox.AcceptRole)
        dont = box.addButton("Don't save", QMessageBox.DestructiveRole)
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is save:
            return self.save()
        return box.clickedButton() is dont

    # ------------------------------------------------- actions du menu Project
    def new_project(self):
        wiz = NewProjectWizard(self.settings.value("folder", DEFAULT_FOLDER), self)
        if wiz.exec() != NewProjectWizard.Accepted:
            return
        proj = wiz.project()
        proj.save()
        self.settings.setValue("folder", proj.folder)
        self._show_project(proj)

    def open_project(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open project", self.settings.value("folder", DEFAULT_FOLDER),
            f"GeoLog project (*{EXT})")
        if path:
            self.open_path(path)

    def open_path(self, path):
        try:
            proj = Project.load(path)
        except Exception as e:
            QMessageBox.critical(self, APP, f"Cannot open project:\n{e}")
            return
        self._show_project(proj)

    def _show_project(self, proj):
        """Comme Word/Excel : fenêtre vide -> on l'utilise ; sinon on demande."""
        if self.project is None:
            self.set_project(proj)
            return
        box = QMessageBox(QMessageBox.Question, APP,
                          f'The project "{self.project.name}" is already open.\n\n'
                          "Do you want to replace the current project or open the "
                          f"project into a new {APP}?", parent=self)
        rep = box.addButton("Replace the current", QMessageBox.AcceptRole)
        new = box.addButton(f"Open inside new {APP}", QMessageBox.ActionRole)
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is rep:
            if self.maybe_save():
                self.set_project(proj)
        elif box.clickedButton() is new:
            w = MainWindow(proj)
            w.show()

    def save(self):
        if not self.project:
            return False
        try:
            self.project.save()
        except Exception as e:
            QMessageBox.critical(self, APP, f"Cannot save:\n{e}")
            return False
        self.set_dirty(False)
        self.statusBar().showMessage("Project saved", 3000)
        return True

    def save_as(self):
        if not self.project:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save project as", self.project.default_path(),
                                              f"GeoLog project (*{EXT})")
        if path:
            self.project.name = Path(path).stem
            self.project.folder = str(Path(path).parent.parent)
            self.project.save(path)
            self._add_recent(path)
            self._refresh_tree()
            self.set_dirty(False)

    def close_project(self):
        if self.maybe_save():
            self.set_project(None)

    def exit_app(self):
        for w in list(MainWindow.windows):
            if not w.close():
                break

    def closeEvent(self, e):
        if self.maybe_save():
            MainWindow.windows.remove(self)
            e.accept()
        else:
            e.ignore()

    # ------------------------------------------------------- projets récents
    def _recent(self):
        r = self.settings.value("recent", [])
        return [r] if isinstance(r, str) else list(r or [])

    def _add_recent(self, path):
        if not path:
            return
        r = [p for p in self._recent() if p != path]
        self.settings.setValue("recent", ([path] + r)[:10])

    def _fill_recent(self):
        self.recent_menu.clear()
        items = [p for p in self._recent() if os.path.exists(p)]
        if not items:
            self.recent_menu.addAction("(none)").setEnabled(False)
        for p in items:
            self.recent_menu.addAction(p, lambda p=p: self.open_path(p))

    # ------------------------------------------------------- données LAS
    def import_las(self):
        """Ouvre le container d'import à droite du Project browser."""
        if not self.project:
            return
        self.mid.show(); self.import_panel.show()
        self.browser_dock.setMinimumWidth(720)
        self.resizeDocks([self.browser_dock], [760], Qt.Horizontal)

    def close_import(self):
        self.mid.hide(); self.import_panel.hide()
        self.browser_dock.setMinimumWidth(0)
        self.resizeDocks([self.browser_dock], [260], Qt.Horizontal)

    def transfer_import(self):
        """Flèche : container d'import -> projet."""
        paths = self.import_panel.selected_paths()
        if not paths:
            self.statusBar().showMessage("Select the data to transfer first", 3000)
            return
        ok = []
        for p in paths:
            if self._load_las(p):
                self.project.datasets.append(p)
                ok.append(p)
        n = len(ok)
        self.import_panel.remove_paths(ok)     # les fichiers en erreur restent dans le container
        if n:
            self.set_dirty()
        self._refresh_tree(); self._refresh_props()
        self.statusBar().showMessage(f"{n} dataset(s) transferred to the project", 4000)

    def delete_selected(self):
        paths = {p for it in self.tree.selectedItems() for p in paths_of(it)}
        if not paths:
            return
        if QMessageBox.question(self, APP, f"Remove {len(paths)} dataset(s) from the project?"
                                ) != QMessageBox.Yes:
            return
        for p in paths:
            info = self.meta.pop(p, None)
            if info:
                self.wells.pop(info["key"], None)
            if p in self.project.datasets:
                self.project.datasets.remove(p)
        self.set_dirty(); self._refresh_tree(); self._refresh_props()

    def _load_las(self, path, register=True):
        path = os.path.normpath(path)
        try:
            import lasio
            df = lasio.read(path).df()
        except ImportError:
            QMessageBox.warning(self, APP, "Install lasio:  pip install lasio")
            return False
        except Exception as e:
            QMessageBox.warning(self, APP, f"Cannot read {path}:\n{e}")
            return False
        info = las_info.read_info_safe(path)
        key, n = info["stem"], 2
        while key in self.wells:           # deux fichiers de même nom, dossiers différents
            key = f'{info["stem"]} ({n})'; n += 1
        info["key"] = key
        self.meta[path] = info
        self.wells[key] = df
        return True

    # ---------------------------------------------------------- LogView
    FAM_TRACK = {"Gamma Ray": 0, "Spontaneous Potential": 0, "Caliper": 0, "Resistivity": 1,
                 "Bulk Density": 2, "Neutron Porosity": 2, "Photoelectric Factor": 2, "Sonic": 3}

    def new_logview(self):
        if not self.project:
            return None
        lv = LogViewWidget(self.make_curve)
        sub = QMdiSubWindow(); sub.setWidget(lv); sub.setAttribute(Qt.WA_DeleteOnClose)
        sub.setWindowTitle("LogView")
        lv.curveSelected.connect(lambda obj, lv=lv: self.on_curve_selected(obj, lv))
        lv.styleChanged.connect(lambda: self.var_panel.refresh())
        lv.canvas.viewChanged.connect(lambda: sub.setWindowTitle(lv.window_title()))
        lv.destroyed.connect(lambda *_, lv=lv: self._logview_closed(lv))
        self.mdi.addSubWindow(sub); sub.resize(900, 640); sub.show()
        lv.canvas.setFocus()
        return lv

    def active_logview(self):
        sub = self.mdi.activeSubWindow()
        if sub and isinstance(sub.widget(), LogViewWidget):
            return sub.widget()
        for s in reversed(self.mdi.subWindowList()):
            if isinstance(s.widget(), LogViewWidget):
                return s.widget()
        return None

    def make_curve(self, key, name, color_index=0):
        df = self.wells.get(key)
        if df is None or name not in df.columns:
            return None
        depth = df.index.values.astype(float)
        vals = df[name].values.astype(float)
        info = next((i for i in self.meta.values() if i.get("key") == key), None)
        unit = fam = well = ""
        dsname = key
        if info:
            cur = next((c for c in info["curves"] if c["mnemonic"].upper() == str(name).upper()), None)
            if cur:
                unit, fam = cur["unit"], cur["family"]
            if info["kind"] == las_info.WELL:
                well = info["group"]
            dsname = info["name"]
        c = CurveItem(key, str(name), depth, vals, unit, well, dsname, fam, color_index)
        c.siblings = [str(x) for x in df.columns if x != name]
        c.loader = lambda n, df=df, depth=depth: (depth, df[n].values.astype(float)) if n in df.columns else None
        return c

    def open_dataset_logview(self, key):
        """Double-clic sur un dataset : tracks automatiques par famille (GR | Rés | Densité/Neutron | Sonic)."""
        lv = self.new_logview()
        if not lv:
            return
        slots, extras = {}, []
        for n in self.wells[key].columns:
            c = self.make_curve(key, n, 0)
            if c is None:
                continue
            slot = self.FAM_TRACK.get(c.style.family)
            (slots.setdefault(slot, []) if slot is not None else extras).append(c)
        groups = [slots[k] for k in sorted(slots)] + [[c] for c in extras[:4]]
        for curves in groups:
            idx = None
            for k, c in enumerate(curves):
                if c.style.family == "":
                    c.apply_family("", k)
                lv.canvas.add_curve(c, idx)
                idx = len(lv.canvas.tracks) - 1
        lv.sync_bars()

    def on_curve_selected(self, obj, lv):
        if isinstance(obj, CurveItem):
            self._panel_owner = lv
            self.var_panel.set_curve(obj, notify=lv.canvas.update)
            self.props_stack.setCurrentIndex(1)
            if not self.props_dock.isVisible():
                self.props_dock.show()
                self.resizeDocks([self.props_dock], [380], Qt.Horizontal)
        else:
            self.var_panel.set_curve(None)
            self.props_stack.setCurrentIndex(0)

    def _logview_closed(self, lv):
        if getattr(self, "_panel_owner", None) is lv:
            self._panel_owner = None
            self.var_panel.set_curve(None)
            self.props_stack.setCurrentIndex(0)

    # ------------------------------------------------------------ plots
    def _pick(self, label, items):
        item, ok = QInputDialog.getItem(self, APP, label, items, 0, False)
        return item if ok else None

    def _need_wells(self):
        if not self.wells:
            QMessageBox.information(self, APP, "Import a LAS dataset first.")
            return False
        return True

    def _show_fig(self, fig, title):
        canvas = FigureCanvasQTAgg(fig)
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(NavigationToolbar2QT(canvas, w)); v.addWidget(canvas)
        sub = QMdiSubWindow(); sub.setWidget(w); sub.setWindowTitle(title)
        sub.setAttribute(Qt.WA_DeleteOnClose)
        self.mdi.addSubWindow(sub); sub.resize(700, 500); sub.show()

    def plot_log(self, well=None):
        if not self._need_wells():
            return
        well = well if isinstance(well, str) else self._pick("Well", list(self.wells))
        if well:
            self._show_fig(plots.log_plot(self.wells[well], well), f"Log plot - {well}")

    def plot_hist(self):
        if not self._need_wells():
            return
        well = self._pick("Well", list(self.wells))
        if well:
            c = self._pick("Curve", list(self.wells[well].columns))
            if c:
                self._show_fig(plots.histogram(self.wells[well], c, well), f"Histogram - {c}")

    def plot_cross(self):
        if not self._need_wells():
            return
        well = self._pick("Well", list(self.wells))
        if well:
            cols = list(self.wells[well].columns)
            x = self._pick("X curve", cols)
            y = x and self._pick("Y curve", cols)
            if x and y:
                self._show_fig(plots.cross_plot(self.wells[well], x, y, well), f"Cross-plot {x}/{y}")

    def mdi_tile(self, mode=None):
        subs = self.mdi.subWindowList()
        if mode and subs:
            area = self.mdi.viewport().rect(); n = len(subs)
            for i, s in enumerate(subs):
                s.showNormal()
                if mode == "h":
                    s.setGeometry(0, i * area.height() // n, area.width(), area.height() // n)
                else:
                    s.setGeometry(i * area.width() // n, 0, area.width() // n, area.height())
        else:
            self.mdi.tileSubWindows()
    def mdi_cascade(self): self.mdi.cascadeSubWindows()
    def _todo(self): QMessageBox.information(self, APP, "Not implemented yet.")
