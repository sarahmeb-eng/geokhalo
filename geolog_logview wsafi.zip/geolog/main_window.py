"""Fenêtre principale GeoLog : ruban à onglets, Project browser, zone MDI."""
import os
from pathlib import Path

from PySide6.QtCore import Qt, QSize, QSettings, QUrl, QMimeData, Signal, QTimer
from PySide6.QtGui import (QAction, QKeySequence, QBrush, QColor, QPainter, QFont, QIcon,
                           QDesktopServices, QGuiApplication)
from PySide6.QtWidgets import (QMainWindow, QTabWidget, QWidget, QHBoxLayout,
                               QVBoxLayout, QToolButton, QLabel, QFrame, QStyle,
                               QMdiArea, QMdiSubWindow, QDockWidget, QTreeWidget,
                               QTreeWidgetItem, QMessageBox, QFileDialog, QMenu,
                               QInputDialog, QApplication, QAbstractItemView, QHeaderView, QTabBar, QStackedWidget, QLineEdit,
                               QFontComboBox, QComboBox, QGridLayout, QButtonGroup,
                               QTableWidget, QTableWidgetItem, QColorDialog, QSizePolicy, QScrollArea, QDialog)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT

import plots
from project import Project, EXT
from new_project_wizard import NewProjectWizard
import copy
import json
import re

import numpy as np
import pandas as pd
import las_info
import logview_icons as pi
import home_icons as hi
from logview import LogViewWidget, MIME_PREFIX
import re
import numpy as np
import processing
from depthshift import DepthShiftWidget, pick_reference
from dialogs import SmoothDialog
from PySide6.QtWidgets import QDialog
from logview_model import CurveItem
from properties_panel import PropertiesPanel
from layout_panel import LayoutPanel
import splice as sp
from splice_tool import SpliceToolWidget, DATASETS_MIME
from splice_graph import SpliceGraphWidget
from variable_tools import SaveVariablesDialog, mask_interval
from import_panel import (ImportPanel, fill_groups, paths_of, filter_tree, _tool,
                          arrow_left_icon, close_icon, trash_icon)

RIBBON_H = 66      # hauteur de la page du ruban (px) : modifier ici
APP = "GeoLog"
TABS = ["Home", "Plot", "Data", "Utility", "Petrophysics", "Geology",
        "Geomechanics", "Drilling", "Reservoir", "Geophysics"]
DEFAULT_FOLDER = str(Path.home() / "GeoLog-Projects")


class Toast(QFrame):
    """Notification non bloquante en bas à droite de la fenêtre."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setStyleSheet("Toast { background:#ffffff; border:1px solid #9a9a9a; }"
                           "QLabel { background:transparent; }")
        v = QVBoxLayout(self); v.setContentsMargins(10, 8, 10, 8); v.setSpacing(4)
        head = QHBoxLayout()
        ic = QLabel("⚠"); ic.setStyleSheet("color:#e0a800; font-size:20px;")
        t = QLabel("Warnings"); f = t.font(); f.setBold(True); t.setFont(f)
        x = QToolButton(); x.setText("×"); x.setAutoRaise(True); x.clicked.connect(self.hide)
        head.addWidget(ic); head.addWidget(t, 1); head.addWidget(x)
        self.msg = QLabel(); self.msg.setWordWrap(True)
        link = QLabel('<a href="#" style="color:#1b7fd0">Click for more details</a>')
        link.linkActivated.connect(lambda _: QMessageBox.information(self.parent(), "Warnings", self.msg.text()))
        v.addLayout(head); v.addWidget(self.msg); v.addWidget(link)
        self.setFixedWidth(330)
        self.timer = QTimer(self); self.timer.setSingleShot(True); self.timer.timeout.connect(self.hide)
        self.hide()

    def show_message(self, text):
        self.msg.setText(text)
        self.adjustSize()
        p = self.parent()
        self.move(p.width() - self.width() - 14, p.height() - self.height() - 34)
        self.show(); self.raise_()
        self.timer.start(8000)


class RibbonTabBar(QTabBar):
    """Barre d'onglets du ruban : les onglets contextuels (tabData == 'ctx') sont jaunes."""

    def paintEvent(self, e):
        p = QPainter(self)
        f = QFont(self.font()); f.setPointSize(f.pointSize()); p.setFont(f)
        for i in range(self.count()):
            if not self.isTabVisible(i):
                continue
            r = self.tabRect(i)
            ctx, sel = self.tabData(i) == "ctx", i == self.currentIndex()
            if ctx:
                bg, fg = QColor("#fff4c2" if sel else "#ffd34d"), QColor("#222")
            else:
                bg, fg = QColor("#ffffff" if sel else "#2b2b2b"), QColor("#000000" if sel else "#ffffff")
            if not self.isTabEnabled(i):
                fg = QColor("#777")
            p.fillRect(r, bg)
            p.setPen(fg)
            p.drawText(r, Qt.AlignCenter, self.tabText(i))
        p.end()


class CurveTree(QTreeWidget):
    """Project browser : on peut glisser des variables (ou un dataset) vers un LogView."""
    resolver = None

    ds_resolver = None

    def mimeTypes(self):
        return ["text/plain", DATASETS_MIME]

    def mimeData(self, items):
        refs, seen, keys = [], set(), []
        for it in items:
            for r in (self.resolver(it) if self.resolver else []):
                if tuple(r) not in seen:
                    seen.add(tuple(r)); refs.append(r)
            for k in (self.ds_resolver(it) if self.ds_resolver else []):
                if k not in keys:
                    keys.append(k)
        md = QMimeData()
        md.setText(MIME_PREFIX + json.dumps(refs))
        md.setData(DATASETS_MIME, json.dumps(keys).encode())      # puits / datasets -> Variables splice
        return md


ROLE_TABLE = Qt.UserRole + 5       # nom de la table de depth shift portée par un item du Project browser


class MdiArea(QMdiArea):
    """Zone centrale grise avec le logo quand aucune fenêtre n'est ouverte.
    Glisser une variable du Project browser ici ouvre un nouveau LogView."""
    dropped = Signal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.viewport().setAcceptDrops(True)

    def _ok(self, e):
        return e.mimeData().hasText() and e.mimeData().text().startswith(MIME_PREFIX)

    def dragEnterEvent(self, e):
        if self._ok(e):
            e.acceptProposedAction()

    dragMoveEvent = dragEnterEvent

    def dropEvent(self, e):
        try:
            refs = json.loads(e.mimeData().text()[len(MIME_PREFIX):])
        except ValueError:
            return
        e.acceptProposedAction()
        self.dropped.emit(refs)

    def paintEvent(self, e):
        super().paintEvent(e)
        if not self.subWindowList():
            p = QPainter(self.viewport())
            f = QFont("Arial Narrow", 60); f.setBold(True)
            p.setFont(f); p.setPen(QColor("#8c8c8c"))
            p.drawText(self.viewport().rect(), Qt.AlignCenter, "GeoLog")
            f2 = QFont("Times New Roman", 18); p.setFont(f2); p.setPen(QColor("#222"))
            r = self.viewport().rect().adjusted(14, 0, 0, -14)
            p.drawText(r, Qt.AlignLeft | Qt.AlignBottom, "Created by\nYour name")


class MainWindow(QMainWindow):
    windows = []          # toutes les fenêtres ouvertes

    def __init__(self, project=None):
        super().__init__()
        self.project = None
        self.dirty = False
        self.wells = {}   # clé -> DataFrame
        self.meta = {}    # chemin LAS -> info (well/dataset, clé, courbes)
        self.settings = QSettings("GeoLogApp", "GeoLog")
        self._sel_src = "tree"        # d'où vient la dernière sélection de variable : "tree" | "lv"
        self._sel_lv = None
        self.ctx_idx = {}
        MainWindow.windows.append(self)
        scr = QGuiApplication.primaryScreen().availableGeometry()      # tient toujours dans l'écran
        w0, h0 = min(1400, int(scr.width() * 0.94)), min(820, int(scr.height() * 0.88))
        self.resize(w0, h0)
        self.move(scr.center().x() - w0 // 2, max(scr.top(), scr.center().y() - h0 // 2))

        self.mdi = MdiArea()
        self.mdi.setBackground(QBrush(QColor("#4a4a4a")))
        self.setCentralWidget(self.mdi)
        self.mdi.dropped.connect(self._drop_on_workspace)
        self._create_actions()
        self._build_ribbon()
        self._build_browser()
        self._build_properties()
        self.set_project(project)
        

    # ------------------------------------------------------------ actions
    def _act(self, text, icon, slot, shortcut=None, checkable=False):
        a = QAction(icon if isinstance(icon, QIcon) else self.style().standardIcon(icon), text, self)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        a.setCheckable(checkable)
        a.triggered.connect(slot)
        self.addAction(a)
        return a

    def _create_actions(self):
        S = QStyle
        J = "Ctrl+Shift+J, "
        self.a_new = self._act("New...", S.SP_FileIcon, self.new_project, J + "N")
        self.a_open = self._act("Open...", S.SP_DirOpenIcon, self.open_project, J + "O")
        self.a_save = self._act("Save...", hi.i_save(), self.save, J + "S")
        self.a_saveas = self._act("Save as...", S.SP_DialogSaveButton, self.save_as, "Ctrl+Shift+S")
        self.a_close = self._act("Close...", S.SP_DialogCloseButton, self.close_project, J + "C")
        self.a_import = self._act("Import...", hi.i_import(), self.import_las, J + "I")
        self.a_export = self._act("Export...", hi.i_export(), self.export_csv, J + "E")
        self.a_print = self._act("Print...", hi.i_print(), self._todo, "Ctrl+P, P")
        self.a_options = self._act("Options...", S.SP_FileDialogDetailedView, self._todo, J + "P")
        self.a_exit = self._act("Exit", S.SP_DialogCancelButton, self.exit_app, "Alt+F4")
        self.a_info = self._act("Project information", S.SP_MessageBoxInformation, self.project_info)
        self.a_folder = self._act("Open project folder", S.SP_DirIcon, self.open_folder)
        self.a_about = self._act("About GeoLog", S.SP_MessageBoxInformation, self.about)

        # Plot
        self.a_logview = self._act("LogView", pi.i_logview(), self.new_logview)
        self.a_cross = self._act("Cross-plot", pi.i_scatter(), self.plot_cross)
        self.a_lineplot = self._act("Line-plot", pi.i_lineplot(), self.plot_log)
        self.a_hist = self._act("Histogram", pi.i_hist(), self.plot_hist)
        self.a_xarray = self._act("Cross-plot array", pi.i_scatter_array(), self._todo)
        self.a_box = self._act("Box-plot", pi.i_boxplot(), self._todo)
        self.a_star = self._act("Star-plot", pi.i_star(), self._todo)
        self.a_mw_cross = self._act("Cross-plot ", pi.i_scatter(), self._todo)
        self.a_mw_hist = self._act("Histogram ", pi.i_hist(), self._todo)
        self.a_mw_box = self._act("Box-plot ", pi.i_boxplot(), self._todo)
        self.a_mx_cross = self._act("Cross-plot  ", pi.i_scatter(), self._todo)
        self.a_mx_hist = self._act("Histogram  ", pi.i_hist(), self._todo)

        # ---- onglet Data
        self.a_d_data = self._act("Data\neditor", pi.i_data_editor(), self._todo)
        self.a_d_zone = self._act("Zone\neditor", pi.i_zone_table(), self._todo)
        self.a_d_eq = self._act("Equation\neditor", pi.i_equation(), self._todo)
        self.a_d_array = self._act("Array editor", pi.i_array_editor(), self._todo)
        self.a_d_gzone = self._act("Graphical zone editor", pi.i_zone_editor(), self._todo)
        self.a_d_comb = self._act("Generic\ncombiner", pi.i_combiner(), self._todo)
        self.a_d_splice = self._act("Variables splice tool", pi.i_splice(), self.open_splice_tool)
        self.a_d_resamp = self._act("Resampling tool", pi.i_resampling(), self._todo)
        self.a_d_math = self._act("Math pack", pi.i_mathpack(), self._todo)
        self.a_d_query = self._act("Query rename\ntool", pi.i_query_rename(), self._todo)
        self.a_d_first = self._act("First/Last\nreadings", pi.i_firstlast(), self._todo)
        self.a_d_predict = self._act("Well\npredict", pi.i_wellpredict(), self._todo)
        # ---- onglet contextuel « Graphical variable splice »
        self.a_sp_auto = self._act("Reset\nboundaries", pi.i_sp_auto(), self.sp_reset)
        self.a_sp_save = self._act("Save the\nmerged variable", pi.i_save_vars(), self.sp_save)
        self.a_sp_close = self._act("Close\nwindow", pi.i_sp_close(), self.sp_close)
        # ---- onglet contextuel « Multi well layout »
        self.a_mw_dup = self._act("Duplicate", pi.i_duplicate(), self.mw_duplicate)
        self.a_mw_horiz = self._act("Horizontal", pi.i_horizontal(), self._todo)
        self.a_mw_goto = self._act("Go to\nthe reference", pi.i_goto(), self.mw_goto)
        self.a_mw_grab = self._act("Grab", pi.i_grab(), self.mw_grab)
        self.a_mw_print = self._act("Print", pi.i_print(), self._todo)
        self.a_mw_savevars = self._act("Save the\nmodified variables", pi.i_save_vars(), self.mw_save_vars)
        self.a_mw_refresh = self._act("Refresh\nheader", pi.i_refresh(), self.mw_refresh)
        self.a_mw_reload = self._act("Reload all\nvariables", pi.i_reload(), self.mw_reload)
        self.a_mw_overview = self._act("Well overview", pi.i_overview(), self._todo)
        self.a_mw_lhdr = self._act("Layout header", pi.i_layout_hdr(), lambda: self.mw_toggle("show_layout_header", self.a_mw_lhdr), None, True)
        self.a_mw_whdr = self._act("Well header", pi.i_well_hdr(), lambda: self.mw_toggle("show_well_header", self.a_mw_whdr), None, True)
        self.a_mw_tips = self._act("Tooltips", pi.i_tooltips(), lambda: self.mw_toggle("show_values", self.a_mw_tips), None, True)
        self.a_mw_wcolor = self._act("Wells color", pi.i_wells_color(), self._todo)
        self.a_mw_base = self._act("Baselines", pi.i_baselines(), self._todo)
        # ---- onglet contextuel « Variable »
        self.a_v_reverse = self._act("Reverse the\nboundaries", pi.i_reverse(), self.v_reverse)
        self.a_v_alias = self._act("Create an\nalias", pi.i_alias(), self.v_alias)
        self.a_v_assign = self._act("Assign to\nthe well", pi.i_assign(), self.v_assign)
        self.a_v_shift = self._act("Shifting baseline", pi.i_shift(), self.v_shift)
        self.a_v_edit = self._act("Edit the selected values", pi.i_edit_vals(), self.v_edit_selected)
        self.a_v_del = self._act("Delete selected values", pi.i_del_sel(), self.v_delete_selected)
        self.a_v_delnon = self._act("Delete non-selected values", pi.i_del_non(), self.v_delete_non_selected)
        self.a_v_overview = self._act("As well\noverview", pi.i_overview(), self._todo)
        self.a_v_pal = self._act("Palettes", pi.i_palettes(), self.v_toggle_palette, None, True)
        self.a_v_points = self._act("Points", pi.i_points(), self.v_toggle_points, None, True)
        self.a_v_text = self._act("Text mode", pi.i_textmode(), self._todo)

        # Home
        self.a_screenshot = self._act("Window\nscreenshot", hi.i_camera(), self.screenshot)
        self.a_composer = self._act("Composer", hi.i_composer(), self._todo)
        self.a_header = self._act("Header editor", hi.i_header(), self._todo)
        self.a_batch = self._act("Batch printing", hi.i_batch(), self._todo)
        self.a_report = self._act("Report\neditor", hi.i_report(), self._todo)
        self.a_patterns = self._act("Patterns", hi.i_patterns(), self._todo)
        self.a_symbols = self._act("Symbols", hi.i_symbols(), self._todo)
        self.a_zones = self._act("Zones", hi.i_zones(), self._todo)
        self.a_menus = self._act("Menus", hi.i_menus(), self._todo)
        self.a_full = self._act("Full\nscreen", hi.i_fullscreen(), self.toggle_fullscreen, "F11", True)
        self.a_props = self._act("Properties editor", hi.i_props(), self.toggle_props, None, True)
        self.a_actions = self._act("Actions widget", hi.i_actions(), self._todo, None, True)
        self.a_dash = self._act("Dashboard\nmode", hi.i_dashboard(), self._todo, None, True)
        self.a_tile = self._act("Tile", hi.i_tile(), self.mdi_tile)
        self.a_casc = self._act("Cascade", hi.i_cascade(), self.mdi_cascade)
        self.a_closeall = self._act("Close all windows", S.SP_DialogCloseButton, self.close_subwindows)
        self.a_tileh = self._act("Tile horizontally", hi.i_tile(), lambda: self.mdi_tile("h"))
        self.a_tilev = self._act("Tile vertically", hi.i_tile(), lambda: self.mdi_tile("v"))

        # Variable (onglet contextuel)
        self.a_v_plot = self._act("Plot", hi.i_plot_var(), self.var_plot)
        self.a_v_ds = self._act("Depth shift\nwindow", hi.i_depthshift(), lambda: self.open_depth_shift_vars(self.current_vars()))

        # Depth shift (onglet contextuel)
        self.a_ds_goref = self._act("Go to\nreference", hi.i_goref(), lambda: self._ds("go_to_reference"))
        self.a_ds_load = self._act("Load an\nexisting depth", hi.i_check(), lambda: self._ds("load_table"))
        self.a_ds_table = self._act("The depth\nshift table", hi.i_depthshift(), lambda: self._ds("save_table"))
        self.a_ds_mod = self._act("Modified\nvariables", hi.i_modvars(), lambda: self._ds("save_modified"))
        self.a_ds_auto = self._act("Automatic definition\nof the depth shift", hi.i_auto(), lambda: self._ds("auto_define"))
        self.a_ds_clear = self._act("Remove all\nthe depth shifts", hi.i_removeall(), lambda: self._ds("remove_all"))
        self.a_ds_recovery = self._act("Load a\nrecovery interval", hi.i_recovery(), self._todo)
        self.a_ds_values = self._act("Values", pi.i_values(), lambda on: self._ds("set_values", on), None, True)
        self.a_ds_pos = self._act("Position lines", pi.i_poslines(), lambda on: self._ds("set_poslines", on), None, True)

    # ------------------------------------------------------------- ruban
    STYLE = """
    #ribbon { background:#f4f4f4; }
    #ribbonPage { background:white; border-top:1px solid #c8c8c8; border-bottom:1px solid #c8c8c8; }
    QTabBar::tab { padding:2px 10px; font-size:9pt; background:#2b2b2b; color:white; }
    QTabBar::tab:selected { background:white; color:black; }
    QTabBar::tab:disabled { color:#777; }
    #projBtn { background:#c8102e; color:white; font-weight:bold; padding:3px 12px; border:none; }
    #projBtn::menu-indicator { image:none; }
    #projBtn:pressed, #projBtn:hover { background:#e0233f; }
    #ribbonPage QToolButton { font-size:8pt; padding:1px 2px; }
    #ribbonPage QComboBox { font-size:8pt; }
    QMenu::item { padding:5px 30px 5px 28px; }
    QMenu::item:selected { background:#cfe3f7; color:black; }
    """

    def _icon_btn(self, a, big):
        b = QToolButton()
        b.setDefaultAction(a)
        b.setAutoRaise(True)
        if big:
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setIconSize(QSize(24, 24)); b.setMinimumWidth(max(44, 6 * max(len(l) for l in a.text().split("\n")) + 10))
        else:
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            b.setIconSize(QSize(14, 14))
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        if a.menu():
            b.setPopupMode(QToolButton.InstantPopup)
            b.setText(a.text().replace("\n", " ") + " \u25be" if big and "\n" not in a.text() else a.text() + " \u25be")
        return b

    def big(self, *acts):
        return [self._icon_btn(a, True) for a in acts]

    def col(self, *acts, icons_only=False):
        w = QWidget(); v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        for a in acts:
            b = self._icon_btn(a, False)
            if icons_only:
                b.setToolButtonStyle(Qt.ToolButtonIconOnly); b.setIconSize(QSize(14, 14))
                b.setToolTip(a.text())
            v.addWidget(b)
        v.addStretch()
        return w

    def _group(self, title, widgets):
        box = QWidget()
        v = QVBoxLayout(box); v.setContentsMargins(3, 0, 3, 0); v.setSpacing(0)
        row = QHBoxLayout(); row.setSpacing(2)
        for w in widgets:
            row.addWidget(w)
        v.addLayout(row)
        lbl = QLabel(title); lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet("color:#666; font-size:7pt;")
        v.addWidget(lbl)
        return box

    def _page(self, groups):
        w = QWidget(); w.setObjectName("ribbonPage")
        h = QHBoxLayout(w); h.setContentsMargins(2, 1, 2, 1); h.setSpacing(0)
        for i, g in enumerate(groups):
            if i:
                sep = QFrame(); sep.setFrameShape(QFrame.VLine); sep.setFrameShadow(QFrame.Sunken)
                h.addWidget(sep)
            h.addWidget(g)
        h.addStretch()
        w.setFixedHeight(RIBBON_H)
        sa = QScrollArea(); sa.setObjectName("ribbonScroll")
        sa.setWidget(w); sa.setWidgetResizable(True); sa.setFrameShape(QFrame.NoFrame)
        sa.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sa.setStyleSheet("QScrollArea#ribbonScroll { background:white; border:none; }"
                         "QScrollBar:horizontal { height:8px; background:#eee; }"
                         "QScrollBar::handle:horizontal { background:#aaa; min-width:30px; border-radius:3px; }"
                         "QScrollBar::add-line, QScrollBar::sub-line { width:0; }")
        sa.viewport().setStyleSheet("background:white;")
        sa.setFixedHeight(RIBBON_H + 8)
        return sa

    def _menu_btn(self, text, icon, items):
        m = QMenu(self)
        for lab, slot in items:
            if lab == "-":
                m.addSeparator()
            else:
                m.addAction(lab, slot)
        self._keep = getattr(self, "_keep", []) + [m]
        return self._make_menu_action(text, icon, m)

    def _data_groups(self):
        t = self._todo
        a_tool = self._menu_btn("Toolbox", pi.i_toolbox(), [("Toolbox...", t)])
        a_ref = self._menu_btn("Reference and\ncoordinates", pi.i_refcoords(), [("Reference...", t)])
        a_fam = self._menu_btn("Families", pi.i_families(), [("Families...", t)])
        a_ali = self._menu_btn("Aliases", pi.i_aliases(), [("Aliases...", t)])
        a_mine = self._menu_btn("Quick data\nmining", pi.i_mining(), [("Quick data mining...", t)])
        a_harm = self._menu_btn("Data\nharmonization", pi.i_harmonization(), [("Data harmonization...", t)])
        a_py = self._menu_btn("Python\nscripts", pi.i_python(), [("Python scripts...", t)])
        return [
            self._group("Techdata", self.big(self.a_d_data, self.a_d_zone, self.a_d_eq)
                        + [self.col(self.a_d_array, self.a_d_gzone)] + self.big(self.a_d_comb, a_tool)
                        + [self.col(self.a_d_splice, self.a_d_resamp, self.a_d_math)] + self.big(a_ref)
                        + [self.col(a_fam, a_ali)]),
            self._group("Techdata+", self.big(a_mine, a_harm, self.a_d_query, self.a_d_first, self.a_d_predict, a_py)),
        ]

    def _sp_groups(self):
        return [self._group("Splice", self.big(self.a_sp_auto, self.a_sp_save)),
                self._group("Window", self.big(self.a_sp_close))]

    def _mw_groups(self):
        t = self._todo
        a_apply = self._menu_btn("Apply\nto", pi.i_apply(), [("Style of the selected variable -> same family", self.mw_apply_style)])
        a_well = self._menu_btn("Well", pi.i_well_dl(), [("Add a well...", t)])
        a_save = self._menu_btn("Save", pi.i_save_menu(), [("Save project", self.save), ("Save the modified variables", self.mw_save_vars)])
        a_sprops = self._menu_btn("Save\nProperties", pi.i_save_props(), [("Save the layout properties", t)])
        a_eprops = self._menu_btn("Edit\nProperties", pi.i_edit_props(), [("Open the Properties window", self.show_properties)])
        a_select = self._menu_btn("Select", pi.i_select_menu(), [("Clear selection", self.mw_clear_selection), ("Clear selected interval", self.mw_clear_interval)])
        a_insert = self._menu_btn("", pi.i_insert_grid(), [("Insert...", t)])
        a_adv = self._menu_btn("", pi.i_advanced(), [("Zonation...", t)])
        return [
            self._group("Layout", self.big(self.a_mw_dup, self.a_mw_horiz, a_apply, self.a_mw_goto, a_well)
                        + [self.col(self.a_mw_grab, self.a_mw_print)]),
            self._group("Save", self.big(a_save, a_sprops, self.a_mw_savevars)),
            self._group("Edit", self.big(self.a_mw_refresh, a_eprops, a_select, self.a_mw_reload)),
            self._group("Display", [self.col(self.a_mw_overview, self.a_mw_lhdr, self.a_mw_whdr),
                                    self.col(self.a_mw_tips, self.a_mw_wcolor, self.a_mw_base)]),
            self._group("Insert", self.big(a_insert)),
            self._group("Advanced", self.big(a_adv)),
        ]

    def _var_groups(self):
        t = self._todo
        a_save = self._menu_btn("Save", pi.i_save_menu(), [("Save project", self.save), ("Save the modified variables", self.mw_save_vars)])
        a_harm = self._menu_btn("Harmonized\ndataset", pi.i_harmonized(), [("Harmonize...", t)])
        a_ins = self._menu_btn("", pi.i_insert_var(), [("Insert...", t)])
        proc_menu = QMenu(self)                                  # Processing > Smoothing / Cleaning / ... / Depth Shifting
        self._fill_processing(proc_menu, self.current_vars)
        self._keep = getattr(self, "_keep", []) + [proc_menu]
        a_proc = self._make_menu_action("Processing", hi.i_processing(), proc_menu)
        a_open = self._menu_btn("", pi.i_boxplot(), [("Open in a Box-plot", t), ("Open in a Histogram", self.plot_hist)])
        return [
            self._group("Save", self.big(a_save)),
            self._group("Edit", self.big(self.a_v_reverse, self.a_v_alias, self.a_v_assign, a_harm)
                        + [self.col(self.a_v_shift), self.col(self.a_v_edit, self.a_v_del, self.a_v_delnon)]),
            self._group("Display", self.big(self.a_v_overview) + [self.col(self.a_v_pal, self.a_v_points, self.a_v_text)]),
            self._group("Insert", self.big(a_ins, self.a_v_plot)),
            self._group("Processing", self.big(a_proc)),
            self._group("Open", self.big(a_open, self.a_v_ds)),
        ]

    def _more_menu(self):
        m = QMenu(self)
        for t in ("Cross-plot 3D", "Polar plot", "Ternary plot"):
            m.addAction(t, self._todo)
        self._keep = getattr(self, "_keep", []) + [m]
        return self._make_menu_action("More", pi.i_more(), m)

    def _adv_menu(self):
        m = QMenu(self)
        for t in ("3D viewer", "Stereonet", "Map view"):
            m.addAction(t, self._todo)
        self._keep = getattr(self, "_keep", []) + [m]
        return self._make_menu_action("", pi.i_cube(), m)

    def _make_menu_action(self, text, icon, menu):
        a = QAction(icon if isinstance(icon, QIcon) else self.style().standardIcon(icon), text, self)
        a.setMenu(menu)
        return a

    def _font_group(self):
        S = QStyle
        w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 2, 0, 0); g.setSpacing(3)
        self.font_box = QFontComboBox(); self.font_box.setCurrentFont(QFont("Verdana"))
        self.font_box.setFixedWidth(130)
        self.size_box = QComboBox(); self.size_box.setEditable(True)
        self.size_box.addItems([str(s) for s in (8, 9, 10, 11, 12, 14, 16, 18, 20)])
        self.size_box.setCurrentText("10"); self.size_box.setFixedWidth(55)
        g.addWidget(self.font_box, 0, 0, 1, 4); g.addWidget(self.size_box, 0, 4, 1, 3)
        self.btn_b, self.btn_i, self.btn_u = (QToolButton() for _ in range(3))
        for b, t, st in ((self.btn_b, "B", "font-weight:bold"), (self.btn_i, "I", "font-style:italic"),
                         (self.btn_u, "U", "text-decoration:underline")):
            b.setText(t); b.setCheckable(True); b.setStyleSheet(st); b.setAutoRaise(True)
            b.toggled.connect(self.apply_font)
        grp = QButtonGroup(w); grp.setExclusive(True)
        aligns = []
        for t in ("⯇", "≡", "⯈", "☰"):
            b = QToolButton(); b.setText(t); b.setCheckable(True); b.setAutoRaise(True)
            grp.addButton(b); aligns.append(b)
        aligns[0].setChecked(True)
        self.btn_color = QToolButton(); self.btn_color.setText("A"); self.btn_color.setAutoRaise(True)
        self.btn_color.setStyleSheet("font-weight:bold; text-decoration:underline; color:#c8102e")
        self.btn_color.clicked.connect(self.pick_color)
        for i, b in enumerate([self.btn_b, self.btn_i, self.btn_u] + aligns + [self.btn_color]):
            g.addWidget(b, 1, i)
        self.font_box.currentFontChanged.connect(self.apply_font)
        self.size_box.currentTextChanged.connect(self.apply_font)
        return w

    def _build_ribbon(self):
        # ---- menu du bouton Project (liste de commandes + raccourcis)
        S = QStyle
        m = QMenu(self)
        for a in (self.a_new, self.a_open, self.a_save, self.a_saveas, self.a_close):
            m.addAction(a)
        m.addSeparator()
        self.recent_menu = m.addMenu(self.style().standardIcon(S.SP_FileDialogDetailedView),
                                     "Recent projects")
        self.recent_menu.aboutToShow.connect(self._fill_recent)
        m.addSeparator(); m.addAction(self.a_import); m.addAction(self.a_export)
        m.addSeparator()
        mu = m.addMenu(self.style().standardIcon(S.SP_DirIcon), "Project utilities")
        mu.addAction(self.a_info); mu.addAction(self.a_folder)
        ml = m.addMenu(self.style().standardIcon(S.SP_MessageBoxInformation), "Licensing")
        ml.addAction(self.a_about)
        m.addSeparator(); m.addAction(self.a_print)
        m.addSeparator(); m.addAction(self.a_options)
        m.addSeparator(); m.addAction(self.a_exit)

        btn = QToolButton(); btn.setText("Project"); btn.setObjectName("projBtn")
        btn.setMenu(m); btn.setPopupMode(QToolButton.InstantPopup)

        # ---- menus des boutons du ruban
        dock_menu = QMenu(self)
        tile_menu = QMenu(self)
        for a in (self.a_tile, self.a_tileh, self.a_tilev):
            tile_menu.addAction(a)
        misc_menu = QMenu(self); misc_menu.addAction(self.a_casc); misc_menu.addAction(self.a_closeall)
        self.win_menu = QMenu(self); self.win_menu.aboutToShow.connect(self._fill_windows)
        batch_menu = QMenu(self); batch_menu.addAction("Print all layouts", self._todo)
        self._dock_menu = dock_menu

        self.a_batch.setMenu(batch_menu)
        a_dock = self._make_menu_action("Dock windows", hi.i_dock(), dock_menu)
        a_tilem = self._make_menu_action("Tile", hi.i_tile(), tile_menu)
        a_misc = self._make_menu_action("Miscellaneous", hi.i_cascade(), misc_menu)
        a_win = self._make_menu_action("Windows", hi.i_windows(), self.win_menu)
        a_s1 = self._act("Save layout", hi.i_save_layout(), self._todo)
        a_s2 = self._act("Reset layout", hi.i_reset_layout(), self._todo)
        a_s3 = self._act("Layout manager", hi.i_layout_mgr(), self._todo)

        home = [
            self._group("Project", self.big(self.a_save, self.a_import, self.a_export, self.a_print)),
            self._group("Techreport", self.big(self.a_screenshot) +
                        [self.col(self.a_composer, self.a_header, self.a_batch)] + self.big(self.a_report)),
            self._group("Font", [self._font_group()]),
            self._group("Tools", self.big(self.a_patterns, self.a_symbols, self.a_zones, self.a_menus)),
            self._group("View", self.big(self.a_full) +
                        [self.col(self.a_props, self.a_actions, a_dock), self.col(a_s1, a_s2, a_s3, icons_only=True)]),
            self._group("Window", self.big(self.a_dash, a_tilem, a_misc, a_win)),
        ]
        pages = {
            "Home": home,
            "Plot": [
                self._group("Layout", self.big(self.a_logview)),
                self._group("Single well", self.big(self.a_cross, self.a_lineplot, self.a_hist) +
                            [self.col(self.a_xarray, self.a_box, self.a_star)] + self.big(self._more_menu())),
                self._group("Multi-well", self.big(self.a_mw_cross, self.a_mw_hist, self.a_mw_box,
                                                   self._more_menu())),
                self._group("Matrix-plot", self.big(self.a_mx_cross, self.a_mx_hist, self._more_menu())),
                self._group("Advanced plotting", self.big(self._adv_menu())),
            ],
            "Data": self._data_groups(),
        }

        # ---- onglet contextuel « Depth shift » (fenêtre Depth shift active) ; « Variable » est construit dans _var_groups
        sel_menu = QMenu(self)
        sel_menu.addAction("Reference variable...", lambda: self._ds("choose_reference"))
        a_sel = self._make_menu_action("Select", hi.i_select_grid(), sel_menu)
        self._keep = getattr(self, "_keep", []) + [sel_menu]
        ctx_pages = [
            ("Depth shift", [
                self._group("Depth shift", self.big(self.a_ds_goref, self.a_ds_load)),
                self._group("Save", self.big(self.a_ds_table, self.a_ds_mod)),
                self._group("Edit", self.big(a_sel, self.a_ds_auto, self.a_ds_clear, self.a_ds_recovery)),
                self._group("Display", [self.col(self.a_ds_values, self.a_ds_pos)]),
            ]),
        ]

        self.tabbar = RibbonTabBar(); self.tabbar.setExpanding(False); self.tabbar.setDrawBase(False)
        self.stack = QStackedWidget()
        for name in TABS:
            self.tabbar.addTab(name)
            if name in pages:
                self.stack.addWidget(self._page(pages[name]))
            else:
                ph = QLabel(f"   {name}: à venir"); ph.setObjectName("ribbonPage"); ph.setFixedHeight(RIBBON_H + 8)
                self.stack.addWidget(ph)
        # onglets contextuels jaunes (cachés tant qu'ils ne servent pas)
        self.tab_mw = self.tabbar.addTab("Multi well layout")
        self.stack.addWidget(self._page(self._mw_groups()))
        self.tab_var = self.tabbar.addTab("Variable")
        self.stack.addWidget(self._page(self._var_groups()))
        self.tab_sp = self.tabbar.addTab("Graphical variable splice")
        self.stack.addWidget(self._page(self._sp_groups()))
        for name, groups in ctx_pages:
            i = self.tabbar.addTab(name)
            self.tabbar.setTabData(i, "ctx")
            self.stack.addWidget(self._page(groups))
            self.ctx_idx[name] = i
            self.tabbar.setTabVisible(i, False)
        for i in (self.tab_mw, self.tab_var, self.tab_sp):
            self.tabbar.setTabData(i, "ctx"); self.tabbar.setTabVisible(i, False)
        self.tabbar.currentChanged.connect(self.stack.setCurrentIndex)

        top = QWidget(); top.setObjectName("ribbon"); top.setStyleSheet(self.STYLE)
        v = QVBoxLayout(top); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        bar = QWidget(); bar.setStyleSheet("background:#2b2b2b;")
        h = QHBoxLayout(bar); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(0)
        h.addWidget(btn); h.addWidget(self.tabbar); h.addStretch()
        v.addWidget(bar); v.addWidget(self.stack)
        dock = QDockWidget(); dock.setTitleBarWidget(QWidget())
        dock.setWidget(top); dock.setFeatures(QDockWidget.NoDockWidgetFeatures)
        self.addDockWidget(Qt.TopDockWidgetArea, dock)

    def _build_browser(self):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(2, 2, 2, 2); h.setSpacing(2)

        # --- colonne gauche : le projet
        left = QWidget(); v = QVBoxLayout(left); v.setContentsMargins(0, 0, 0, 0)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search")
        self.search.textChanged.connect(lambda t: filter_tree(self.tree, t))
        self.tree = CurveTree(); self.tree.resolver = self.curve_refs; self.tree.ds_resolver = self.dataset_keys_of
        self.tree.setDragEnabled(True); self.tree.setDragDropMode(QAbstractItemView.DragOnly)
        self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Name", "Family"])
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(self._tree_double_click)
        self.tree.itemSelectionChanged.connect(self._tree_selection_changed)
        self.btn_trash = _tool(trash_icon(), "Delete selected from project", 20)
        self.btn_trash.clicked.connect(self.delete_selected)
        v.addWidget(self.search); v.addWidget(self.tree)
        v.addWidget(self.btn_trash, 0, Qt.AlignLeft)

        # --- colonne milieu : X (fermer l'import) et flèche (transférer)
        self.mid = QWidget(); m = QVBoxLayout(self.mid); m.setContentsMargins(0, 0, 0, 0)
        bx = _tool(close_icon(), "Close import panel", 20); bx.clicked.connect(self.close_import)
        self.btn_transfer = _tool(arrow_left_icon(), "Transfer to project", 28)
        self.btn_transfer.clicked.connect(self.transfer_import)
        m.addWidget(bx); m.addStretch(); m.addWidget(self.btn_transfer); m.addStretch()

        # --- colonne droite : le container d'import
        self.import_panel = ImportPanel()
        self.import_panel.is_known = lambda p: bool(self.project) and p in {
            os.path.normpath(x) for x in self.project.datasets}

        h.addWidget(left, 1); h.addWidget(self.mid); h.addWidget(self.import_panel, 1)
        self.mid.hide(); self.import_panel.hide()

        self.browser_dock = QDockWidget("Project browser")
        self.browser_dock.setWidget(w)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.browser_dock)
        self._dock_menu.addAction(self.browser_dock.toggleViewAction())

    def curve_refs(self, item):
        """[[dataset_key, courbe], ...] porté par un item du Project browser."""
        key = item.data(0, Qt.UserRole)
        if key in self.wells:                                  # un dataset entier
            return [[key, str(c)] for c in self.wells[key].columns]
        par = item.parent()
        if par is not None:
            k = par.data(0, Qt.UserRole)
            if k in self.wells and item.text(0) in self.wells[k].columns:
                return [[k, item.text(0)]]
        return []

    def _tree_double_click(self, item, _col):
        table = item.data(0, ROLE_TABLE)
        if table:                                              # table de depth shift -> appliquée à la fenêtre active
            w = self.active_depthshift()
            if w is None:
                QMessageBox.information(self, APP, "Open a Depth shift window first "
                                        "(select 2 variables in a LogView, right-click, Depth shift window).")
            else:
                w.load_table(table)
            return
        key = item.data(0, Qt.UserRole)
        if key in self.wells:                                  # dataset -> LogView automatique
            self.open_dataset_logview(key)
            return
        refs = self.curve_refs(item)
        if refs:                                               # courbe -> ajoutée au LogView actif
            lv = self.active_logview() or self.new_logview()
            if lv:
                lv.add_refs(refs, -1)

    def _build_properties(self):
        self.props = QTableWidget(0, 2)
        self.props.horizontalHeader().setVisible(False); self.props.verticalHeader().setVisible(False)
        self.props.horizontalHeader().setStretchLastSection(True)
        self.var_panel = PropertiesPanel()
        self.props_stack = QStackedWidget()
        self.props_stack.addWidget(self.props)          # page 0 : infos du projet
        self.props_stack.addWidget(self.var_panel)      # page 1 : variable sélectionnée
        self.layout_panel = LayoutPanel()
        self.props_stack.addWidget(self.layout_panel)   # page 2 : layout (Limits | Wells | Display options)
        self.mdi.subWindowActivated.connect(self._on_subwindow_activated)
        self.props_dock = QDockWidget("Properties")
        self.props_dock.setWidget(self.props_stack)
        self.addDockWidget(Qt.RightDockWidgetArea, self.props_dock)
        self.props_dock.hide()
        self.props_dock.visibilityChanged.connect(self.a_props.setChecked)
        self._dock_menu.addAction(self.props_dock.toggleViewAction())

    def _refresh_props(self):
        p = self.project
        rows = [] if not p else [("Name", p.name), ("Folder", p.folder), ("Status", p.status),
                                 ("Mode", p.mode), ("Units", p.units), ("Wells", str(len(self.wells)))]
        self.props.setRowCount(len(rows))
        for i, (k, val) in enumerate(rows):
            self.props.setItem(i, 0, QTableWidgetItem(k)); self.props.setItem(i, 1, QTableWidgetItem(val))

    def _tree_state(self):
        out = set()
        def walk(it, path):
            path = path + (it.text(0),)
            if it.isExpanded():
                out.add(path)
            for i in range(it.childCount()):
                walk(it.child(i), path)
        for i in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(i), ())
        return out

    def _restore_tree_state(self, state):
        def walk(it, path):
            path = path + (it.text(0),)
            if path in state:
                it.setExpanded(True)
            for i in range(it.childCount()):
                walk(it.child(i), path)
        for i in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(i), ())

    def _reveal(self, key, name):
        """Déplie l'arbre jusqu'à la variable (key, name) et la fait défiler dans la vue."""
        def walk(it):
            par = it.parent()
            if par is not None and par.data(0, Qt.UserRole) == key and it.text(0) == name:
                return it
            for i in range(it.childCount()):
                r = walk(it.child(i))
                if r is not None:
                    return r
            return None
        for i in range(self.tree.topLevelItemCount()):
            it = walk(self.tree.topLevelItem(i))
            if it is not None:
                par = it.parent()
                while par is not None:
                    par.setExpanded(True); par = par.parent()
                self.tree.scrollToItem(it)
                self.tree.setCurrentItem(it)
                return

    def _refresh_tree(self, reveal=None):
        state = self._tree_state()
        self.tree.clear()
        if not self.project:
            return
        root = QTreeWidgetItem([self.project.name])
        self.tree.addTopLevelItem(root)
        ds = None
        for n in ("Datasets", "Depth shifts", "Layouts", "Cross-plots", "Python scripts"):
            node = QTreeWidgetItem(root, [n])
            if n == "Datasets":
                ds = node
                infos = [self.meta[p] for p in self.project.datasets if p in self.meta]
                infos += [self.meta[v["path"]] for v in self.project.virtual.values() if v["path"] in self.meta]
                fill_groups(node, infos, with_curves=True)
            elif n == "Depth shifts":
                for name, t in self.project.depth_shifts.items():
                    it = QTreeWidgetItem(node, [name])
                    it.setData(0, ROLE_TABLE, name)
                    it.setToolTip(0, f"Reference: {t.get('reference', '?')}\n"
                                     f"Shifted: {', '.join(t.get('variables', []))}\n"
                                     f"{len(t.get('anchors', []))} point(s) - double-click to apply in the Depth shift window")
                    for a, b in t.get("anchors", []):
                        QTreeWidgetItem(it, [f"{a:.2f}  ->  {b:.2f}   ({b - a:+.2f})"])
                node.setExpanded(bool(self.project.depth_shifts))
        root.setExpanded(True)
        ds.setExpanded(True)
        self._restore_tree_state(state)
        if reveal:
            self._reveal(*reveal)

    # ------------------------------------------- fonctions du ruban Home
    def apply_font(self, *_):
        f = QFont(self.font_box.currentFont())
        try:
            f.setPointSize(int(self.size_box.currentText()))
        except ValueError:
            pass
        f.setBold(self.btn_b.isChecked()); f.setItalic(self.btn_i.isChecked())
        f.setUnderline(self.btn_u.isChecked())
        self.tree.setFont(f)

    def pick_color(self):
        c = QColorDialog.getColor(parent=self)
        if c.isValid():
            self.tree.setStyleSheet(f"QTreeWidget {{ color:{c.name()}; }}")

    def screenshot(self):
        path, _ = QFileDialog.getSaveFileName(self, "Window screenshot", "screenshot.png", "PNG (*.png)")
        if path:
            self.grab().save(path)

    def toggle_fullscreen(self):
        self.showFullScreen() if self.a_full.isChecked() else self.showNormal()

    def toggle_props(self):
        self.props_dock.setVisible(self.a_props.isChecked())

    def _fill_windows(self):
        self.win_menu.clear()
        subs = self.mdi.subWindowList()
        if not subs:
            self.win_menu.addAction("(no window)").setEnabled(False)
        for s in subs:
            self.win_menu.addAction(s.windowTitle(), lambda s=s: self.mdi.setActiveSubWindow(s))

    def close_subwindows(self):
        for s in self.mdi.subWindowList():
            s.close()

    def project_info(self):
        p = self.project
        if p:
            QMessageBox.information(self, APP, f"Name: {p.name}\nFile: {p.path}\nStatus: {p.status}\n"
                                    f"Mode: {p.mode}\nUnits: {p.units}\nDatasets: {len(p.datasets)}")

    def open_folder(self):
        if self.project:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.project.project_dir))

    def about(self):
        QMessageBox.about(self, APP, "GeoLog 1.0\nGeophysics / petrophysics desktop software.")

    def export_csv(self):
        if not self._need_wells():
            return
        well = self._pick("Well to export", list(self.wells))
        if well:
            path, _ = QFileDialog.getSaveFileName(self, "Export", f"{well}.csv", "CSV (*.csv)")
            if path:
                self.wells[well].to_csv(path)

# ----------------------------------------------------- état du projet
    def set_project(self, project):
        self.project = project
        self.dirty = False
        self.wells = {}
        self.meta = {}
        if project:
            project.datasets = [os.path.normpath(p) for p in project.datasets]
        for sub in self.mdi.subWindowList():
            sub.close()
        self.var_panel.set_curve(None); self.layout_panel.set_view(None)
        self.props_stack.setCurrentIndex(0); self._panel_owner = None; self._mw_counter = 0
        if project:
            for p in project.datasets:
                self._load_las(p, register=False)
            self._load_derived()
            self._load_virtual()
            self._add_recent(project.path)
        self.stack.setEnabled(project is not None)
        for a in (self.a_save, self.a_saveas, self.a_close, self.a_import, self.a_export,
                  self.a_print, self.a_info, self.a_folder):
            a.setEnabled(project is not None)
        self._refresh_tree()
        self._refresh_props()
        self.update_title()
        self.update_context_tabs()

    def update_title(self):
        if not self.project:
            self.setWindowTitle(f"{APP} - no project")
            return
        p = self.project
        star = " *" if self.dirty else ""
        self.setWindowTitle(f"{APP} 1.0 | Project: {p.name}{star} | Status: {p.status} "
                            f"| Workspace: {APP} workspace")

    def set_dirty(self, d=True):
        self.dirty = d
        self.update_title()

    def maybe_save(self):
        """True si on peut continuer (sauvé ou ignoré), False si annulé."""
        if not (self.project and self.dirty):
            return True
        box = QMessageBox(QMessageBox.Question, APP,
                          f'Do you want to save changes to the project "{self.project.name}"?',
                          parent=self)
        save = box.addButton("Save", QMessageBox.AcceptRole)
        dont = box.addButton("Don't save", QMessageBox.DestructiveRole)
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is save:
            return self.save()
        return box.clickedButton() is dont

    # ------------------------------------------------- actions du menu Project
    def new_project(self):
        wiz = NewProjectWizard(self.settings.value("folder", DEFAULT_FOLDER), self)
        if wiz.exec() != NewProjectWizard.Accepted:
            return
        proj = wiz.project()
        proj.save()
        self.settings.setValue("folder", proj.folder)
        self._show_project(proj)

    def open_project(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open project", self.settings.value("folder", DEFAULT_FOLDER),
            f"GeoLog project (*{EXT})")
        if path:
            self.open_path(path)

    def open_path(self, path):
        try:
            proj = Project.load(path)
        except Exception as e:
            QMessageBox.critical(self, APP, f"Cannot open project:\n{e}")
            return
        self._show_project(proj)

    def _show_project(self, proj):
        """Comme Word/Excel : fenêtre vide -> on l'utilise ; sinon on demande."""
        if self.project is None:
            self.set_project(proj)
            return
        box = QMessageBox(QMessageBox.Question, APP,
                          f'The project "{self.project.name}" is already open.\n\n'
                          "Do you want to replace the current project or open the "
                          f"project into a new {APP}?", parent=self)
        rep = box.addButton("Replace the current", QMessageBox.AcceptRole)
        new = box.addButton(f"Open inside new {APP}", QMessageBox.ActionRole)
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is rep:
            if self.maybe_save():
                self.set_project(proj)
        elif box.clickedButton() is new:
            w = MainWindow(proj)
            w.show()

    def save(self):
        if not self.project:
            return False
        try:
            self.project.save()
            self._write_derived()
        except Exception as e:
            QMessageBox.critical(self, APP, f"Cannot save:\n{e}")
            return False
        self.set_dirty(False)
        self.statusBar().showMessage("Project saved", 3000)
        return True

    def save_as(self):
        if not self.project:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save project as", self.project.default_path(),
                                              f"GeoLog project (*{EXT})")
        if path:
            self.project.name = Path(path).stem
            self.project.folder = str(Path(path).parent.parent)
            self.project.save(path)
            self._write_derived()
            self._add_recent(path)
            self._refresh_tree()
            self.set_dirty(False)

    def close_project(self):
        if self.maybe_save():
            self.set_project(None)

    def exit_app(self):
        for w in list(MainWindow.windows):
            if not w.close():
                break

    def closeEvent(self, e):
        if self.maybe_save():
            MainWindow.windows.remove(self)
            e.accept()
        else:
            e.ignore()

    # ------------------------------------------------------- projets récents
    def _recent(self):
        r = self.settings.value("recent", [])
        return [r] if isinstance(r, str) else list(r or [])

    def _add_recent(self, path):
        if not path:
            return
        r = [p for p in self._recent() if p != path]
        self.settings.setValue("recent", ([path] + r)[:10])

    def _fill_recent(self):
        self.recent_menu.clear()
        items = [p for p in self._recent() if os.path.exists(p)]
        if not items:
            self.recent_menu.addAction("(none)").setEnabled(False)
        for p in items:
            self.recent_menu.addAction(p, lambda p=p: self.open_path(p))

    # ------------------------------------------------------- données LAS
    def import_las(self):
        """Ouvre le container d'import à droite du Project browser."""
        if not self.project:
            return
        self.mid.show(); self.import_panel.show()
        self.browser_dock.setMinimumWidth(720)
        self.resizeDocks([self.browser_dock], [760], Qt.Horizontal)

    def close_import(self):
        self.mid.hide(); self.import_panel.hide()
        self.browser_dock.setMinimumWidth(0)
        self.resizeDocks([self.browser_dock], [260], Qt.Horizontal)

    def transfer_import(self):
        """Flèche : container d'import -> projet."""
        paths = self.import_panel.selected_paths()
        if not paths:
            self.statusBar().showMessage("Select the data to transfer first", 3000)
            return
        ok = []
        for p in paths:
            if self._load_las(p):
                self.project.datasets.append(p)
                ok.append(p)
        n = len(ok)
        self.import_panel.remove_paths(ok)     # les fichiers en erreur restent dans le container
        if n:
            self.set_dirty()
        self._refresh_tree(); self._refresh_props()
        self.statusBar().showMessage(f"{n} dataset(s) transferred to the project", 4000)

    def _splice_derived(self, key, name):
        """Entrées de project.derived (variables « nouvelle version » GR_2...) correspondant à (dataset, nom)."""
        info = self._info_of(key)
        if not info:
            return []
        p = os.path.normpath(info["path"])
        return [d for d in self.project.derived if os.path.normpath(d["path"]) == p and d["name"] == name]

    def _delete_variables(self, items):
        """Corbeille sur des variables seules : on ne supprime que celles créées dans GeoLog
        (smoothing, depth shift, nouvelles versions, splice) ; les courbes des LAS d'origine sont protégées."""
        todo = []
        for it in items:
            key = it.parent().data(0, Qt.UserRole)
            name = it.text(0)
            if (name in self.project.derived_cols.get(key, {}) or self._splice_derived(key, name) or (
                    name != "MD" and name in self.project.virtual.get(key, {}).get("columns", {}))):
                todo.append((key, name))
        if not todo:
            self.statusBar().showMessage("Only variables created in GeoLog can be deleted "
                                         "(select the dataset to remove the original data).", 6000)
            return
        if QMessageBox.question(self, APP, "Delete %d variable(s) created in GeoLog?\n\n%s" % (
                len(todo), "\n".join(n for _, n in todo))) != QMessageBox.Yes:
            return
        for key, name in todo:
            df = self.wells.get(key)
            if df is not None and name in df.columns:
                df.drop(columns=[name], inplace=True)
            info = self._info_of(key)
            if info:
                info["curves"] = [c for c in info["curves"] if c["mnemonic"] != name]
            for d in self._splice_derived(key, name):
                self.project.derived.remove(d)
                try:
                    os.remove(os.path.join(self.project.project_dir, d["file"]))
                except OSError:
                    pass
            self.project.derived_cols.get(key, {}).pop(name, None)
            self.project.virtual.get(key, {}).get("columns", {}).pop(name, None)
        self.set_dirty(); self._refresh_tree()

    def delete_selected(self):
        sel = self.tree.selectedItems()
        tables = [it.data(0, ROLE_TABLE) for it in sel if it.data(0, ROLE_TABLE)]
        if tables:
            if QMessageBox.question(self, APP, "Delete the depth shift table(s)?\n\n" + "\n".join(tables)) == QMessageBox.Yes:
                for t in tables:
                    self.project.depth_shifts.pop(t, None)
                self.set_dirty(); self._refresh_tree()
            return
        if sel and all(it.parent() is not None and it.parent().data(0, Qt.UserRole) in self.wells for it in sel):
            self._delete_variables(sel)
            return
        paths = {p for it in self.tree.selectedItems() for p in paths_of(it)}
        if not paths:
            return
        if QMessageBox.question(self, APP, f"Remove {len(paths)} dataset(s) from the project?"
                                ) != QMessageBox.Yes:
            return
        for p in paths:
            info = self.meta.pop(p, None)
            if info:
                self.wells.pop(info["key"], None)
            for vk in [k for k, v in self.project.virtual.items() if v["path"] == p]:
                del self.project.virtual[vk]
            if p in self.project.datasets:
                self.project.datasets.remove(p)
        gone = {os.path.normpath(x) for x in paths}
        self.project.derived = [d for d in self.project.derived if os.path.normpath(d["path"]) not in gone]
        self.set_dirty(); self._refresh_tree(); self._refresh_props()

    def _load_las(self, path, register=True):
        path = os.path.normpath(path)
        try:
            import lasio
            df = lasio.read(path, mnemonic_case="preserve").df()
        except ImportError:
            QMessageBox.warning(self, APP, "Install lasio:  pip install lasio")
            return False
        except Exception as e:
            QMessageBox.warning(self, APP, f"Cannot read {path}:\n{e}")
            return False
        info = las_info.read_info_safe(path)
        key, n = info["stem"], 2
        while key in self.wells:           # deux fichiers de même nom, dossiers différents
            key = f'{info["stem"]} ({n})'; n += 1
        info["key"] = key
        if self.project:                            # variables créées dans le projet (GR_2...)
            for d in self.project.derived:
                f = os.path.join(self.project.project_dir, d["file"])
                if os.path.normpath(d["path"]) != path or not os.path.exists(f):
                    continue
                try:
                    sv = pd.read_csv(f)
                    if len(sv) == len(df) and np.allclose(sv["depth"].values, df.index.values, equal_nan=True):
                        df[d["name"]] = sv["value"].values
                    else:
                        ser = pd.Series(sv["value"].values, index=sv["depth"].values)
                        df[d["name"]] = ser[~ser.index.duplicated()].reindex(df.index).values
                    info["curves"].append({"mnemonic": d["name"], "unit": d.get("unit", ""), "descr": "derived",
                                           "family": d.get("family", ""), "derived": True})
                except Exception:
                    pass
        self.meta[path] = info
        self.wells[key] = df
        return True

    # ------------------------------------------------- Variables splice
    def dataset_keys_of(self, item):
        keys = []
        for path in paths_of(item):
            info = self.meta.get(os.path.normpath(path))
            if info and info.get("key") in self.wells and info["key"] not in keys:
                keys.append(info["key"])
        return keys

    def dataset_info(self, key):
        """Résumé d'un dataset du projet pour les outils (splice...)."""
        df = self.wells.get(key)
        info = next((i for i in self.meta.values() if i.get("key") == key), None)
        if df is None or info is None:
            return None
        du = info["curves"][0]["unit"] if info["curves"] else ""
        return {"key": key, "name": info["name"], "path": info["path"], "df": df,
                "well": info["group"] if info["kind"] == las_info.WELL else "",
                "depth_unit": "ft" if str(du).upper().startswith("F") else "M",
                "units": {c["mnemonic"]: c["unit"] for c in info["curves"]}}

    def open_splice_tool(self):
        if not self.project:
            return
        w = SpliceToolWidget(self)
        sub = QMdiSubWindow(); sub.setWidget(w); sub.setAttribute(Qt.WA_DeleteOnClose)
        sub.setWindowTitle(w.window_title())
        w.titleChanged.connect(sub.setWindowTitle)
        self.mdi.addSubWindow(sub)
        sub.resize(max(500, min(980, self.mdi.width() - 20)), max(320, min(560, self.mdi.height() - 20)))
        sub.move(8, 8)
        sub.show()
        return w

    def open_splice_graphs(self, tool, rows):
        for row in rows[:4]:
            w = SpliceGraphWidget(self, tool, row, tool.spec())
            w.curveSelected.connect(lambda obj, w=w: self.on_curve_selected(obj, w))
            sub = QMdiSubWindow(); sub.setWidget(w); sub.setAttribute(Qt.WA_DeleteOnClose)
            sub.setWindowTitle(w.window_title())
            w.destroyed.connect(lambda *_, w=w: self._logview_closed(w))
            self.mdi.addSubWindow(sub)
            sub.resize(max(520, min(820, self.mdi.width() - 20)), max(320, min(640, self.mdi.height() - 20)))
            sub.move(8, 8)
            sub.show()
        if len(rows) > 4:
            self.toast("Only the first 4 variables are displayed graphically.")

    def save_merged(self, spec, rows):
        """Écrit le dataset de sortie (LAS dans le dossier du projet) et le recharge dans le Project browser."""
        import lasio
        if not self.project:
            return
        step = float(spec["step"])
        grid = sp.make_grid(rows, step)
        if grid.size < 2:
            QMessageBox.information(self, APP, "Nothing to save: empty depth interval."); return
        cols = {}
        for r in rows:
            data = []
            for seg in r.segs:
                info = self.dataset_info(seg.key)
                col = next(c for c in info["df"].columns if str(c) == seg.var)
                data.append(sp.sorted_series(info["df"], col))
            cols[r.out_name] = (sp.merge_row(r, grid, lambda i, data=data: data[i]), r.out_unit or "")
        folder = os.path.join(self.project.project_dir, "datasets")
        os.makedirs(folder, exist_ok=True)
        path = os.path.normpath(os.path.join(folder, re.sub(r"[^A-Za-z0-9_. -]+", "_", spec["name"]) + ".las"))
        existed = os.path.exists(path)
        if existed:                                    # même dataset : on garde les variables d'avant si la grille est la même
            try:
                old = lasio.read(path, mnemonic_case="preserve")
                od = np.asarray(old.index, float)
                if len(od) == len(grid) and np.allclose(od, grid):
                    for c in old.curves[1:]:
                        if c.mnemonic not in cols:
                            cols[c.mnemonic] = (np.asarray(c.data, float), c.unit)
            except Exception:
                pass
        du = "F" if str(spec["depth_unit"]).lower().startswith("f") else "M"
        las = lasio.LASFile()
        las.well["WELL"].value = spec.get("well") or spec["name"]
        las.append_curve("MD", grid, unit=du, descr="Measured depth")
        for name, (vals, unit) in cols.items():
            las.append_curve(name, vals, unit=unit, descr="spliced variable")
        las.write(path, version=2.0)
        # recharger comme n'importe quel dataset du projet
        old_info = self.meta.pop(path, None)
        if old_info:
            self.wells.pop(old_info.get("key"), None)
        if self._load_las(path):
            if path not in [os.path.normpath(p) for p in self.project.datasets]:
                self.project.datasets.append(path)
            self.set_dirty(); self._refresh_tree(); self._refresh_props()
        if existed:
            self.toast(f"The dataset {spec['name']} already exists. The variables will be saved with the option "
                       "overwrite")
        self.statusBar().showMessage(f"Dataset {spec['name']} saved ({', '.join(cols)})", 5000)

    def _active_splice(self):
        lv = self._strict_logview()
        return lv if isinstance(lv, SpliceGraphWidget) else None

    def sp_reset(self):
        w = self._active_splice()
        if w:
            w.reset_bounds()

    def sp_save(self):
        w = self._active_splice()
        if w:
            self.save_merged(w.spec, [w.row])

    def sp_close(self):
        sub = self.mdi.activeSubWindow()
        if sub:
            sub.close()

    def toast(self, text):
        """Petite notification « Warnings » en bas à droite (comme Techlog)."""
        if not hasattr(self, "_toast"):
            self._toast = Toast(self)
        self._toast.show_message(text)

    # ---------------------------------------------------------- LogView
    FAM_TRACK = {"Gamma Ray": 0, "Spontaneous Potential": 0, "Caliper": 0, "Resistivity": 1,
                 "Bulk Density": 2, "Neutron Porosity": 2, "Photoelectric Factor": 2, "Sonic": 3}

    def new_logview(self):
        if not self.project:
            return None
        lv = LogViewWidget(self.make_curve)
        lv.index = self._mw_counter; self._mw_counter += 1
        sub = QMdiSubWindow(); sub.setWidget(lv); sub.setAttribute(Qt.WA_DeleteOnClose)
        sub.setWindowTitle(lv.window_title())
        lv.curveSelected.connect(lambda obj, lv=lv: self.on_curve_selected(obj, lv))
        lv.canvas.extra_menu = lambda menu, curves, lv=lv: self._lv_context_menu(menu, curves, lv)
        lv.styleChanged.connect(lambda: self.var_panel.refresh())
        lv.canvas.viewChanged.connect(lambda: sub.setWindowTitle(lv.window_title()))
        lv.destroyed.connect(lambda *_, lv=lv: self._logview_closed(lv))
        self.mdi.addSubWindow(sub)
        sub.resize(max(400, min(900, self.mdi.width() - 20)), max(300, min(640, self.mdi.height() - 20)))
        sub.show()
        lv.canvas.setFocus()
        return lv

    def active_logview(self):
        """Dernier LogView « normal » (ni fenêtre Depth shift, ni graphique de splice)."""
        ok = lambda w: isinstance(w, LogViewWidget) and not isinstance(w, (DepthShiftWidget, SpliceGraphWidget))
        sub = self.mdi.activeSubWindow()
        if sub and ok(sub.widget()):
            return sub.widget()
        for s in reversed(self.mdi.subWindowList()):
            if ok(s.widget()):
                return s.widget()
        return None

    def make_curve(self, key, name, color_index=0):
        df = self.wells.get(key)
        if df is None or name not in df.columns:
            return None
        depth = df.index.values.astype(float)
        vals = df[name].values.astype(float)
        info = next((i for i in self.meta.values() if i.get("key") == key), None)
        unit = fam = well = ""
        dsname = key
        if info:
            cur = next((c for c in info["curves"] if c["mnemonic"].upper() == str(name).upper()), None)
            if cur:
                unit, fam = cur["unit"], cur["family"]
            if info["kind"] == las_info.WELL:
                well = info["group"]
            dsname = info["name"]
        c = CurveItem(key, str(name), depth, vals, unit, well, dsname, fam, color_index)
        dunit = info["curves"][0]["unit"] if info and info["curves"] else ""
        c.depth_unit = "ft" if str(dunit).upper().startswith("F") else "M"
        c.siblings = [str(x) for x in df.columns if x != name]
        c.loader = lambda n, df=df, depth=depth: (depth, df[n].values.astype(float)) if n in df.columns else None
        return c

    def open_dataset_logview(self, key):
        """Double-clic sur un dataset : tracks automatiques par famille (GR | Rés | Densité/Neutron | Sonic)."""
        lv = self.new_logview()
        if not lv:
            return
        slots, extras = {}, []
        for n in self.wells[key].columns:
            c = self.make_curve(key, n, 0)
            if c is None:
                continue
            slot = self.FAM_TRACK.get(c.style.family)
            (slots.setdefault(slot, []) if slot is not None else extras).append(c)
        groups = [slots[k] for k in sorted(slots)] + [[c] for c in extras[:4]]
        for curves in groups:
            idx = None
            for k, c in enumerate(curves):
                if c.style.family == "":
                    c.apply_family("", k)
                lv.canvas.add_curve(c, idx)
                idx = len(lv.canvas.tracks) - 1
        lv.sync_bars()

    def _strict_logview(self):
        sub = self.mdi.activeSubWindow()
        w = sub.widget() if sub else None
        return w if isinstance(w, LogViewWidget) else None

    def show_props_for(self, lv):
        """Properties : variable sélectionnée > layout > infos du projet."""
        sel = lv.canvas.selected if lv else None
        if isinstance(sel, CurveItem):
            self._panel_owner = lv
            self.var_panel.set_curve(sel, notify=lv.canvas.update)
            self.props_stack.setCurrentIndex(1)
        elif lv is not None:
            self.var_panel.set_curve(None)
            self.layout_panel.set_view(lv)
            self.props_stack.setCurrentIndex(2)
        else:
            self.var_panel.set_curve(None); self.layout_panel.set_view(None)
            self.props_stack.setCurrentIndex(0)

    def show_properties(self):
        if not self.props_dock.isVisible():
            self.props_dock.show()
            self.resizeDocks([self.props_dock], [380], Qt.Horizontal)

    def on_curve_selected(self, obj, lv):
        if isinstance(obj, CurveItem):
            self._sel_src, self._sel_lv = "lv", lv
        self.show_props_for(lv)
        if isinstance(obj, CurveItem):
            self.show_properties()
        self.update_context_tabs()

    def _on_subwindow_activated(self, sub):
        w = sub.widget() if sub is not None else None
        lv = w if isinstance(w, LogViewWidget) else None
        self.show_props_for(lv)
        self.update_context_tabs()
        if isinstance(w, DepthShiftWidget):              # fenêtre Depth shift : on passe sur son onglet
            self.a_ds_values.setChecked(w.canvas.show_values)
            self.a_ds_pos.setChecked(w.canvas.show_poslines)
            self.tabbar.setCurrentIndex(self.ctx_idx["Depth shift"])

    def _logview_closed(self, lv):
        if self._sel_lv is lv:
            self._sel_lv = None
        if getattr(self, "_panel_owner", None) is lv:
            self._panel_owner = None
            self.var_panel.set_curve(None)
        if self.layout_panel.lv is lv:
            self.layout_panel.set_view(None)
        self.props_stack.setCurrentIndex(0)
        QTimer.singleShot(0, self._after_logview_closed)

    def _after_logview_closed(self):
        self.show_props_for(self._strict_logview())
        self.update_context_tabs()

    def update_context_tabs(self):
        """Onglets jaunes : « Multi well layout » si un LogView est actif, « Variable » si une courbe est choisie."""
        lv = self._strict_logview()
        in_sp = isinstance(lv, SpliceGraphWidget)
        in_ds = isinstance(lv, DepthShiftWidget)
        sel = lv.canvas.selected if lv else None
        lv_var = isinstance(sel, CurveItem) and not in_sp and not in_ds
        has_var = lv_var or (not in_sp and not in_ds and self.project is not None and bool(self._vars_from_tree()))
        self._set_ctx_tab("Depth shift", in_ds)
        for idx, on in ((self.tab_mw, lv is not None and not in_sp and not in_ds), (self.tab_var, has_var),
                        (self.tab_sp, in_sp)):
            self.tabbar.setTabVisible(idx, on)
            self.tabbar.setTabText(idx, self.tabbar.tabText(idx))     # force la mise en page de la barre
        if lv and not in_sp and not in_ds:
            self.a_mw_lhdr.setChecked(lv.canvas.show_layout_header)
            self.a_mw_whdr.setChecked(lv.canvas.show_well_header)
            self.a_mw_tips.setChecked(lv.canvas.show_values)
        if lv_var:
            self.a_v_pal.setChecked(sel.style.fill_mode != "none")
            self.a_v_points.setChecked(sel.style.show_points)
        if not self.tabbar.isTabVisible(self.tabbar.currentIndex()):
            self.tabbar.setCurrentIndex(1)

    # ------------------------------------------- ruban « Multi well layout »
    def mw_toggle(self, attr, action):
        lv = self._strict_logview()
        if lv:
            setattr(lv.canvas, attr, action.isChecked())
            lv.canvas.view_changed()
            self.show_props_for(lv) if lv.canvas.selected is None else None

    def mw_clear_selection(self):
        lv = self._strict_logview()
        if lv:
            lv.canvas.select(None)

    def mw_clear_interval(self):
        lv = self._strict_logview()
        if lv:
            lv.canvas.sel_interval = None; lv.canvas.update()

    def mw_duplicate(self):
        lv = self._strict_logview()
        if not lv:
            return
        new = self.new_logview()
        cv, nc = lv.canvas, new.canvas
        for t in cv.tracks:
            idx = None
            for c in t.curves:
                n = self.make_curve(c.key, c.name, 0)
                if n is None:
                    continue
                n.style = copy.deepcopy(c.style)
                nc.add_curve(n, idx)
                idx = len(nc.tracks) - 1
        nc.scale, nc.top = cv.scale, cv.top
        nc.view_changed(); new.sync_bars()

    def mw_goto(self):
        lv = self._strict_logview()
        if not lv:
            return
        d, ok = QInputDialog.getDouble(self, APP, f"Go to the reference ({lv.canvas.ref_unit}):",
                                       lv.canvas.top, -1e9, 1e9, 2)
        if ok:
            lv.canvas.top = d
            lv.canvas.view_changed()

    def mw_grab(self):
        lv = self._strict_logview()
        if lv:
            path, _ = QFileDialog.getSaveFileName(self, "Grab", "layout.png", "PNG (*.png)")
            if path:
                lv.canvas.grab().save(path)

    def mw_refresh(self):
        lv = self._strict_logview()
        if lv:
            lv.canvas.update(); lv.sync_bars()

    def mw_reload(self):
        lv = self._strict_logview()
        if not lv:
            return
        for c in lv.canvas.all_curves():
            n = self.make_curve(c.key, c.name, 0)
            if n is not None:
                c.depth, c.values = n.depth, n.values
                c.modified, c.orig_values = False, None
                c._aux.clear()
        lv.canvas.view_changed()

    def mw_apply_style(self):
        lv = self._strict_logview()
        c = lv.canvas.selected if lv else None
        if not isinstance(c, CurveItem):
            QMessageBox.information(self, APP, "Select a variable first."); return
        keep = ("title", "family", "axis_type", "user_lo", "user_hi", "unit", "ref_limit", "ref_top", "ref_bottom")
        for o in lv.canvas.all_curves():
            if o is not c and o.style.family == c.style.family:
                for f in c.style.__dataclass_fields__:
                    if f not in keep:
                        setattr(o.style, f, getattr(c.style, f))
        lv.canvas.update()

    def mw_save_vars(self):
        lv = self._strict_logview()
        mods = [c for c in lv.canvas.all_curves() if c.modified] if lv else []
        if not mods:
            QMessageBox.information(self, APP, "There is no modified variable to save.")
            return
        self.save_modified(lv, mods)

    # ------------------------------------------- ruban « Variable »
    def _cur(self, need_interval=False):
        lv = self._strict_logview()
        c = lv.canvas.selected if lv else None
        if not isinstance(c, CurveItem):
            QMessageBox.information(self, APP, "Select a variable first.")
            return None, None
        if need_interval and not lv.canvas.sel_interval:
            QMessageBox.information(self, APP, "Select an interval first: use the Interactive selection tool "
                                    "and drag over the log.")
            return None, None
        return lv, c

    def _style_done(self, lv):
        self.var_panel.refresh()
        lv.canvas.update()

    def v_reverse(self):
        lv, c = self._cur()
        if c:
            lo, hi = c.effective_limits()
            c.style.axis_type, c.style.user_lo, c.style.user_hi = "user", hi, lo
            c.log(f"Reverse the boundaries: {lo:g} / {hi:g} -> {hi:g} / {lo:g}")
            self._style_done(lv)

    def v_alias(self):
        lv, c = self._cur()
        if c:
            text, ok = QInputDialog.getText(self, APP, "Alias:", text=c.display_name())
            if ok:
                c.style.title = text.strip() if text.strip() != c.name else ""
                c.log(f"Alias: {text}")
                self._style_done(lv)

    def v_assign(self):
        lv, c = self._cur()
        if c:
            wells = sorted({i["group"] for i in self.meta.values() if i["kind"] == las_info.WELL})
            if not wells:
                QMessageBox.information(self, APP, "No well in the project."); return
            w, ok = QInputDialog.getItem(self, APP, "Assign to the well:", wells,
                                         max(0, wells.index(c.well)) if c.well in wells else 0, False)
            if ok:
                c.well = w
                lv.canvas.well_settings(w)
                c.log(f"Assigned to the well {w}")
                lv.canvas.update(); lv.canvas.contentChanged.emit()

    def v_shift(self):
        lv, c = self._cur()
        if c:
            v, ok = QInputDialog.getDouble(self, APP, "Baseline value:", c.style.base_value, -1e9, 1e9, 4)
            if ok:
                c.style.base_value = v
                if c.style.fill_mode == "none":
                    c.style.fill_mode = "baseline"
                c.log(f"Baseline: {v:g}")
                self._style_done(lv)

    def v_toggle_palette(self):
        lv, c = self._cur()
        if c:
            c.style.fill_mode = "baseline" if self.a_v_pal.isChecked() else "none"
            self._style_done(lv)
        else:
            self.a_v_pal.setChecked(False)

    def v_toggle_points(self):
        lv, c = self._cur()
        if c:
            c.style.show_points = self.a_v_points.isChecked()
            self._style_done(lv)
        else:
            self.a_v_points.setChecked(False)

    def _modify(self, lv, c, new_vals, label):
        """Applique la modification sur la copie de travail puis propose de la sauvegarder (nouvelle version)."""
        if c.orig_values is None:
            c.orig_values = c.values.copy()
        c.values = new_vals
        c.modified = True
        c._aux.clear()
        c.log(label)
        lv.canvas.update()
        self.save_modified(lv, [c])

    def v_delete_selected(self):
        lv, c = self._cur(True)
        if c:
            m = mask_interval(c.depth, lv.canvas.sel_interval)
            if not m.any():
                QMessageBox.information(self, APP, "No value in the selected interval."); return
            new = c.values.copy(); new[m] = np.nan
            self._modify(lv, c, new, f"Delete selected values ({int(m.sum())} points)")

    def v_delete_non_selected(self):
        lv, c = self._cur(True)
        if c:
            m = mask_interval(c.depth, lv.canvas.sel_interval)
            if not m.any():
                QMessageBox.information(self, APP, "No value in the selected interval."); return
            new = c.values.copy(); new[~m] = np.nan
            self._modify(lv, c, new, f"Delete non-selected values ({int((~m).sum())} points)")

    def v_edit_selected(self):
        lv, c = self._cur(True)
        if c:
            m = mask_interval(c.depth, lv.canvas.sel_interval)
            if not m.any():
                QMessageBox.information(self, APP, "No value in the selected interval."); return
            v, ok = QInputDialog.getDouble(self, APP, "New value for the selected values:", 0.0, -1e12, 1e12, 4)
            if ok:
                new = c.values.copy(); new[m] = v
                self._modify(lv, c, new, f"Edit the selected values -> {v:g} ({int(m.sum())} points)")

    def save_modified(self, lv, curves):
        """« Save the modified variables » : nouvelle version (GR_2) ou extension ; l'original reste intact."""
        dlg = SaveVariablesDialog(self, [c.name for c in curves])
        if dlg.exec() != QDialog.Accepted:
            return False
        for c in list(curves):
            df = self.wells.get(c.key)
            if df is None:
                continue
            new_name = dlg.new_name({str(x) for x in df.columns}, c.name)
            self.create_variable(c.key, c, new_name)
            c.values, c.orig_values, c.modified = c.orig_values, None, False      # l'original revient tel quel
            c._aux.clear()
            lv.add_refs([[c.key, new_name]], -1)                                    # la nouvelle version : nouveau track
        lv.canvas.update()
        self.statusBar().showMessage("Variable saved", 4000)
        return True

    def create_variable(self, key, curve, new_name):
        df = self.wells[key]
        ser = pd.Series(curve.values, index=curve.depth)
        ser = ser[~ser.index.duplicated()]
        df[new_name] = ser.reindex(df.index).values
        path = next(p for p, i in self.meta.items() if i.get("key") == key)
        info = self.meta[path]
        orig = next((x for x in info["curves"] if x["mnemonic"] == curve.name), {})
        unit, fam = orig.get("unit", curve.style.unit), orig.get("family", curve.style.family)
        info["curves"].append({"mnemonic": new_name, "unit": unit, "descr": f"new version of {curve.name}",
                               "family": fam, "derived": True})
        vdir = os.path.join(self.project.project_dir, "variables")
        os.makedirs(vdir, exist_ok=True)
        fname = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{key}__{new_name}") + ".csv"
        ser.to_csv(os.path.join(vdir, fname), header=["value"], index_label="depth")
        self.project.derived.append({"path": path, "name": new_name, "file": os.path.join("variables", fname),
                                     "unit": unit, "family": fam})
        self.set_dirty(); self._refresh_tree(); self._refresh_props()

    # ------------------------------------------------------------ plots
    def _pick(self, label, items):
        item, ok = QInputDialog.getItem(self, APP, label, items, 0, False)
        return item if ok else None

    def _need_wells(self):
        if not self.wells:
            QMessageBox.information(self, APP, "Import a LAS dataset first.")
            return False
        return True

    def _show_fig(self, fig, title):
        canvas = FigureCanvasQTAgg(fig)
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(NavigationToolbar2QT(canvas, w)); v.addWidget(canvas)
        sub = QMdiSubWindow(); sub.setWidget(w); sub.setWindowTitle(title)
        sub.setAttribute(Qt.WA_DeleteOnClose)
        self.mdi.addSubWindow(sub); sub.resize(700, 500); sub.show()

    def plot_log(self, well=None):
        if not self._need_wells():
            return
        well = well if isinstance(well, str) else self._pick("Well", list(self.wells))
        if well:
            self._show_fig(plots.log_plot(self.wells[well], well), f"Log plot - {well}")

    def plot_hist(self):
        if not self._need_wells():
            return
        well = self._pick("Well", list(self.wells))
        if well:
            c = self._pick("Curve", list(self.wells[well].columns))
            if c:
                self._show_fig(plots.histogram(self.wells[well], c, well), f"Histogram - {c}")

    def plot_cross(self):
        if not self._need_wells():
            return
        well = self._pick("Well", list(self.wells))
        if well:
            cols = list(self.wells[well].columns)
            x = self._pick("X curve", cols)
            y = x and self._pick("Y curve", cols)
            if x and y:
                self._show_fig(plots.cross_plot(self.wells[well], x, y, well), f"Cross-plot {x}/{y}")

    def mdi_tile(self, mode=None):
        subs = self.mdi.subWindowList()
        if mode and subs:
            area = self.mdi.viewport().rect(); n = len(subs)
            for i, s in enumerate(subs):
                s.showNormal()
                if mode == "h":
                    s.setGeometry(0, i * area.height() // n, area.width(), area.height() // n)
                else:
                    s.setGeometry(i * area.width() // n, 0, area.width() // n, area.height())
        else:
            self.mdi.tileSubWindows()
    def mdi_cascade(self): self.mdi.cascadeSubWindows()
    def _todo(self): QMessageBox.information(self, APP, "Not implemented yet.")

    # =========================================================== variables sélectionnées / onglet Variable
    def _vars_from_tree(self):
        out = []
        for it in self.tree.selectedItems():
            if it.data(0, Qt.UserRole) in self.wells:      # un dataset entier : pas une variable
                continue
            for k, n in self.curve_refs(it):
                out.append(dict(key=k, name=n, curve=None, lv=None))
        return out

    def current_vars(self):
        """Variables sélectionnées : dans le LogView (dernier clic) sinon dans le Project browser."""
        lv = self._sel_lv
        if self._sel_src == "lv" and lv is not None and lv.canvas.selection:
            return [dict(key=c.key, name=c.name, curve=c, lv=lv) for c in lv.canvas.selection]
        return self._vars_from_tree()

    def _tree_selection_changed(self):
        if self._vars_from_tree():
            self._sel_src = "tree"
        self.update_context_tabs()

    def _set_ctx_tab(self, name, visible):
        i = self.ctx_idx.get(name)
        if i is None or self.tabbar.isTabVisible(i) == visible:
            return
        if not visible and self.tabbar.currentIndex() == i:
            self.tabbar.setCurrentIndex(0)
        self.tabbar.setTabVisible(i, visible)

    def _logviews(self):
        return [s.widget() for s in self.mdi.subWindowList() if isinstance(s.widget(), LogViewWidget)
                and not isinstance(s.widget(), (DepthShiftWidget, SpliceGraphWidget))]

    def _curves_of(self, v):
        if v.get("curve") is not None:
            return [v["curve"]]
        return [c for lv in self._logviews() for c in lv.canvas.all_curves()
                if c.key == v["key"] and c.name == v["name"]]

    def var_toggle_points(self, checked=False):
        for v in self.current_vars():
            for c in self._curves_of(v):
                c.style.show_points = bool(checked)
        for lv in self._logviews():
            lv.canvas.update()
        self.var_panel.refresh()

    def var_plot(self):
        vars_ = self.current_vars()
        if not vars_:
            return
        lv = self.active_logview() or self.new_logview()
        if lv:
            lv.add_refs([[v["key"], v["name"]] for v in vars_], -1)

    def _drop_on_workspace(self, refs):
        """Variable glissée sur l'espace de travail : nouveau LogView (un track par variable)."""
        lv = self.new_logview()
        if lv:
            lv.add_refs(refs, -1)

    # =========================================================== menu Processing
    def _menu_act(self, menu, icon, text, fn):
        a = QAction(icon, text, menu)
        a.triggered.connect(lambda checked=False, fn=fn: fn())
        menu.addAction(a)
        return a

    SMOOTH = {"gauss": ("Gaussian smooth", "_GAUSS"),
              "gauss_mv": ("Smooth with missing values", "_GAUSS_MV"),
              "median": ("Median smooth", "_MEDIAN")}

    def _fill_processing(self, menu, get_vars):
        sm = menu.addMenu(hi.i_smooth(), "Smoothing")
        for kind, label in (("gauss", "Gaussian smooth..."), ("gauss_mv", "Smooth with missing values..."),
                            ("median", "Median smooth...")):
            self._menu_act(sm, hi.i_smooth(), label, lambda k=kind: self.smooth(k, get_vars()))
        for name, icon in (("Cleaning", hi.i_clean()), ("Interpolation", hi.i_interp()),
                           ("Derivative", hi.i_deriv())):
            self._menu_act(menu.addMenu(icon, name), icon, "(not implemented yet)", self._todo)
        menu.addSeparator()
        self._menu_act(menu.addMenu(hi.i_others(), "Others"), hi.i_others(), "(not implemented yet)", self._todo)
        self._menu_act(menu.addMenu(hi.i_compaction(), "Compaction"), hi.i_compaction(),
                       "(not implemented yet)", self._todo)
        self._menu_act(menu, hi.i_depthshift(), "Depth Shifting",
                       lambda: self.open_depth_shift_vars(get_vars()))

    def _lv_context_menu(self, menu, curves, lv):
        """Compléments du clic droit dans un LogView (courbes sélectionnées)."""
        vars_ = [dict(key=c.key, name=c.name, curve=c, lv=lv) for c in curves]
        self._fill_processing(menu.addMenu(hi.i_processing(), "Processing"), lambda: vars_)
        menu.addSection("Open")
        self._menu_act(menu, hi.i_depthshift(), "Depth shift window",
                       lambda: self.open_depth_shift_vars(vars_, lv))
        self._menu_act(menu, hi.i_data_editor(), "Data editor", self._todo)

    # =========================================================== variables créées (smoothing, depth shift...)
    def _info_of(self, key):
        return next((i for i in self.meta.values() if i.get("key") == key), None)

    def depth_unit_label(self, key):
        info = self._info_of(key)
        u = (info["curves"][0]["unit"] if info and info["curves"] else "").strip().upper()
        return "ft" if u in ("FT", "F", "FEET", "FOOT") else "m"

    def var_label(self, key, name):
        info = self._info_of(key)
        if not info:
            return name
        parts = ([info["group"]] if info["kind"] == las_info.WELL else []) + [info["name"], name]
        return ".".join(parts)

    def add_derived(self, key, base, values, like, descr, refresh=True):
        """Ajoute une variable calculée au dataset `key` (nom unique garanti) ; retourne son nom."""
        df = self.wells[key]
        new, n = base, 2
        while new in df.columns:
            new = f"{base}_{n}"; n += 1
        df[new] = np.asarray(values, float)
        unit = fam = ""
        info = self._info_of(key)
        if info:
            cur = next((c for c in info["curves"] if c["mnemonic"].upper() == str(like).upper()), None)
            if cur:
                unit, fam = cur["unit"], cur["family"]
            info["curves"].append({"mnemonic": new, "unit": unit, "descr": descr, "family": fam, "derived": True})
        if self.project is not None:
            self.project.derived_cols.setdefault(key, {})[new] = {"unit": unit, "family": fam, "descr": descr}
        self.set_dirty()
        if refresh:
            self._refresh_tree(reveal=(key, new))
        return new

    @staticmethod
    def _safe(key):
        return re.sub(r"[^\w.-]+", "_", key)

    def _derived_folder(self):
        return os.path.join(os.path.dirname(self.project.path), "derived")

    def _write_derived(self):
        """Écrit les variables créées dans <projet>/derived/<dataset>.csv (les LAS d'origine ne sont pas modifiés)."""
        if not (self.project and self.project.path and (self.project.derived_cols or self.project.virtual)):
            return
        folder = self._derived_folder()
        os.makedirs(folder, exist_ok=True)
        for vkey in self.project.virtual:
            if vkey in self.wells:
                self.wells[vkey].to_csv(os.path.join(folder, "virtual_" + self._safe(vkey) + ".csv"))
        for key, cols in self.project.derived_cols.items():
            df = self.wells.get(key)
            names = [c for c in cols if df is not None and c in df.columns]
            if names:
                df[names].to_csv(os.path.join(folder, self._safe(key) + ".csv"))

    def _load_virtual(self):
        """Recrée les datasets virtuels (Shifted_Set...) à partir de derived/virtual_*.csv."""
        proj = self.project
        if not (proj and proj.virtual and proj.path):
            return
        import pandas as pd
        for vkey, v in proj.virtual.items():
            fn = os.path.join(self._derived_folder(), "virtual_" + self._safe(vkey) + ".csv")
            if v["source"] not in self.wells or not os.path.exists(fn):
                continue
            try:
                df = pd.read_csv(fn, index_col=0)
                df.index = df.index.astype(float)
            except Exception:
                continue
            self.wells[vkey] = df
            self.meta[v["path"]] = {
                "path": v["path"], "stem": v["name"], "name": v["name"], "kind": v["kind"], "group": v["group"],
                "key": vkey, "virtual": True,
                "curves": [{"mnemonic": c, "unit": m.get("unit", ""), "descr": m.get("descr", ""),
                            "family": m.get("family", "")} for c, m in v["columns"].items() if c in df.columns]}

    def _shifted_set(self, src_key):
        """Dataset virtuel « Shifted_Set » du puits de `src_key` (créé la 1re fois) : retourne sa clé."""
        proj = self.project
        for vkey, v in proj.virtual.items():
            if v["source"] == src_key and vkey in self.wells:
                return vkey
        src_info, src_df = self._info_of(src_key), self.wells[src_key]
        if src_info and src_info["kind"] == las_info.WELL:
            kind, group = las_info.WELL, src_info["group"]
            taken = {i["name"] for i in self.meta.values()
                     if i["kind"] == las_info.WELL and las_info.well_key(i["group"]) == las_info.well_key(group)}
            name, n = "Shifted_Set", 2
            while name in taken:
                name = f"Shifted_Set_{n}"; n += 1
        else:                                          # LAS indépendant : dataset indépendant lui aussi
            kind = las_info.DATASET
            name = f"{src_info['name'] if src_info else src_key}_Shifted"
            group = name
        vkey, n = f"{group}.{name}", 2
        while vkey in self.wells:
            vkey = f"{group}.{name} ({n})"; n += 1
        path = f"virtual://{vkey}"
        unit = src_info["curves"][0]["unit"] if src_info and src_info["curves"] else ""
        df = src_df[[]].copy()                         # même grille de profondeur que le dataset d'origine
        df["MD"] = src_df.index.values.astype(float)
        self.wells[vkey] = df
        self.meta[path] = {"path": path, "stem": name, "name": name, "kind": kind, "group": group, "key": vkey,
                           "virtual": True,
                           "curves": [{"mnemonic": "MD", "unit": unit, "descr": "Measured depth",
                                       "family": "Measured Depth"}]}
        proj.virtual[vkey] = {"path": path, "source": src_key, "name": name, "group": group, "kind": kind,
                              "columns": {"MD": {"unit": unit, "family": "Measured Depth", "descr": "Measured depth"}}}
        return vkey

    def add_to_shifted_set(self, src_key, base, values, like, descr):
        """Ajoute une variable au dataset « Shifted_Set » du puits ; retourne (clé du dataset, nom de la variable)."""
        vkey = self._shifted_set(src_key)
        df = self.wells[vkey]
        new, n = base, 2
        while new in df.columns:
            new = f"{base}_{n}"; n += 1
        df[new] = np.asarray(values, float)
        src_info = self._info_of(src_key)
        unit = fam = ""
        if src_info:
            cur = next((c for c in src_info["curves"] if c["mnemonic"].upper() == str(like).upper()), None)
            if cur:
                unit, fam = cur["unit"], cur["family"]
        self._info_of(vkey)["curves"].append({"mnemonic": new, "unit": unit, "descr": descr, "family": fam})
        self.project.virtual[vkey]["columns"][new] = {"unit": unit, "family": fam, "descr": descr}
        self.set_dirty()
        self._refresh_tree(reveal=(vkey, new))
        return vkey, new

    def _load_derived(self):
        proj = self.project
        if not (proj and proj.derived_cols and proj.path):
            return
        import pandas as pd
        for key, cols in proj.derived_cols.items():
            df = self.wells.get(key)
            fn = os.path.join(self._derived_folder(), self._safe(key) + ".csv")
            if df is None or not os.path.exists(fn):
                continue
            try:
                d = pd.read_csv(fn, index_col=0)
            except Exception:
                continue
            info = self._info_of(key)
            for name, m in cols.items():
                if name in d.columns and name not in df.columns and len(d) == len(df):
                    df[name] = d[name].to_numpy(dtype=float)
                    if info:
                        info["curves"].append({"mnemonic": name, "unit": m.get("unit", ""),
                                               "descr": m.get("descr", ""), "family": m.get("family", ""),
                                               "derived": True})

    # =========================================================== Smoothing
    def smooth(self, kind, vars_=None):
        vars_ = self.current_vars() if vars_ is None else vars_
        if not vars_:
            QMessageBox.information(self, APP, "Select a variable first.")
            return
        title, suffix = self.SMOOTH[kind]
        unit = self.depth_unit_label(vars_[0]["key"])
        dlg = SmoothDialog(self, title, hi.i_smooth(), [self.var_label(v["key"], v["name"]) for v in vars_], unit)
        if dlg.exec() != QDialog.Accepted:
            return
        window, log = dlg.values()
        made, last = [], None
        for v in vars_:
            df = self.wells.get(v["key"])
            if df is None or v["name"] not in df.columns:
                continue
            vals = processing.on_valid_depth(
                df.index.values, df[v["name"]].values,
                lambda d, x: processing.smooth(d, x, window, kind, log))
            new = self.add_derived(v["key"], v["name"] + suffix, vals, v["name"],
                                   f"{title} (window {window:g} {unit}{', log' if log else ''})", refresh=False)
            self._overlay_new(v, new)
            made.append(new); last = (v["key"], new)
        if made:
            self._refresh_tree(reveal=last)
            self.statusBar().showMessage("Created: " + ", ".join(made), 6000)

    def _overlay_new(self, v, new):
        """Affiche la variable lissée en gris par-dessus la variable d'origine, dans le même track."""
        for lv in self._logviews():
            cv = lv.canvas
            for ti, t in enumerate(list(cv.tracks)):
                src = next((c for c in t.curves if c.key == v["key"] and c.name == v["name"]), None)
                if src is None or any(c.name == new for c in t.curves):
                    continue
                c = self.make_curve(v["key"], new, 0)
                if c is None:
                    continue
                s = c.style
                s.axis_type = "user"
                s.user_lo, s.user_hi = src.effective_limits()
                s.scale, s.unit, s.inverted = src.style.scale, src.style.unit, src.style.inverted
                s.color, s.thickness, s.fill_mode, s.line_style = "#8a8a5c", 1.4, "none", "solid"
                cv.add_curve(c, ti)
            lv.sync_bars()

    # =========================================================== Depth shift
    def active_depthshift(self):
        sub = self.mdi.activeSubWindow()
        if sub is not None and isinstance(sub.widget(), DepthShiftWidget):
            return sub.widget()
        for s in reversed(self.mdi.subWindowList()):
            if isinstance(s.widget(), DepthShiftWidget):
                return s.widget()
        return None

    def _ds(self, method, *args):
        w = self.active_depthshift()
        if w is not None:
            getattr(w, method)(*args)

    def open_depth_shift_vars(self, vars_, lv=None):
        """Ouvre la fenêtre Depth shift pour les variables données (≥ 2 : une référence + les autres à décaler)."""
        curves = []
        for i, v in enumerate(vars_ or []):
            c = v.get("curve") or self.make_curve(v["key"], v["name"], i)
            if c is not None and all(c is not x for x in curves):
                curves.append(c)
        if not curves:
            QMessageBox.information(self, APP, "Select the variables first (Ctrl+click to select several).")
            return
        if len(curves) == 1:                   # une seule variable : la référence vient d'un autre track du LogView
            lv = lv or self.active_logview()
            pool, seen = [], {(curves[0].key, curves[0].name)}
            for c in (lv.canvas.all_curves() if lv else []):
                if (c.key, c.name) not in seen:
                    seen.add((c.key, c.name)); pool.append(c)
            if not pool:
                QMessageBox.information(self, APP, "A depth shift needs two variables:\n"
                                        "select a reference and a variable to shift (Ctrl+click).")
                return
            labels = [f"{c.name}  ({c.dataset})" for c in pool]
            item, ok = QInputDialog.getItem(self, "Depth shift",
                                            f"Reference variable for the shift of {curves[0].name}:",
                                            labels, 0, False)
            if not ok:
                return
            ref, shifted = pool[labels.index(item)], curves
        else:
            got = pick_reference(self, curves)
            if not got:
                return
            ref, shifted = got
        w = DepthShiftWidget(self, ref, shifted)
        sub = QMdiSubWindow(); sub.setWidget(w); sub.setAttribute(Qt.WA_DeleteOnClose)
        sub.setWindowTitle(w.title())
        self.mdi.addSubWindow(sub); sub.resize(1000, 640); sub.show()
        self.mdi.setActiveSubWindow(sub)
        self._on_subwindow_activated(sub)
