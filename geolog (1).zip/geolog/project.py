"""Modèle de données d'un projet GeoLog (fichier JSON .gpproj)."""
import json
import os
from dataclasses import dataclass, field, asdict

EXT = ".gpproj"
STATUSES = ["in progress", "completed", "archived"]
MODES = ["single user [read/write]", "single user [read only]"]
UNITS = ["Undefined", "Metric (SI)", "Oilfield (API)"]


@dataclass
class Project:
    name: str
    folder: str                      # dossier parent, ex: C:\GeoLog-Projects
    template: str = ""
    status: str = "in progress"
    mode: str = MODES[0]
    units: str = "Undefined"
    datasets: list = field(default_factory=list)   # chemins des fichiers LAS
    path: str = ""                   # chemin du fichier .gpproj

    @property
    def project_dir(self):
        return os.path.join(self.folder, self.name)

    def default_path(self):
        return os.path.join(self.project_dir, self.name + EXT)

    def save(self, path=None):
        self.path = path or self.path or self.default_path()
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        p = cls(**data)
        p.path = path
        return p
