"""Fonctions de tracé (matplotlib) : log plot, histogramme, cross-plot."""
import numpy as np
from matplotlib.figure import Figure


def log_plot(df, name, max_tracks=6):
    curves = list(df.columns)[:max_tracks]
    fig = Figure()
    axes = np.atleast_1d(fig.subplots(1, len(curves), sharey=True))
    for ax, c in zip(axes, curves):
        ax.plot(df[c].values, df.index.values, lw=0.8)
        ax.set_title(c, fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.xaxis.tick_top()
    axes[0].invert_yaxis()
    axes[0].set_ylabel("Depth")
    fig.suptitle(name)
    return fig


def histogram(df, curve, name):
    fig = Figure()
    ax = fig.subplots()
    ax.hist(df[curve].dropna().values, bins=40)
    ax.set_xlabel(curve); ax.set_ylabel("Count"); ax.set_title(name)
    return fig


def cross_plot(df, cx, cy, name):
    fig = Figure()
    ax = fig.subplots()
    ax.scatter(df[cx], df[cy], s=4)
    ax.set_xlabel(cx); ax.set_ylabel(cy); ax.set_title(name); ax.grid(True, alpha=0.3)
    return fig
