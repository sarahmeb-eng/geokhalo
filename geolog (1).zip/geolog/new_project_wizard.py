"""Assistant « New project » (2 pages), comme dans Techlog."""
import os
from PySide6.QtWidgets import (QWizard, QWizardPage, QFormLayout, QLineEdit,
                               QComboBox, QPushButton, QHBoxLayout, QWidget,
                               QFileDialog, QMessageBox, QLabel, QVBoxLayout)
from project import Project, STATUSES, MODES, UNITS


def _path_row(line_edit, title, is_dir=True, filt=""):
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    btn = QPushButton("...")
    btn.setFixedWidth(32)

    def browse():
        if is_dir:
            p = QFileDialog.getExistingDirectory(w, title, line_edit.text())
        else:
            p, _ = QFileDialog.getOpenFileName(w, title, line_edit.text(), filt)
        if p:
            line_edit.setText(os.path.normpath(p))
    btn.clicked.connect(browse)
    h.addWidget(line_edit)
    h.addWidget(btn)
    return w


class PageFolder(QWizardPage):
    def __init__(self, default_folder):
        super().__init__()
        self.setTitle("Folder, status and type")
        form = QFormLayout(self)
        self.folder = QLineEdit(default_folder)
        self.template = QLineEdit()
        self.status = QComboBox(); self.status.addItems(STATUSES)
        self.mode = QComboBox(); self.mode.addItems(MODES)
        self.units = QComboBox(); self.units.addItems(UNITS)
        form.addRow("Project folder:", _path_row(self.folder, "Project folder"))
        form.addRow("Template project path:",
                    _path_row(self.template, "Template", False, "GeoLog (*.gpproj)"))
        form.addRow("Project status:", self.status)
        form.addRow("Project opening default mode:", self.mode)
        form.addRow("Unit system:", self.units)
        self.registerField("folder*", self.folder)

    def validatePage(self):
        if not self.folder.text().strip():
            QMessageBox.warning(self, "New project", "Please choose a project folder.")
            return False
        return True


class PageName(QWizardPage):
    def __init__(self):
        super().__init__()
        self.setTitle("Project name")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Enter the name of the new project:"))
        self.name = QLineEdit()
        lay.addWidget(self.name)
        self.registerField("name*", self.name)

    def validatePage(self):
        name = self.name.text().strip()
        bad = set('\\/:*?"<>|')
        if any(c in bad for c in name):
            QMessageBox.warning(self, "New project", "Invalid characters in the name.")
            return False
        folder = self.wizard().page_folder.folder.text()
        if os.path.exists(os.path.join(folder, name)):
            QMessageBox.warning(self, "New project", "A project with this name already exists.")
            return False
        return True


class NewProjectWizard(QWizard):
    def __init__(self, default_folder, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New project")
        self.setWizardStyle(QWizard.ClassicStyle)
        self.setOption(QWizard.HaveHelpButton, True)
        self.setButtonText(QWizard.BackButton, "< Previous")
        self.setButtonText(QWizard.NextButton, "Next >")
        self.setButtonText(QWizard.HelpButton, "Help")
        self.setButtonText(QWizard.FinishButton, "Finish")
        self.page_folder = PageFolder(default_folder)
        self.addPage(self.page_folder)
        self.page_name = PageName()
        self.addPage(self.page_name)
        self.helpRequested.connect(lambda: QMessageBox.information(
            self, "Help", "Choose where the project is stored, then give it a name."))
        self.resize(560, 380)

    def project(self):
        f = self.page_folder
        return Project(name=self.page_name.name.text().strip(),
                       folder=f.folder.text().strip(),
                       template=f.template.text().strip(),
                       status=f.status.currentText(),
                       mode=f.mode.currentText(),
                       units=f.units.currentText())
