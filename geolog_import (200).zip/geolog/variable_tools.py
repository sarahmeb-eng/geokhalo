"""Outils « Variable » : boîte de dialogue de sauvegarde et nommage des nouvelles versions."""
import re

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QCheckBox,
                               QPushButton)


def next_version(existing, name):
    """GR -> GR_2 ; GR_2 -> GR_3 (premier nom libre)."""
    m = re.match(r"^(.*)_(\d+)$", name)
    root, n = (m.group(1), int(m.group(2)) + 1) if m else (name, 2)
    while f"{root}_{n}" in existing:
        n += 1
    return f"{root}_{n}"


def with_extension(existing, name, ext):
    """GR + _clean -> GR_clean (suffixe numérique si le nom existe déjà)."""
    new = f"{name}{ext}"
    n = 2
    while new in existing:
        new = f"{name}{ext}_{n}"; n += 1
    return new


class SaveVariablesDialog(QDialog):
    """Boîte « Save the modified variables » : extension + case « As a new version »."""

    def __init__(self, parent=None, names=()):
        super().__init__(parent)
        self.setWindowTitle("Save the modified variables")
        self.setModal(True)
        v = QVBoxLayout(self)
        if names:
            v.addWidget(QLabel("Variables: " + ", ".join(names)))
        v.addWidget(QLabel("Save with extension:"))
        self.ext = QLineEdit("_clean")
        v.addWidget(self.ext)
        self.new_version = QCheckBox("As a new version")
        self.new_version.setChecked(True)
        self.new_version.toggled.connect(lambda on: self.ext.setEnabled(not on))
        self.ext.setEnabled(False)                    # désactivé tant que « new version » est coché
        v.addWidget(self.new_version)
        row = QHBoxLayout(); row.addStretch()
        ok, cancel = QPushButton("OK"), QPushButton("Cancel")
        ok.setDefault(True)
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(cancel)
        v.addLayout(row)
        self.setMinimumWidth(300)

    def new_name(self, existing, name):
        if self.new_version.isChecked():
            return next_version(existing, name)
        return with_extension(existing, name, self.ext.text().strip() or "_clean")


def mask_interval(depth, interval):
    """Masque booléen des points dont la profondeur est dans l'intervalle (a, b)."""
    a, b = interval
    return (depth >= a) & (depth <= b)
