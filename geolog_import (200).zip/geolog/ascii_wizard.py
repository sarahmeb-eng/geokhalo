"""« Data import wizard » (Figure 15 du cours) : texte / CSV / Excel -> datasets."""
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QBrush
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QSplitter, QPlainTextEdit, QTableWidget,
                               QTableWidgetItem, QPushButton, QLabel, QLineEdit, QComboBox, QSpinBox,
                               QCheckBox, QMessageBox, QHeaderView, QAbstractItemView)

import ascii_import as ai
from ascii_import import AsciiSettings, TYPES, TYPE_COLORS


class AsciiWizard(QDialog):
    def __init__(self, path, parent=None):
        super().__init__(parent)
        self.path = str(path)
        self.stem = Path(path).stem
        self.is_xlsx = self.path.lower().endswith((".xlsx", ".xls"))
        self.lines = [] if self.is_xlsx else ai.read_lines(self.path)
        self.xrows = ai.read_xlsx_rows(self.path) if self.is_xlsx else None
        self.datasets = []
        self.types, self.names, self.units, self.table = [], [], [], None
        self._building = False
        self.setWindowTitle(f"Data import wizard - {self.path}")
        self.resize(1180, 760)

        v = QVBoxLayout(self)
        self.chk_detect = QCheckBox("Parameters detection"); self.chk_detect.setChecked(True)
        v.addWidget(self.chk_detect)
        split = QSplitter(Qt.Horizontal)
        self.view = QPlainTextEdit(); self.view.setReadOnly(True); self.view.setLineWrapMode(QPlainTextEdit.NoWrap)
        f = QFont("Courier New", 9); self.view.setFont(f)
        src = self.lines if not self.is_xlsx else ["\t".join(r) for r in self.xrows]
        self.view.setPlainText("\n".join(f"{i + 1:>3} : {l}" for i, l in enumerate(src[:2000])))
        self.props = QTableWidget(0, 2)
        self.props.setHorizontalHeaderLabels(["Property", "Value"]); self.props.verticalHeader().hide()
        self.props.horizontalHeader().setStretchLastSection(True)
        self.props.setEditTriggers(QAbstractItemView.NoEditTriggers); self.props.setColumnWidth(0, 190)
        split.addWidget(self.view); split.addWidget(self.props); split.setSizes([620, 520])
        v.addWidget(split, 3)

        bar = QHBoxLayout()
        self.btn_preview = QPushButton("Preview"); self.btn_load = QPushButton("Load to the import buffer")
        self.ed_mv = QLineEdit("-999.25"); self.ed_mv.setFixedWidth(80)
        bar.addWidget(self.btn_preview); bar.addWidget(self.btn_load); bar.addSpacing(12)
        bar.addWidget(QLabel("Missing value detection rules:  MV =")); bar.addWidget(self.ed_mv); bar.addStretch()
        self.sp_rows = QSpinBox(); self.sp_rows.setRange(5, 500); self.sp_rows.setValue(25)
        bar.addWidget(QLabel("Preview rows:")); bar.addWidget(self.sp_rows)
        v.addLayout(bar)
        self.grid = QTableWidget(); self.grid.setEditTriggers(QAbstractItemView.NoEditTriggers)
        v.addWidget(self.grid, 3)

        self._build_props()
        self.btn_preview.clicked.connect(lambda: self.refresh(False))
        self.btn_load.clicked.connect(self.load)
        self.sp_rows.valueChanged.connect(lambda _: self.refresh(False))
        if self.chk_detect.isChecked():
            self._apply_detection()
        self.refresh(True)
        if "Zone name" in self.types and self.w["dtype"].currentText() == "continuous":
            self.w["dtype"].setCurrentText("interval")           # le cours : « verify that the Dataset type is interval »

    # ------------------------------------------------------------ propriétés
    def _section(self, title):
        r = self.props.rowCount(); self.props.insertRow(r)
        it = QTableWidgetItem(title); f = it.font(); f.setBold(True); it.setFont(f)
        it.setBackground(QBrush(QColor("#e4e4e4")))
        self.props.setItem(r, 0, it); self.props.setItem(r, 1, QTableWidgetItem("")); self.props.item(r, 1).setBackground(QBrush(QColor("#e4e4e4")))

    def _row(self, key, label, widget):
        r = self.props.rowCount(); self.props.insertRow(r)
        self.props.setItem(r, 0, QTableWidgetItem("   " + label)); self.props.setCellWidget(r, 1, widget)
        self.w[key] = widget

    def _build_props(self):
        self.w = {}
        yn = lambda on: self._combo(["no", "yes"], "yes" if on else "no")
        self._section("General")
        self._row("well", "Well name", QLineEdit(self.stem))
        self._row("dataset", "Dataset name", QLineEdit(""))
        self._row("dtype", "Dataset type", self._combo(ai.DTYPES, "continuous", True))
        for k, lab, val in (("start", "Import from line", 2), ("name", "Variable name line", 1), ("unit", "Units line", 0)):
            sp = QSpinBox(); sp.setRange(0, 100000); sp.setValue(val); sp.valueChanged.connect(lambda _: self.refresh(False))
            self._row(k, lab, sp)
        self._section("Type")
        self._row("data_type", "Data type", self._combo(["delimited", "fixed"]))
        self._row("decimal", "Decimal comma", self._combo(["point", "comma"]))
        sp = QSpinBox(); sp.setRange(1, 500); sp.setValue(10); sp.valueChanged.connect(lambda _: self.refresh(False)); self._row("colsize", "Column size", sp)
        sp = QSpinBox(); sp.setRange(0, 500); sp.valueChanged.connect(lambda _: self.refresh(False)); self._row("fromcol", "Import from column", sp)
        self._row("zonation", "Zonation mode", self._combo(["default", "zonation"], "default", True))
        self._section("Delimiter")
        self._row("semicolon", "Semicolon", yn(False)); self._row("tab", "Tabulation", yn(True))
        self._row("space", "Space", yn(False)); self._row("comma", "Comma", yn(False))
        ed = QLineEdit(); ed.editingFinished.connect(lambda: self.refresh(False)); self._row("others", "Others", ed)
        self._row("keep", "Keep consecutive separators", yn(True))
        self._row("textid", "Text identifier", self._combo(["automatic", '"', "'", "none"]))
        if self.is_xlsx:
            for k in ("data_type", "colsize", "semicolon", "tab", "space", "comma", "others", "keep", "textid"):
                self.w[k].setEnabled(False)

    def _combo(self, items, cur=None, reguess=False):
        c = QComboBox(); c.addItems(items)
        if cur:
            c.setCurrentText(cur)
        c.currentTextChanged.connect(lambda _: self.refresh(reguess))
        return c

    def _apply_detection(self):
        if self.is_xlsx:
            return
        st = ai.detect_settings(self.lines)
        self._building = True
        for k, v in (("start", st.start_line), ("name", st.name_line), ("unit", st.unit_line)):
            self.w[k].setValue(v)
        for k in ("semicolon", "tab", "space", "comma"):
            self.w[k].setCurrentText("yes" if getattr(st, k) else "no")
        self.w["keep"].setCurrentText("yes" if st.keep_consecutive else "no")
        self._building = False

    def settings(self):
        w = self.w
        try:
            mv = float(self.ed_mv.text().replace(",", "."))
        except ValueError:
            mv = -999.25
        return AsciiSettings(
            dtype=w["dtype"].currentText(), well=w["well"].text().strip(), dataset=w["dataset"].text().strip(),
            start_line=w["start"].value(), name_line=w["name"].value(), unit_line=w["unit"].value(),
            data_type=w["data_type"].currentText(), decimal_comma=w["decimal"].currentText() == "comma",
            col_size=w["colsize"].value(), from_col=w["fromcol"].value(), zonation=w["zonation"].currentText(),
            semicolon=w["semicolon"].currentText() == "yes", tab=w["tab"].currentText() == "yes",
            space=w["space"].currentText() == "yes", comma=w["comma"].currentText() == "yes",
            others=w["others"].text(), keep_consecutive=w["keep"].currentText() == "yes",
            text_id=w["textid"].currentText(), mv=mv)

    # --------------------------------------------------------------- aperçu
    def refresh(self, reguess):
        if self._building:
            return
        self._capture_edits()
        st = self.settings()
        rows = self.xrows if self.is_xlsx else ai.tokenize(self.lines, st)
        tb = ai.parse_table(rows, st)
        same = self.table is not None and tb.ncols == self.table.ncols and not reguess
        self.table = tb
        if not same:
            self.types = ai.guess_types(tb, st)
            self.names = [h or "" for h in tb.headers]
            self.units = [u or "" for u in tb.units]
        self._fill_grid()

    def _capture_edits(self):
        if self.table is None or self.grid.rowCount() < 3:
            return
        for c in range(min(self.grid.columnCount(), len(self.names))):
            for row, store in ((1, self.names), (2, self.units)):
                it = self.grid.item(row, c)
                if it:
                    store[c] = it.text()

    def _fill_grid(self):
        g, tb = self.grid, self.table
        n = min(self.sp_rows.value(), len(tb.rows))
        g.clear(); g.setColumnCount(tb.ncols); g.setRowCount(3 + n)
        g.setVerticalHeaderLabels(["Type", "Name", "Unit"] + [str(i + 1) for i in range(n)])
        g.setHorizontalHeaderLabels([str(i + 1) for i in range(tb.ncols)])
        for c in range(tb.ncols):
            cb = QComboBox(); cb.addItems(TYPES); cb.setCurrentText(self.types[c])
            cb.currentTextChanged.connect(lambda t, c=c: self._type_changed(c, t))
            g.setCellWidget(0, c, cb)
            g.setItem(1, c, QTableWidgetItem(self.names[c])); g.setItem(2, c, QTableWidgetItem(self.units[c]))
            for r in range(n):
                it = QTableWidgetItem(tb.rows[r][c]); it.setFlags(it.flags() & ~Qt.ItemIsEditable); g.setItem(3 + r, c, it)
            self._color_col(c)
        for r in (1, 2):
            for c in range(tb.ncols):
                g.item(r, c).setFlags(g.item(r, c).flags() | Qt.ItemIsEditable)
        g.resizeColumnsToContents()

    def _type_changed(self, c, t):
        self.types[c] = t
        self._color_col(c)

    def _color_col(self, c):
        col = QColor(TYPE_COLORS[self.types[c]])
        for r in range(1, self.grid.rowCount()):
            it = self.grid.item(r, c)
            if it:
                it.setBackground(QBrush(col if r > 1 else col.darker(108)))

    # ---------------------------------------------------------------- chargement
    def load(self):
        self._capture_edits()
        st = self.settings()
        try:
            self.datasets = ai.build_datasets(self.table, self.types, self.names, self.units, st, self.stem)
        except ValueError as e:
            QMessageBox.warning(self, "Data import wizard", str(e)); return
        if not self.datasets:
            QMessageBox.warning(self, "Data import wizard", "No data could be read with these parameters."); return
        self.accept()
