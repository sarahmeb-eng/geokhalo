"""Fenêtre « Variables splice tool » : onglets Inputs / Limits, exécution display / save."""
import json

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QBrush, QFont
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QTableWidget,
                               QTableWidgetItem, QLabel, QLineEdit, QDoubleSpinBox, QComboBox,
                               QToolButton, QMenu, QDialog, QListWidget, QListWidgetItem,
                               QCheckBox, QPushButton, QMessageBox, QHeaderView, QAbstractItemView)

from splice import (build_rows, auto_bounds, default_step, valid_extent, Seg)

DATASETS_MIME = "application/x-geolog-datasets"
POS_COLORS = ["#e4e4ff", "#d4eefa", "#dcf3d6", "#f3ebcc"]
YELLOW = "#fff0b0"
UNITS = ["GAPI", "G/C3", "V/V", "US/F", "IN", "OHMM", "MV", "B/E", "M", "FT", "%"]


class DropTable(QTableWidget):
    """Table des Inputs : on y dépose des puits / datasets depuis le Project browser."""
    datasetsDropped = Signal(list)

    def __init__(self, *a):
        super().__init__(*a)
        self.setAcceptDrops(True)

    def dragEnterEvent(self, e):
        if e.mimeData().hasFormat(DATASETS_MIME):
            e.acceptProposedAction()

    dragMoveEvent = dragEnterEvent

    def dropEvent(self, e):
        try:
            keys = json.loads(bytes(e.mimeData().data(DATASETS_MIME)).decode())
        except ValueError:
            return
        self.datasetsDropped.emit(keys)
        e.acceptProposedAction()


class GroupsDialog(QDialog):
    """« Groups selection » : choix des variables à fusionner."""

    def __init__(self, parent, variables, selected):
        super().__init__(parent)
        self.setWindowTitle("Groups selection")
        v = QVBoxLayout(self)
        self.lst = QListWidget()
        for i, name in enumerate(variables, 1):
            it = QListWidgetItem(f"{i} ({name})")
            it.setData(Qt.UserRole, name)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if name in selected else Qt.Unchecked)
            self.lst.addItem(it)
        v.addWidget(self.lst)
        self.count = QLabel()
        v.addWidget(self.count)
        row = QHBoxLayout()
        self.all = QCheckBox("Select all")
        ok = QPushButton("OK"); ok.setDefault(True)
        row.addWidget(self.all); row.addStretch(); row.addWidget(ok)
        v.addLayout(row)
        ok.clicked.connect(self.accept)
        self.lst.itemChanged.connect(lambda _: self._update())
        self.all.clicked.connect(self._select_all)
        self.resize(320, 420)
        self._update()

    def _checked(self):
        return [self.lst.item(i).data(Qt.UserRole) for i in range(self.lst.count())
                if self.lst.item(i).checkState() == Qt.Checked]

    def _update(self):
        n, tot = len(self._checked()), self.lst.count()
        self.count.setText(f"{n} / {tot} selected column{'s' if n > 1 else ''}")
        self.all.blockSignals(True); self.all.setChecked(n == tot); self.all.blockSignals(False)

    def _select_all(self, on):
        self.lst.blockSignals(True)
        for i in range(self.lst.count()):
            self.lst.item(i).setCheckState(Qt.Checked if on else Qt.Unchecked)
        self.lst.blockSignals(False)
        self._update()

    def selection(self):
        return self._checked()


class SpliceToolWidget(QWidget):
    titleChanged = Signal(str)

    def __init__(self, host):
        super().__init__()
        self.host = host                      # fenêtre principale (accès aux datasets)
        self.datasets = []                    # entrées : dict(key, name, well, df, units, depth_unit, use)
        self.rows = []
        self.sel_vars = None                  # None = toutes les variables
        self.col_show = {"Variable": True, "Top": True, "Bottom": True}
        self.colmap = []
        self._building = False
        self.out_name, self.step, self.unit = "Merged_Set", 0.5, "ft"
        self._step_user = False

        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        self.tabs = QTabWidget(); self.tabs.setDocumentMode(True)
        self.inputs = DropTable(0, 4)
        self.inputs.setHorizontalHeaderLabels(["Use", "Group", "Well", "Dataset"])
        self.inputs.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.inputs.datasetsDropped.connect(self.add_datasets)
        self.inputs.cellDoubleClicked.connect(self._toggle_input)
        self.inputs.horizontalHeader().setStretchLastSection(False)
        self.limits = QTableWidget()
        self.limits.setContextMenuPolicy(Qt.CustomContextMenu)
        self.limits.customContextMenuRequested.connect(self._menu)
        self.limits.itemChanged.connect(self._item_changed)
        self.limits.cellDoubleClicked.connect(self._toggle_used)
        self.tabs.addTab(self.inputs, "Inputs")
        self.tabs.addTab(self.limits, "Limits")
        v.addWidget(self.tabs, 1)

        self.placeholder = QLabel("Please drop your\ndatasets here", self.inputs.viewport())
        f = QFont(); f.setPointSize(14); f.setBold(True)
        self.placeholder.setFont(f); self.placeholder.setStyleSheet("color:#9a9a9a; background:transparent;")
        self.placeholder.move(4, 6)

        bar = QWidget(); hb = QHBoxLayout(bar); hb.setContentsMargins(6, 3, 6, 3)
        hb.addWidget(QLabel("Dataset output:"))
        self.ed_out = QLineEdit(self.out_name); self.ed_out.setFixedWidth(120)
        self.ed_out.editingFinished.connect(self._out_changed)
        hb.addWidget(self.ed_out)
        hb.addWidget(QLabel("Sampling rate:"))
        self.sp_step = QDoubleSpinBox(); self.sp_step.setDecimals(4); self.sp_step.setRange(0.0001, 1000)
        self.sp_step.setValue(self.step); self.sp_step.setKeyboardTracking(False)
        self.sp_step.valueChanged.connect(self._step_changed)
        hb.addWidget(self.sp_step)
        self.lb_unit = QLabel(f"Unit: {self.unit}")
        hb.addWidget(self.lb_unit)
        hb.addStretch()
        self.btn_refresh = QToolButton(); self.btn_refresh.setText("⟳"); self.btn_refresh.setToolTip("Refresh")
        self.btn_refresh.clicked.connect(self.refresh)
        self.mode = QComboBox(); self.mode.addItems(["display", "save", "save and display"])
        self.btn_run = QToolButton(); self.btn_run.setText("▶"); self.btn_run.setToolTip("Run")
        self.btn_run.setStyleSheet("QToolButton { color:#1b7fd0; font-size:16px; }")
        self.btn_run.clicked.connect(self.run)
        hb.addWidget(self.btn_refresh); hb.addWidget(self.mode); hb.addWidget(self.btn_run)
        v.addWidget(bar)
        self.rebuild_inputs()

    # ---------------------------------------------------------------- titre
    def window_title(self):
        return (f"Variables splice table  Dataset output: {self.out_name} "
                f"[Unit: {self.unit}] [Sampling rate: {self.step:g}]")

    def _emit_title(self):
        self.lb_unit.setText(f"Unit: {self.unit}")
        self.titleChanged.emit(self.window_title())

    def _out_changed(self):
        self.out_name = self.ed_out.text().strip() or "Merged_Set"
        self.ed_out.setText(self.out_name)
        self._emit_title()

    def _step_changed(self, v):
        self.step, self._step_user = float(v), True
        self._emit_title()

    # --------------------------------------------------------------- Inputs
    def add_datasets(self, keys):
        for k in keys:
            if any(d["key"] == k for d in self.datasets):
                continue
            info = self.host.dataset_info(k)
            if info:
                info["use"] = True
                self.datasets.append(info)
        self.rebuild_inputs()
        self.rebuild_rows()

    def rebuild_inputs(self):
        t = self.inputs
        t.setRowCount(len(self.datasets))
        for r, d in enumerate(self.datasets):
            for c, txt in enumerate(("yes" if d["use"] else "no", "", d["well"], d["name"])):
                it = QTableWidgetItem(txt)
                if c == 3:
                    f = it.font(); f.setBold(True); it.setFont(f)
                t.setItem(r, c, it)
        t.resizeColumnsToContents()
        self.placeholder.setVisible(not self.datasets)
        if not self.datasets:
            self.placeholder.move(4, t.horizontalHeader().height() + 6)

    def _toggle_input(self, row, col):
        if col == 0 and row < len(self.datasets):
            self.datasets[row]["use"] = not self.datasets[row]["use"]
            self.rebuild_inputs()
            self.rebuild_rows()

    def used_datasets(self):
        return [d for d in self.datasets if d["use"]]

    # --------------------------------------------------------------- Limits
    def visible_rows(self):
        return [r for r in self.rows if self.sel_vars is None or r.var in self.sel_vars]

    def rebuild_rows(self):
        old = {r.var: r for r in self.rows}
        self.rows = build_rows(self.used_datasets())
        for r in self.rows:
            o = old.get(r.var)
            if o:
                r.used, r.out_name, r.out_unit = o.used, o.out_name, o.out_unit
        used = self.used_datasets()
        if used:
            self.unit = used[0]["depth_unit"]
            if not self._step_user:
                self.step = default_step(used)
                self.sp_step.blockSignals(True); self.sp_step.setValue(self.step); self.sp_step.blockSignals(False)
        self.rebuild_limits()
        self._emit_title()

    def refresh(self):
        self.rebuild_inputs()
        self.rebuild_rows()

    def rebuild_limits(self):
        self._building = True
        t = self.limits
        t.clear()
        rows = self.visible_rows()
        P = max([len(r.segs) for r in rows] or [0])
        self.colmap = [("used",)] + [x for p in range(P) for x in
                                     (("pos", p), ("ds", p), ("top", p), ("bottom", p))] + [("out",), ("unit",)]
        heads = ["Used"] + ["Position", "Dataset.variable", "Top", "Bottom"] * P + ["Output variable", "Output unit"]
        t.setColumnCount(len(heads)); t.setRowCount(len(rows))
        t.setHorizontalHeaderLabels(heads)
        t.setVerticalHeaderLabels([r.var for r in rows])
        dsnames = {d["key"]: d for d in self.used_datasets()}
        for ri, r in enumerate(rows):
            self._cell(ri, 0, "yes" if r.used else "no", editable=False)
            for p in range(P):
                base = 1 + 4 * p
                col = QColor(POS_COLORS[p % len(POS_COLORS)])
                if p < len(r.segs):
                    s = r.segs[p]
                    self._cell(ri, base, str(p + 1), editable=False, bg=col)
                    cb = QComboBox()
                    opts = [f"{d['name']}.{r.var}" for d in self.used_datasets()
                            if any(str(c) == r.var for c in d["df"].columns)]
                    cb.addItems(opts)
                    cb.setCurrentText(f"{s.dsname}.{r.var}")
                    cb.currentTextChanged.connect(lambda txt, row=r, pos=p: self._ds_changed(row, pos, txt))
                    t.setCellWidget(ri, base + 1, cb)
                    self._cell(ri, base + 2, f"{s.top:g}", bg=col)
                    self._cell(ri, base + 3, f"{s.bottom:g}", bg=col)
                else:
                    for k in range(4):
                        self._cell(ri, base + k, "", editable=False, bg=QColor("#f0f0f0"))
            self._cell(ri, len(self.colmap) - 2, r.out_name, bg=QColor(YELLOW))
            cu = QComboBox(); cu.setEditable(True)
            cu.addItems(UNITS)
            if r.out_unit and cu.findText(r.out_unit) < 0:
                cu.addItem(r.out_unit)
            cu.setCurrentText(r.out_unit)
            cu.currentTextChanged.connect(lambda txt, row=r: setattr(row, "out_unit", txt))
            t.setCellWidget(ri, len(self.colmap) - 1, cu)
        t.resizeColumnsToContents()
        for ci, m in enumerate(self.colmap):
            if m[0] == "ds":
                t.setColumnWidth(ci, 120)
        self._apply_hidden()
        self._building = False

    def _cell(self, r, c, text, editable=True, bg=None):
        it = QTableWidgetItem(text)
        if not editable:
            it.setFlags(it.flags() & ~Qt.ItemIsEditable)
        if bg is not None:
            it.setBackground(QBrush(bg))
        self.limits.setItem(r, c, it)

    def _apply_hidden(self):
        for ci, m in enumerate(self.colmap):
            hide = ((m[0] == "ds" and not self.col_show["Variable"]) or
                    (m[0] == "top" and not self.col_show["Top"]) or
                    (m[0] == "bottom" and not self.col_show["Bottom"]))
            self.limits.setColumnHidden(ci, hide)

    def _ds_changed(self, row, pos, text):
        if self._building:
            return
        dsname = text[:-(len(row.var) + 1)]
        d = next((x for x in self.used_datasets() if x["name"] == dsname), None)
        if not d:
            return
        col = next(c for c in d["df"].columns if str(c) == row.var)
        ext = valid_extent(d["df"].index.values, d["df"][col].values)
        if ext:
            row.segs[pos] = Seg(d["key"], d["name"], row.var, ext[0], ext[1], ext[0], ext[1])
            auto_bounds(row)
            self.rebuild_limits()

    def _toggle_used(self, ri, ci):
        if ci == 0 and ri < len(self.visible_rows()):
            r = self.visible_rows()[ri]
            r.used = not r.used
            self.limits.item(ri, 0).setText("yes" if r.used else "no")

    def _item_changed(self, item):
        if self._building:
            return
        rows = self.visible_rows()
        if item.row() >= len(rows):
            return
        r = rows[item.row()]
        kind = self.colmap[item.column()]
        if kind[0] in ("top", "bottom"):
            try:
                v = float(item.text().replace(",", "."))
            except ValueError:
                self.rebuild_limits(); return
            setattr(r.segs[kind[1]], kind[0], v)
            auto_bounds(r)
        elif kind[0] == "out":
            r.out_name = item.text().strip() or f"{r.var}_Merged"

    # ------------------------------------------------------- menu clic droit
    def _menu(self, pos):
        m = QMenu(self)
        sub = m.addMenu("Display the columns")
        for name in ("Variable", "Top", "Bottom"):
            a = sub.addAction(name); a.setCheckable(True); a.setChecked(self.col_show[name])
            a.toggled.connect(lambda on, n=name: self._toggle_col(n, on))
        m.addAction("Select the variables...", self.select_variables)
        m.exec(self.limits.viewport().mapToGlobal(pos))

    def _toggle_col(self, name, on):
        self.col_show[name] = on
        self._apply_hidden()

    def select_variables(self):
        names = [r.var for r in self.rows]
        if not names:
            return
        dlg = GroupsDialog(self, names, names if self.sel_vars is None else self.sel_vars)
        if dlg.exec() == QDialog.Accepted:
            sel = dlg.selection()
            self.sel_vars = None if len(sel) == len(names) else sel
            self.rebuild_limits()

    # ----------------------------------------------------------- exécution
    def spec(self):
        used = self.used_datasets()
        well = next((d["well"] for d in used if d["well"]), "")
        return {"name": self.out_name, "step": self.step, "depth_unit": self.unit, "well": well}

    def run(self):
        rows = [r for r in self.visible_rows() if r.used]
        if not rows:
            QMessageBox.information(self, "GeoLog", "Drop datasets in Inputs and select at least one variable.")
            return
        mode = self.mode.currentText()
        if "save" in mode:
            self.host.save_merged(self.spec(), rows)
        if "display" in mode:
            self.host.open_splice_graphs(self, rows)
