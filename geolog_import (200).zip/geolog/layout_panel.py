"""Properties d'un « Multi well layout » : onglets Limits | Wells | Display options."""
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QDoubleValidator
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox,
                               QCheckBox, QSpinBox, QPushButton, QTabWidget, QScrollArea,
                               QColorDialog, QFrame)

import logview_icons as ic
from properties_panel import Section, glyph_icon

GRID_TITLES = ("Main reference grid", "Secondary reference grid", "Tertiary reference grid")
SCALES = ["20", "50", "100", "200", "500", "1000", "2000", "5000"]


class LayoutPanel(QWidget):
    def __init__(self):
        super().__init__()
        self.lv = None
        self.canvas = None
        self._loading = False
        self._conn = None
        self._sync_static = []
        self._sync_wells = []

        root = QVBoxLayout(self); root.setContentsMargins(4, 4, 4, 4); root.setSpacing(4)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search"); self.search.setEnabled(False)
        root.addWidget(self.search)
        head = QHBoxLayout()
        icon = QLabel(); icon.setPixmap(ic.i_logview().pixmap(18, 18))
        self.title = QLabel("Multi well layout"); f = self.title.font(); f.setBold(True); self.title.setFont(f)
        head.addWidget(icon); head.addWidget(self.title, 1)
        root.addLayout(head)

        self.tabs = QTabWidget(); self.tabs.setDocumentMode(True)
        self.tabs.addTab(self._scroll(self._build_limits()), glyph_icon("1", "#1b7fd0"), "Limits")
        self.wells_host = QWidget(); self.wells_box = QVBoxLayout(self.wells_host)
        self.wells_box.setContentsMargins(0, 0, 0, 0); self.wells_box.setSpacing(2)
        self.tabs.addTab(self._scroll(self.wells_host), glyph_icon("A", "#1f4f8f"), "Wells")
        self.tabs.addTab(self._scroll(self._build_display()), glyph_icon("◆", "#8e44ad"), "Display options")
        root.addWidget(self.tabs, 1)

    # ------------------------------------------------------------- utilitaires
    def _scroll(self, w):
        sa = QScrollArea(); sa.setWidgetResizable(True); sa.setFrameShape(QFrame.NoFrame)
        sa.setWidget(w); return sa

    def _page(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(2)
        return w, v

    def _apply(self):
        if self.canvas:
            self.canvas.view_changed()
        self.sync()

    def sync(self):
        if not self.canvas:
            return
        self._loading = True
        try:
            for fn in self._sync_static + self._sync_wells:
                fn()
        finally:
            self._loading = False

    # champs génériques : (section, libellé, getter, setter, bucket de synchro)
    def _f_check(self, sec, text, get, set_, bucket, enabled=None):
        cb = QCheckBox(text)
        cb.toggled.connect(lambda v: None if self._loading else (set_(bool(v)), self._apply()))
        sec.form.addRow(cb)

        def sync():
            cb.setChecked(bool(get()))
            if enabled:
                cb.setEnabled(enabled())
        bucket.append(sync)
        return cb

    def _f_num(self, sec, label, get, set_, bucket, enabled=None, fmt="{:g}"):
        ed = QLineEdit(); ed.setValidator(QDoubleValidator())

        def done():
            if self._loading:
                return
            try:
                v = float(ed.text().replace(",", "."))
            except ValueError:
                self.sync(); return
            set_(v); self._apply()
        ed.editingFinished.connect(done)
        sec.form.addRow(label, ed)

        def sync():
            ed.setText(fmt.format(get()))
            if enabled:
                ed.setEnabled(enabled())
        bucket.append(sync)
        return ed

    def _f_spin(self, sec, label, get, set_, bucket, lo, hi):
        sp = QSpinBox(); sp.setRange(lo, hi); sp.setKeyboardTracking(False)
        sp.valueChanged.connect(lambda v: None if self._loading else (set_(int(v)), self._apply()))
        sec.form.addRow(label, sp)
        bucket.append(lambda: sp.setValue(int(get())))
        return sp

    def _f_color(self, sec, label, get, set_, bucket):
        b = QPushButton(); b.setFixedSize(44, 18)

        def pick():
            col = QColorDialog.getColor(QColor(get()), self, "Select Color")
            if col.isValid():
                set_(col.name()); self._apply()
        b.clicked.connect(pick)
        sec.form.addRow(label, b)
        bucket.append(lambda: b.setStyleSheet(f"background:{get()}; border:1px solid #555;"))
        return b

    def _grid_section(self, parent_sec, title, get_grid, setter, bucket, sub=True):
        """Spacing / Thickness / Visible / Color d'une grille de référence."""
        sec = Section(title, glyph_icon("≡", "#555"), sub=sub)
        g = lambda: get_grid()
        self._f_num(sec, "Spacing", lambda: g().spacing, lambda v: setter("spacing", v), bucket)
        self._f_spin(sec, "Thickness", lambda: g().thickness, lambda v: setter("thickness", v), bucket, 1, 10)
        self._f_check(sec, "Visible", lambda: g().visible, lambda v: setter("visible", v), bucket)
        self._f_color(sec, "Color", lambda: g().color, lambda v: setter("color", v), bucket)
        if parent_sec is not None:
            parent_sec.form.addRow(sec)
        return sec

    # ----------------------------------------------------------- onglet Limits
    def _build_limits(self):
        w, v = self._page()
        top = Section("", None); top.head.hide()
        cb = QComboBox(); cb.setEditable(True); cb.addItems(SCALES); cb.setValidator(QDoubleValidator(1, 1e6, 2))

        def set_scale():
            if self._loading or not self.canvas:
                return
            try:
                self.canvas.set_scale(float(cb.currentText().replace(",", ".")))
            except ValueError:
                pass
            self.sync()
        cb.lineEdit().editingFinished.connect(set_scale)
        cb.activated.connect(lambda _: set_scale())
        top.form.addRow("Scale 1:", cb)
        self._sync_static.append(lambda: cb.setCurrentText(f"{self.canvas.scale:g}"))
        shift = QCheckBox("Shift"); shift.setEnabled(False); top.form.addRow(shift)
        v.addWidget(top)

        rl = Section("Reference limitation", glyph_icon("I", "#333"))
        lim = QCheckBox("Limitation"); lim.setEnabled(False); lim.setToolTip("Zone-based limitation: needs zones (not available yet)")
        rl.form.addRow(lim)
        for lab in ("Zonation", "Top zones", "Bottom zones", "Top zone delta", "Bottom zone delta"):
            ed = QLineEdit(); ed.setEnabled(False); rl.form.addRow(lab, ed)
        ref = QComboBox(); ref.addItem("Default_Ref"); ref.setEnabled(False); rl.form.addRow("Reference", ref)
        unit = QComboBox(); unit.setEnabled(False); unit.addItem("M")
        rl.form.addRow("Unit", unit)

        def sync_unit():
            unit.clear(); unit.addItem(self.canvas.ref_unit)
        self._sync_static.append(sync_unit)
        v.addWidget(rl)

        wd = Section("Wells distances", glyph_icon("↔", "#1b7fd0"))
        a = QCheckBox("Activate"); a.setEnabled(False); wd.form.addRow(a)
        for lab, items in (("Track unit", ["cm"]), ("Real value", ["500"]), ("Real unit", ["km"])):
            c = QComboBox(); c.addItems(items); c.setEnabled(False); wd.form.addRow(lab, c)
        v.addWidget(wd)

        for i, title in enumerate(GRID_TITLES):
            def setter(attr, val, i=i):
                setattr(self.canvas.grids[i], attr, val)
                for ws in self.canvas.wells.values():          # le layout impose ses grilles aux puits
                    setattr(ws.grids[i], attr, val)
            v.addWidget(self._grid_section(None, title, lambda i=i: self.canvas.grids[i], setter,
                                           self._sync_static, sub=False))
        v.addStretch()
        return w

    # ------------------------------------------------------------ onglet Wells
    def rebuild_wells(self):
        while self.wells_box.count():
            it = self.wells_box.takeAt(0)
            wd = it.widget()
            if wd:
                wd.hide(); wd.setParent(None); wd.deleteLater()      # disparaît tout de suite
        self._sync_wells = []
        if not self.canvas:
            return
        for name in self.canvas.well_names():
            self.wells_box.addWidget(self._build_well(name))
        self.wells_box.addStretch()

    def _build_well(self, name):
        cv = self.canvas
        ws = lambda: cv.well_settings(name)
        sec = Section(name or "(no well)", ic.i_assign())
        bucket = self._sync_wells

        rl = Section("Reference limitation", None, sub=True)

        def set_limit(on):
            w = ws(); w.ref_limit = on
            if on and w.top == w.bottom:
                w.top, w.bottom = cv.well_real(name)
        self._f_check(rl, "Limitation", lambda: ws().ref_limit, set_limit, bucket)
        self._f_num(rl, "Top", lambda: ws().top if ws().ref_limit else cv.well_real(name)[0],
                    lambda x: setattr(ws(), "top", x), bucket, enabled=lambda: ws().ref_limit)
        self._f_num(rl, "Bottom", lambda: ws().bottom if ws().ref_limit else cv.well_real(name)[1],
                    lambda x: setattr(ws(), "bottom", x), bucket, enabled=lambda: ws().ref_limit)
        real = Section("Real", None, sub=True)
        self._f_num(real, "Top", lambda: cv.well_real(name)[0], lambda x: None, bucket, enabled=lambda: False)
        self._f_num(real, "Bottom", lambda: cv.well_real(name)[1], lambda x: None, bucket, enabled=lambda: False)
        rl.form.addRow(real)
        sec.form.addRow(rl)

        for i, title in enumerate(GRID_TITLES):
            self._grid_section(sec, title, lambda i=i: ws().grids[i],
                               lambda attr, val, i=i: setattr(ws().grids[i], attr, val), bucket)
        return sec

    # --------------------------------------------------- onglet Display options
    def _build_display(self):
        w, v = self._page()
        hd = Section("Headers", glyph_icon("H", "#7ac943"))
        self._f_check(hd, "Layout header", lambda: self.canvas.show_layout_header,
                      lambda x: setattr(self.canvas, "show_layout_header", x), self._sync_static)
        self._f_check(hd, "Well header", lambda: self.canvas.show_well_header,
                      lambda x: setattr(self.canvas, "show_well_header", x), self._sync_static)
        v.addWidget(hd)

        tr = Section("Tracks", glyph_icon("|||", "#555"))

        def set_width(x):
            for t in self.canvas.tracks:
                t.width = x
        self._f_spin(tr, "Track width (px)", lambda: self.canvas.tracks[0].width if self.canvas.tracks else 190,
                     set_width, self._sync_static, 60, 800)

        def set_lines(x):
            for t in self.canvas.tracks:
                t.grid_lines = x
        self._f_spin(tr, "Vertical grid lines", lambda: self.canvas.tracks[0].grid_lines if self.canvas.tracks else 4,
                     set_lines, self._sync_static, 1, 12)
        v.addWidget(tr)
        v.addStretch()
        return w

    # ----------------------------------------------------------------- API
    def set_view(self, lv):
        if self._conn:
            try:
                self._conn[0].viewChanged.disconnect(self._conn[1])
                self._conn[0].contentChanged.disconnect(self._conn[2])
            except (RuntimeError, TypeError):
                pass
            self._conn = None
        self.lv = lv
        self.canvas = lv.canvas if lv else None
        self.setEnabled(lv is not None)
        if not lv:
            self.title.setText("Multi well layout")
            return
        self.title.setText(f"Multi well layout ({lv.window_title()})")
        self.rebuild_wells()
        self.sync()
        f1 = self._on_view
        f2 = self._on_content
        lv.canvas.viewChanged.connect(f1); lv.canvas.contentChanged.connect(f2)
        self._conn = (lv.canvas, f1, f2)

    def _on_view(self):
        if self.canvas:
            self.title.setText(f"Multi well layout ({self.lv.window_title()})")
            self.sync()

    def _on_content(self):
        self.rebuild_wells()
        self.sync()
