"""Import de fichiers texte / tableur (Lesson 4 du cours : Data import wizard)."""
import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

import las_info

TYPES = ["Reference", "Well name", "Dataset name", "Variable", "Zone name", "Top", "Bottom", "Remove column"]
TYPE_COLORS = {"Reference": "#f5b942", "Well name": "#9cc7ee", "Dataset name": "#9fd48f", "Variable": "#ffffff",
               "Zone name": "#c9c9c9", "Top": "#f3e27a", "Bottom": "#c98a6b", "Remove column": "#eeeeee"}
DTYPES = ["continuous", "point data", "interval"]
DEPTH_NAMES = {"MD", "DEPT", "DEPTH", "TVD", "TVDSS", "REF", "REFERENCE", "MEASURED_DEPTH", "PROFONDEUR", "Z"}


@dataclass
class AsciiSettings:
    dtype: str = "continuous"
    well: str = ""
    dataset: str = ""
    start_line: int = 2
    name_line: int = 1
    unit_line: int = 0
    data_type: str = "delimited"        # delimited | fixed
    decimal_comma: bool = False
    col_size: int = 10
    from_col: int = 0
    zonation: str = "default"           # default | zonation (Top / Bottom)
    semicolon: bool = False
    tab: bool = True
    space: bool = False
    comma: bool = False
    others: str = ""
    keep_consecutive: bool = True       # oui = les séparateurs consécutifs donnent des colonnes vides
    text_id: str = "automatic"
    mv: float = -999.25


@dataclass
class Table:
    headers: list
    units: list
    rows: list

    @property
    def ncols(self):
        return len(self.headers)


def read_lines(path):
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            with open(path, encoding=enc) as f:
                return f.read().splitlines()
        except UnicodeDecodeError:
            continue
    return []


def read_xlsx_rows(path, sheet=0):
    df = pd.read_excel(path, header=None, sheet_name=sheet, dtype=object)
    return [["" if pd.isna(v) else str(v) for v in r] for r in df.values.tolist()]


def _delims(st):
    d = []
    if st.semicolon: d.append(";")
    if st.tab: d.append("\t")
    if st.space: d.append(" ")
    if st.comma: d.append(",")
    return set(d) | set(st.others)


def split_line(line, st):
    if st.data_type == "fixed":
        w = max(1, st.col_size)
        return [line[i:i + w].strip() for i in range(0, len(line), w)]
    ds = _delims(st)
    if not ds:
        return [line.strip()]
    quotes = {"automatic": '"', '"': '"', "'": "'", "none": ""}.get(st.text_id, '"')
    out, cur, q = [], [], None
    for ch in line:
        if q:
            if ch == q:
                q = None
            else:
                cur.append(ch)
        elif quotes and ch == quotes:
            q = ch
        elif ch in ds:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(ch)
    out.append("".join(cur).strip())
    if not st.keep_consecutive:
        out = [t for t in out if t != ""]
    return out


def tokenize(lines, st):
    return [split_line(l, st) for l in lines]


def to_number(s, st=None):
    s = str(s).strip()
    if s == "":
        return None
    if st is not None and st.decimal_comma:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def parse_table(all_rows, st):
    data = [r for r in all_rows[max(0, st.start_line - 1):] if any(t != "" for t in r)]
    n = max((len(r) for r in data[:300]), default=0)
    n = max(0, n - st.from_col)
    cut = lambda r: (list(r) + [""] * (st.from_col + n))[st.from_col:st.from_col + n]

    def line(k):
        if 0 < k <= len(all_rows):
            r = list(all_rows[k - 1])
            return r + [""] * (st.from_col + n - len(r)) if len(r) >= n else [""] * (n - len(r)) + r   # aligné à droite
        return [""] * n
    names = cut(line(st.name_line)) if st.name_line > 0 else [""] * n
    units = cut(line(st.unit_line)) if st.unit_line > 0 else [""] * n
    return Table(names, units, [cut(r) for r in data])


def _numeric_ratio(rows, i, st):
    vals = [r[i] for r in rows[:200] if r[i] != ""]
    return (sum(to_number(v, st) is not None for v in vals) / len(vals)) if vals else 0.0


def guess_types(table, st):
    n = table.ncols
    types = ["Variable"] * n
    num = [_numeric_ratio(table.rows, i, st) >= 0.9 for i in range(n)]
    up = [h.strip().upper() for h in table.headers]
    zon = st.zonation == "zonation"
    for i in range(n):
        h = up[i]
        if h in ("WELL", "WELLNAME", "WELL_NAME", "UWI", "WELL NAME") and not num[i]:
            types[i] = "Well name"
        elif h in ("DATASET", "DATASET_NAME", "DATASET NAME") and not num[i]:
            types[i] = "Dataset name"
        elif zon and h in ("BOTTOM", "BASE", "BOT") and num[i]:
            types[i] = "Bottom"
        elif zon and (h in ("TOP",) or h in DEPTH_NAMES) and num[i] and "Top" not in types:
            types[i] = "Top"
        elif not zon and h in DEPTH_NAMES and num[i] and "Reference" not in types:
            types[i] = "Reference"
    texts = [i for i in range(n) if not num[i] and types[i] == "Variable"]
    if "Well name" not in types and texts and (len(texts) >= 3 or (len(texts) == 2 and texts[0] == 0)):
        types[texts[0]] = "Well name"; texts = texts[1:]          # colonnes sans titre : puits, dataset, zone...
    if "Dataset name" not in types and "Well name" in types and len(texts) >= 2:
        types[texts[0]] = "Dataset name"; texts = texts[1:]
    first_num = [i for i in range(n) if num[i] and types[i] == "Variable"]
    if zon:
        if "Top" not in types and first_num:
            types[first_num.pop(0)] = "Top"
        if "Bottom" not in types and first_num:
            types[first_num.pop(0)] = "Bottom"
    elif "Reference" not in types and first_num:
        types[first_num.pop(0)] = "Reference"
    has_vars = bool(first_num)                                    # des variables numériques en plus de la référence ?
    for i in texts:                                               # colonnes texte restantes = noms de zones (intervalles)
        types[i] = "Zone name" if (st.dtype == "interval" or zon or not has_vars) else "Remove column"
    return types


def detect_settings(lines):
    """« Parameters detection » : séparateur, lignes d'en-tête et de données."""
    st = AsciiSettings()
    sample = [l for l in lines[:30] if l.strip()]
    best = None
    for key, ch in (("tab", "\t"), ("semicolon", ";"), ("comma", ","), ("space", " ")):
        counts = [l.count(ch) for l in sample]
        if counts and min(counts) >= 1 and max(counts) - min(counts) <= 1:
            best = key; break
    st.tab = st.semicolon = st.comma = st.space = False
    setattr(st, best or "tab", True)
    st.keep_consecutive = best != "space"
    rows = tokenize(lines, st)
    isnum = lambda r: any(to_number(t) is not None for t in r)
    first = next((i for i, r in enumerate(rows) if any(r) and isnum(r)), 0)
    st.start_line = first + 1
    st.name_line = first if first >= 1 and any(rows[first - 1]) else 0
    st.unit_line = 0
    if first >= 2 and any(rows[first - 1]) and any(rows[first - 2]) and \
            all(len(t) <= 8 for t in rows[first - 1]):
        st.name_line, st.unit_line = first - 1, first
    return st


def build_datasets(table, types, names, units, st, stem):
    """Regroupe les lignes par (puits, dataset) et crée les datasets prêts à enregistrer."""
    n = table.ncols
    zon = st.zonation == "zonation"
    ref_t = "Top" if zon else "Reference"
    if ref_t not in types:
        raise ValueError(f"A '{ref_t}' column is mandatory (set it in the Type row).")
    ref_i = types.index(ref_t)
    well_i = types.index("Well name") if "Well name" in types else None
    ds_i = types.index("Dataset name") if "Dataset name" in types else None
    cols, seen = [], {}
    for i in range(n):
        if types[i] in ("Variable", "Zone name", "Bottom"):
            nm = (names[i] or f"COL{i + 1}").strip()
            if types[i] == "Bottom" and nm == (names[ref_i] or "").strip():
                nm = "BOTTOM"
            seen[nm] = seen.get(nm, 0) + 1
            if seen[nm] > 1:
                nm = f"{nm}_{seen[nm]}"
            cols.append((i, nm))
    groups = {}
    for r in table.rows:
        ref = to_number(r[ref_i], st)
        if ref is None:
            continue
        w = (r[well_i] if well_i is not None else "") or st.well or stem
        d = (r[ds_i] if ds_i is not None else "") or st.dataset or stem
        groups.setdefault((w, d), []).append((ref, r))
    dtype = "interval" if zon else st.dtype
    out = []
    for (w, d), items in groups.items():
        data = {}
        for i, nm in cols:
            if types[i] == "Zone name":
                data[nm] = [r[i] for _, r in items]
            else:
                v = np.array([np.nan if to_number(r[i], st) is None else to_number(r[i], st) for _, r in items])
                v[np.isclose(v, st.mv)] = np.nan
                data[nm] = v
        df = pd.DataFrame(data, index=[x for x, _ in items]).sort_index()
        meta = {nm: {"unit": (units[i] or "").strip(), "family": las_info.family_of(nm), "descr": ""} for i, nm in cols}
        out.append({"well": w, "name": d, "dtype": dtype, "ref_name": (names[ref_i] or "MD").strip() or "MD",
                    "ref_unit": (units[ref_i] or "").strip(), "df": df, "columns": meta})
    return out
