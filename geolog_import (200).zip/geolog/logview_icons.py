"""Icônes dessinées en code (barre d'outils LogView + ruban Plot)."""
import math
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import (QIcon, QPixmap, QPainter, QPen, QColor, QPolygonF, QPainterPath,
                           QFont, QBrush)

BLUE, DBLUE, RED, ORANGE, GREEN, PURPLE, GRAY = ("#1b7fd0", "#1f4f8f", "#d9382b", "#f39c12",
                                                  "#2ca02c", "#8e44ad", "#666666")


def _new(size=32):
    pm = QPixmap(size, size); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    return pm, p


def _pen(color, w=1.5):
    return QPen(QColor(color), w, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)


def _poly(pts):
    return QPolygonF([QPointF(x, y) for x, y in pts])


def _wiggle(p, x0, y0, y1, amp, color, w=1.4, phase=0.0):
    path = QPainterPath(QPointF(x0, y0))
    n = 14
    for i in range(1, n + 1):
        y = y0 + (y1 - y0) * i / n
        path.lineTo(x0 + amp * math.sin(i * 1.3 + phase), y)
    p.setPen(_pen(color, w)); p.setBrush(Qt.NoBrush); p.drawPath(path)


def _done(p, pm):
    p.end(); return QIcon(pm)


def _box(p, size=32):
    p.setPen(_pen("#333", 1.4)); p.setBrush(QColor("#fdfdfd"))
    p.drawRoundedRect(QRectF(5, 5, size - 10, size - 10), 2, 2)


def _arrow(p, x, y, dx, dy, color="#222", s=3.2):
    p.setPen(_pen(color, 1.4)); p.drawLine(QPointF(x, y), QPointF(x + dx, y + dy))
    ang = math.atan2(dy, dx); tip = QPointF(x + dx, y + dy)
    p.setBrush(QColor(color))
    p.drawPolygon(_poly([(tip.x(), tip.y()),
                         (tip.x() - s * 1.6 * math.cos(ang - .5), tip.y() - s * 1.6 * math.sin(ang - .5)),
                         (tip.x() - s * 1.6 * math.cos(ang + .5), tip.y() - s * 1.6 * math.sin(ang + .5))]))


# ------------------------------------------------------ barre d'outils LogView
def i_select():
    pm, p = _new()
    p.setPen(_pen("#ffffff", 3)); p.setBrush(QColor("#111"))
    pts = [(9, 5), (9, 25), (14, 20), (18, 28), (21, 26.5), (17, 19), (24, 19)]
    p.drawPolygon(_poly(pts)); p.setPen(_pen("#111", 1)); p.drawPolygon(_poly(pts))
    return _done(p, pm)


def i_interactive():
    pm, p = _new()
    pen = _pen(DBLUE, 2.2); pen.setStyle(Qt.DashLine); p.setPen(pen)
    p.drawEllipse(QRectF(6, 6, 20, 20))
    p.setPen(Qt.NoPen); p.setBrush(QColor(DBLUE)); p.drawEllipse(QRectF(13, 13, 6, 6))
    return _done(p, pm)


def i_eraser():
    pm, p = _new()
    p.save(); p.translate(16, 16); p.rotate(-40)
    p.setPen(_pen("#555", 1)); p.setBrush(QColor("#ef7f9a")); p.drawRoundedRect(QRectF(-12, -6, 12, 12), 2, 2)
    p.setBrush(QColor(BLUE)); p.drawRoundedRect(QRectF(0, -6, 12, 12), 2, 2)
    p.restore()
    return _done(p, pm)


def i_zoom():
    pm, p = _new()
    p.setPen(_pen(DBLUE, 3)); p.setBrush(QColor("#d8ecfb")); p.drawEllipse(QRectF(5, 5, 17, 17))
    p.setPen(_pen("#333", 4)); p.drawLine(QPointF(20, 20), QPointF(28, 28))
    p.setPen(_pen(DBLUE, 2)); p.drawLine(QPointF(10, 13.5), QPointF(17, 13.5)); p.drawLine(QPointF(13.5, 10), QPointF(13.5, 17))
    return _done(p, pm)


def i_hand():
    pm, p = _new()
    p.setPen(_pen("#222", 1.2)); p.setBrush(QColor("#fafafa"))
    for i, (x, h) in enumerate([(9, 11), (13, 14), (17, 14), (21, 12)]):
        p.drawRoundedRect(QRectF(x, 5 + (14 - h), 3.6, h + 6), 1.8, 1.8)
    p.drawRoundedRect(QRectF(8, 15, 17, 12), 5, 5)
    p.drawRoundedRect(QRectF(4.5, 14, 4, 10), 2, 2)
    return _done(p, pm)


def i_graph_mod():
    pm, p = _new(); _wiggle(p, 10, 4, 28, 5, DBLUE, 2.0)
    p.setPen(_pen("#555", 1)); p.setBrush(QColor(ORANGE)); p.drawPolygon(_poly([(16, 26), (27, 12), (30, 15), (19, 29)]))
    return _done(p, pm)


def i_annot():
    pm, p = _new()
    p.setPen(_pen("#444", 1.5)); p.setBrush(QColor("#f4f4f4"))
    p.drawRoundedRect(QRectF(5, 6, 22, 16), 4, 4); p.drawPolygon(_poly([(10, 22), (10, 28), (16, 22)]))
    p.setPen(_pen("#777", 1.3)); p.drawLine(9, 12, 23, 12); p.drawLine(9, 16, 20, 16)
    return _done(p, pm)


def i_zones(plus=True):
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, c in enumerate(["#c0392b", "#f39c12", "#f1c40f", "#8e44ad"]):
        p.setBrush(QColor(c)); p.drawRect(QRectF(5, 6 + i * 5, 20, 5))
    if plus:
        p.setBrush(QColor(GREEN)); p.setPen(_pen("#fff", 1)); p.drawEllipse(QRectF(17, 17, 12, 12))
        p.setPen(_pen("#fff", 2)); p.drawLine(23, 19.5, 23, 26.5); p.drawLine(19.5, 23, 26.5, 23)
    return _done(p, pm)


def i_zone_editor():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, c in enumerate(["#c0392b", "#f39c12", "#f1c40f", "#2980b9"]):
        p.setBrush(QColor(c)); p.drawRect(QRectF(5, 6 + i * 5, 20, 5))
    _arrow(p, 27, 8, 0, 6, "#222"); _arrow(p, 27, 26, 0, -6, "#222")
    return _done(p, pm)


def i_markers():
    pm, p = _new(); p.setPen(_pen(BLUE, 2.2))
    for y in (9, 15, 21): p.drawLine(6, y, 22, y)
    p.setPen(_pen("#555", 1)); p.setBrush(QColor(ORANGE)); p.drawPolygon(_poly([(15, 27), (25, 13), (28, 16), (18, 30)]))
    return _done(p, pm)


def i_split():
    pm, p = _new(); _wiggle(p, 7, 5, 27, 3, DBLUE, 2.0, 0.5)
    _arrow(p, 14, 16, 9, 0, RED); _wiggle(p, 25, 5, 27, 3, DBLUE, 2.0, 2.0)
    return _done(p, pm)


def i_depth_inter():
    pm, p = _new(); p.setPen(_pen("#222", 1.6))
    for y in (13, 19, 25): p.drawLine(5, y, 12, y)
    _arrow(p, 20, 15, 0, -9, "#222"); _arrow(p, 20, 17, 0, 10, "#222")
    p.setPen(_pen(DBLUE, 2)); p.drawLine(5, 6, 28, 6)
    return _done(p, pm)


def i_regression():
    pm, p = _new(); p.setPen(_pen(ORANGE, 3))
    p.drawLine(7, 24, 21, 8); p.setBrush(QColor(ORANGE)); p.setPen(Qt.NoPen)
    p.drawEllipse(QRectF(5, 7, 6, 6)); p.drawEllipse(QRectF(17, 19, 6, 6))
    p.setBrush(QColor(GREEN)); p.drawEllipse(QRectF(18, 18, 12, 12))
    p.setPen(_pen("#fff", 2)); p.drawLine(24, 20.5, 24, 27.5); p.drawLine(20.5, 24, 27.5, 24)
    return _done(p, pm)


def i_values():
    pm, p = _new()
    p.setPen(_pen(RED, 2)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(7, 6, 8, 8))
    p.setPen(_pen("#222", 1)); p.setBrush(QColor("#fff7c0")); p.drawRect(QRectF(7, 17, 19, 10))
    f = QFont("Arial", 6); f.setBold(True); p.setFont(f); p.drawText(QRectF(7, 17, 19, 10), Qt.AlignCenter, "1.7")
    return _done(p, pm)


def i_poslines():
    pm, p = _new(); p.setPen(_pen(RED, 2)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(10, 11, 10, 10))
    p.drawLine(3, 16, 10, 16); p.drawLine(20, 16, 29, 16)
    p.setPen(_pen(DBLUE, 1.4)); p.drawLine(15, 3, 15, 11); p.drawLine(15, 21, 15, 29)
    return _done(p, pm)


def i_vadj():
    pm, p = _new(); _box(p); _arrow(p, 16, 15, 0, -6); _arrow(p, 16, 17, 0, 6)
    return _done(p, pm)


def i_hadj():
    pm, p = _new(); _box(p); _arrow(p, 15, 16, -6, 0); _arrow(p, 17, 16, 6, 0)
    return _done(p, pm)


def i_gadj():
    pm, p = _new(); _box(p)
    for dx, dy in ((-5, -5), (5, -5), (-5, 5), (5, 5)):
        _arrow(p, 16 + dx * .35, 16 + dy * .35, dx, dy, "#222", 2.6)
    return _done(p, pm)


def i_auto_h():
    pm, p = _new(); _box(p); _arrow(p, 13, 14, -4, 0); _arrow(p, 15, 14, 4, 0)
    p.setPen(_pen("#222", 1)); p.setBrush(QColor(ORANGE)); p.drawRoundedRect(QRectF(17, 19, 11, 9), 1.5, 1.5)
    p.setBrush(Qt.NoBrush); p.setPen(_pen("#222", 1.5)); p.drawArc(QRectF(19, 14, 7, 9), 0, 180 * 16)
    return _done(p, pm)


def i_one_one():
    pm, p = _new(); _box(p)
    f = QFont("Arial", 8); f.setBold(True); p.setFont(f); p.setPen(QColor("#111"))
    p.drawText(QRectF(5, 5, 22, 22), Qt.AlignCenter, "1:1")
    return _done(p, pm)


# ------------------------------------------------------------- ruban Plot
def i_logview():
    pm, p = _new()
    p.setPen(_pen("#555", 1.3)); p.setBrush(QColor("#fff")); p.drawRoundedRect(QRectF(3, 3, 26, 26), 2, 2)
    for x in (11, 20): p.drawLine(x, 3, x, 29)
    _wiggle(p, 7, 6, 27, 2.3, DBLUE, 1.5); _wiggle(p, 15.5, 6, 27, 2.3, RED, 1.5, 1.0)
    _wiggle(p, 24.5, 6, 27, 2.3, GREEN, 1.5, 2.0)
    return _done(p, pm)


def i_scatter():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for (x, y, c) in [(6, 22, BLUE), (11, 15, RED), (15, 19, ORANGE), (19, 11, GREEN), (24, 7, PURPLE),
                      (9, 9, ORANGE), (22, 21, BLUE), (14, 8, GREEN), (26, 15, RED)]:
        p.setBrush(QColor(c)); p.drawEllipse(QRectF(x - 2.6, y - 2.6, 5.2, 5.2))
    p.setPen(_pen("#555", 1.4)); p.drawLine(3, 4, 3, 28); p.drawLine(3, 28, 29, 28)
    return _done(p, pm)


def i_lineplot():
    pm, p = _new(); _wiggle(p, 8, 5, 27, 4, RED, 2); _wiggle(p, 20, 5, 27, 4, DBLUE, 2, 1.2)
    return _done(p, pm)


def i_hist():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, (h, c) in enumerate([(12, "#f39c12"), (22, "#8e44ad"), (17, "#1b7fd0"), (8, "#e74c3c")]):
        p.setBrush(QColor(c)); p.drawRect(QRectF(5 + i * 6.3, 28 - h, 5.2, h))
    return _done(p, pm)


def i_boxplot():
    pm, p = _new(); p.setPen(_pen("#222", 1.3))
    for x, c in ((10, GREEN), (22, BLUE)):
        p.drawLine(x, 4, x, 28); p.setBrush(QColor(c)); p.drawRect(QRectF(x - 5, 11, 10, 10))
        p.drawLine(x - 5, 16, x + 5, 16)
    return _done(p, pm)


def i_star():
    pm, p = _new()
    p.setPen(_pen("#555", 1.4)); p.setBrush(QColor("#f1f1f1")); p.drawEllipse(QRectF(4, 4, 24, 24))
    p.setPen(_pen(BLUE, 1.6))
    for k in range(6):
        a = k * math.pi / 3; p.drawLine(QPointF(16, 16), QPointF(16 + 11 * math.cos(a), 16 + 11 * math.sin(a)))
    return _done(p, pm)


def i_scatter_array():
    pm, p = _new(); p.setPen(_pen("#555", 1))
    for i in range(2):
        for j in range(2):
            p.setBrush(QColor("#fff")); p.drawRect(QRectF(4 + i * 13, 4 + j * 13, 11, 11))
            p.setPen(Qt.NoPen); p.setBrush(QColor([BLUE, RED, GREEN, ORANGE][i * 2 + j]))
            for dx, dy in ((3, 7), (6, 4), (8, 8)): p.drawEllipse(QRectF(4 + i * 13 + dx - 1.2, 4 + j * 13 + dy - 1.2, 2.4, 2.4))
            p.setPen(_pen("#555", 1))
    return _done(p, pm)


def i_more():
    pm, p = _new(); p.setPen(Qt.NoPen)
    cols = [BLUE, RED, GREEN, ORANGE, PURPLE, BLUE, RED, GREEN, ORANGE]
    for k in range(9):
        p.setBrush(QColor(cols[k])); p.drawRect(QRectF(5 + (k % 3) * 8.5, 5 + (k // 3) * 8.5, 6.5, 6.5))
    return _done(p, pm)


def i_cube():
    pm, p = _new(); p.setPen(_pen(DBLUE, 1.6)); p.setBrush(QColor("#e6f1fb"))
    p.drawPolygon(_poly([(16, 4), (28, 10), (28, 22), (16, 28), (4, 22), (4, 10)]))
    p.drawLine(16, 16, 16, 28); p.drawLine(16, 16, 4, 10); p.drawLine(16, 16, 28, 10)
    return _done(p, pm)


def i_curve_var():
    """Petite icône 'variable' (le $ bleu) pour l'en-tête des Properties."""
    pm, p = _new(20)
    path = QPainterPath(QPointF(13, 3)); path.cubicTo(3, 3, 14, 10, 8, 10); path.cubicTo(3, 10, 14, 17, 7, 17)
    p.setPen(_pen(BLUE, 2.4)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    return _done(p, pm)


# ===================================================== rubans contextuels
def _sheet(p, x, y, w, h, fill="#ffffff", edge="#555"):
    p.setPen(_pen(edge, 1.2)); p.setBrush(QColor(fill)); p.drawRoundedRect(QRectF(x, y, w, h), 2, 2)


def _floppy(p, color=BLUE):
    p.setPen(_pen("#1d3557", 1.2)); p.setBrush(QColor(color)); p.drawRoundedRect(QRectF(5, 4, 22, 24), 2.5, 2.5)
    p.setBrush(QColor("#f4f4f4")); p.drawRect(QRectF(9, 4, 14, 8)); p.setBrush(QColor("#1d3557")); p.drawRect(QRectF(10, 17, 12, 9))


# ---- Multi well layout
def i_duplicate():
    pm, p = _new(); _sheet(p, 4, 4, 17, 20, "#e8f1fb"); _sheet(p, 11, 9, 17, 20)
    _wiggle(p, 19, 12, 27, 2.5, DBLUE, 1.3); return _done(p, pm)


def i_horizontal():
    pm, p = _new(); _sheet(p, 3, 6, 26, 20)
    path = QPainterPath(QPointF(5, 16))
    for i in range(1, 12): path.lineTo(5 + i * 2, 16 + 5 * math.sin(i * 1.2))
    p.setPen(_pen(RED, 1.6)); p.setBrush(Qt.NoBrush); p.drawPath(path); return _done(p, pm)


def i_apply():
    pm, p = _new(); _sheet(p, 15, 14, 14, 14, "#e8f1fb"); _arrow(p, 4, 10, 16, 0, GREEN, 4)
    p.setPen(_pen(GREEN, 2.2)); p.drawLine(4, 10, 20, 10); _arrow(p, 22, 10, 0, 6, GREEN, 3); return _done(p, pm)


def i_goto():
    pm, p = _new(); _sheet(p, 5, 3, 16, 22)
    p.setPen(_pen("#777", 1.1))
    for y in (8, 12, 16): p.drawLine(8, y, 18, y)
    p.setPen(_pen(DBLUE, 2.4)); p.setBrush(Qt.NoBrush); p.drawEllipse(QRectF(14, 15, 10, 10))
    p.setPen(_pen("#333", 3)); p.drawLine(22, 23, 28, 29); return _done(p, pm)


def i_well_dl():
    pm, p = _new(); p.setPen(_pen(BLUE, 3.2)); p.drawLine(16, 4, 16, 20); p.drawLine(9, 14, 16, 21); p.drawLine(23, 14, 16, 21)
    p.setPen(_pen("#333", 3)); p.drawLine(7, 27, 25, 27); return _done(p, pm)


def i_grab():
    pm, p = _new(); p.setPen(_pen("#222", 1.2)); p.setBrush(QColor("#555")); p.drawRoundedRect(QRectF(3, 9, 26, 18), 3, 3)
    p.drawRect(QRectF(11, 5, 10, 5)); p.setBrush(QColor("#e8e8e8")); p.drawEllipse(QRectF(10, 12, 12, 12))
    p.setBrush(QColor("#333")); p.drawEllipse(QRectF(13, 15, 6, 6)); return _done(p, pm)


def i_print():
    pm, p = _new(); _sheet(p, 9, 3, 14, 10); p.setPen(_pen("#222", 1.2)); p.setBrush(QColor("#9aa4ad"))
    p.drawRoundedRect(QRectF(3, 12, 26, 12), 2, 2); _sheet(p, 9, 19, 14, 9); return _done(p, pm)


def i_save_menu():
    pm, p = _new(); _floppy(p); return _done(p, pm)


def i_save_props():
    pm, p = _new(); _floppy(p, "#6b8fd1"); p.setPen(_pen("#fff", 1)); p.setBrush(QColor(PURPLE))
    p.drawPolygon(_poly([(24, 16), (30, 22), (24, 28), (18, 22)])); return _done(p, pm)


def i_save_vars():
    pm, p = _new(); _floppy(p, "#5d7fc4"); p.setPen(Qt.NoPen); p.setBrush(QColor(RED)); p.drawEllipse(QRectF(19, 3, 10, 10))
    p.setPen(_pen("#fff", 1.8)); p.drawLine(24, 5.5, 24, 9); p.drawPoint(QPointF(24, 11)); return _done(p, pm)


def i_refresh():
    pm, p = _new(); p.setPen(_pen("#2aa7c9", 3)); p.setBrush(Qt.NoBrush)
    p.drawArc(QRectF(6, 6, 20, 20), 40 * 16, 250 * 16); _arrow(p, 22, 4, 4, 6, "#2aa7c9", 3.5)
    _sheet(p, 12, 12, 8, 8, "#fff", "#2aa7c9"); return _done(p, pm)


def i_edit_props():
    pm, p = _new(); p.setPen(_pen("#2a7fbf", 1.2)); p.setBrush(QColor("#4aa3df"))
    p.drawPolygon(_poly([(16, 3), (28, 15), (16, 27), (4, 15)])); p.setPen(_pen("#fff", 1.6))
    p.drawLine(11, 15, 21, 15); p.drawLine(16, 10, 16, 20); return _done(p, pm)


def i_select_menu():
    pm, p = _new(); _sheet(p, 4, 4, 24, 24, "#fff", "#555")
    for x, c in ((10, BLUE), (16, RED), (22, GREEN)): _wiggle(p, x, 7, 26, 2, c, 1.2, x)
    return _done(p, pm)


def i_reload():
    pm, p = _new(); _wiggle(p, 10, 5, 27, 3, GREEN, 2.4); _arrow(p, 18, 7, 8, 0, GREEN, 3.4); _arrow(p, 26, 24, -8, 0, GREEN, 3.4)
    return _done(p, pm)


def i_overview():
    pm, p = _new(); p.setPen(_pen(DBLUE, 1.4)); p.setBrush(QColor("#d8ecfb"))
    p.drawPolygon(_poly([(16, 4), (22, 28), (10, 28)])); p.setPen(_pen(RED, 1.6)); p.drawLine(5, 14, 27, 14); return _done(p, pm)


def i_layout_hdr():
    pm, p = _new(); _sheet(p, 4, 6, 24, 20); p.setPen(Qt.NoPen); p.setBrush(QColor("#e6ee2a")); p.drawRect(QRectF(5, 7, 22, 6))
    p.setBrush(QColor("#7ac943")); p.drawRect(QRectF(5, 13, 22, 4)); p.setPen(_pen("#777", 1))
    p.drawLine(11, 17, 11, 25); p.drawLine(19, 17, 19, 25); return _done(p, pm)


def i_well_hdr():
    pm, p = _new(); _sheet(p, 4, 6, 24, 20); p.setPen(Qt.NoPen); p.setBrush(QColor("#7ac943")); p.drawRect(QRectF(5, 7, 22, 7))
    p.setPen(_pen("#777", 1)); p.drawLine(11, 14, 11, 25); p.drawLine(19, 14, 19, 25); return _done(p, pm)


def i_tooltips():
    pm, p = _new(); _sheet(p, 4, 6, 24, 14, "#fff7c0"); p.setPen(_pen("#555", 1.2)); p.setBrush(QColor("#fff7c0"))
    p.drawPolygon(_poly([(10, 20), (10, 27), (17, 20)]))
    p.setPen(_pen("#777", 1.4)); p.drawLine(8, 11, 24, 11); p.drawLine(8, 15, 20, 15); return _done(p, pm)


def i_wells_color():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for x, c in ((6, RED), (13, BLUE), (20, GREEN)): p.setBrush(QColor(c)); p.drawRect(QRectF(x, 8 + (x % 3) * 2, 6, 18))
    return _done(p, pm)


def i_baselines():
    pm, p = _new(); p.setPen(Qt.NoPen); p.setBrush(QColor("#2ca02c"))
    p.drawPolygon(_poly([(6, 6), (6, 26), (16, 26), (12, 16), (16, 6)])); p.setPen(_pen("#222", 1.4)); p.drawLine(16, 4, 16, 28)
    return _done(p, pm)


def i_insert_grid():
    pm, p = _new(); _sheet(p, 5, 5, 22, 22); p.setPen(_pen("#777", 1.2))
    for v in (12, 20): p.drawLine(v, 5, v, 27); p.drawLine(5, v, 27, v)
    return _done(p, pm)


def i_advanced():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, c in enumerate(["#e74c3c", "#f39c12", "#f1c40f", "#8e44ad"]): p.setBrush(QColor(c)); p.drawRect(QRectF(5, 5 + i * 5.5, 22, 5.5))
    p.setPen(_pen("#333", 1.4)); p.drawLine(5, 5, 5, 28); return _done(p, pm)


# ---- Variable
def i_reverse():
    pm, p = _new(); _sheet(p, 5, 4, 22, 24, "#e8f1fb"); _arrow(p, 8, 12, 16, 0, DBLUE, 3); _arrow(p, 24, 20, -16, 0, DBLUE, 3)
    return _done(p, pm)


def i_alias():
    pm, p = _new(); path = QPainterPath(QPointF(18, 4)); path.cubicTo(5, 4, 20, 14, 12, 14); path.cubicTo(5, 14, 20, 26, 8, 26)
    p.setPen(_pen(GREEN, 3.4)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    p.setPen(Qt.NoPen); p.setBrush(QColor(DBLUE)); p.drawEllipse(QRectF(19, 3, 11, 11))
    p.setPen(_pen("#fff", 2)); p.drawLine(24.5, 5, 24.5, 12); p.drawLine(21, 8.5, 28, 8.5); return _done(p, pm)


def i_assign():
    pm, p = _new(); p.setPen(_pen(DBLUE, 2)); p.drawLine(16, 3, 7, 29); p.drawLine(16, 3, 25, 29)
    for y, hw in ((12, 4.5), (20, 7)): p.drawLine(16 - hw, y, 16 + hw, y)
    p.drawLine(7, 29, 25, 29); return _done(p, pm)


def i_harmonized():
    pm, p = _new(); p.setPen(_pen("#8a6d00", 1)); 
    for i, c in enumerate(["#f1c40f", "#e6b800", "#f39c12"]):
        p.setBrush(QColor(c)); p.drawRoundedRect(QRectF(6 + i * 4, 5 + i * 3, 14, 20), 2, 2)
    return _done(p, pm)


def i_shift():
    pm, p = _new(); _wiggle(p, 12, 4, 28, 3, DBLUE, 2.0); p.setPen(_pen(RED, 1.6)); p.drawLine(18, 4, 18, 28)
    _arrow(p, 18, 16, 8, 0, RED, 3); return _done(p, pm)


def _abc(p, color):
    p.setPen(Qt.NoPen); p.setBrush(QColor(color)); p.drawRoundedRect(QRectF(3, 4, 18, 8), 1.5, 1.5)
    f = QFont("Arial", 5); f.setBold(True); p.setFont(f); p.setPen(QColor("#fff")); p.drawText(QRectF(3, 4, 18, 8), Qt.AlignCenter, "ABC")


def i_edit_vals():
    pm, p = _new(); _abc(p, "#6b6b6b"); _wiggle(p, 8, 14, 28, 2.5, DBLUE, 1.6)
    p.setPen(_pen("#555", 1)); p.setBrush(QColor(ORANGE)); p.drawPolygon(_poly([(17, 28), (25, 14), (28, 17), (20, 30)])); return _done(p, pm)


def i_del_sel():
    pm, p = _new(); _abc(p, "#6b6b6b"); _wiggle(p, 8, 14, 28, 2.5, DBLUE, 1.6)
    p.setPen(_pen(RED, 2.6)); p.drawLine(18, 17, 28, 27); p.drawLine(28, 17, 18, 27); return _done(p, pm)


def i_del_non():
    pm, p = _new(); _abc(p, "#9a9a9a"); _wiggle(p, 8, 14, 28, 2.5, "#9aa4ad", 1.6)
    p.setPen(_pen(RED, 2.6)); p.drawLine(18, 17, 28, 27); p.drawLine(28, 17, 18, 27); return _done(p, pm)


def i_palettes():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, c in enumerate(["#2ecc71", "#f1c40f", "#e74c3c"]): p.setBrush(QColor(c)); p.drawRect(QRectF(5 + i * 7.3, 6, 7.3, 20))
    return _done(p, pm)


def i_points():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for (x, y, c) in [(8, 9, RED), (16, 8, BLUE), (24, 11, GREEN), (11, 19, ORANGE), (20, 22, PURPLE)]:
        p.setBrush(QColor(c)); p.drawEllipse(QRectF(x - 3, y - 3, 6, 6))
    return _done(p, pm)


def i_textmode():
    pm, p = _new(); f = QFont("Arial", 7); f.setBold(True); p.setFont(f); p.setPen(QColor("#222"))
    p.drawText(QRectF(2, 3, 28, 12), Qt.AlignCenter, "40|50"); p.drawText(QRectF(2, 15, 28, 12), Qt.AlignCenter, "60|80")
    return _done(p, pm)


def i_insert_var():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, c in enumerate(["#1abc9c", "#2ecc71", "#f1c40f", "#e67e22"]): p.setBrush(QColor(c)); p.drawRect(QRectF(6, 5 + i * 5.5, 20, 5.5))
    p.setBrush(QColor(DBLUE)); p.drawEllipse(QRectF(18, 17, 11, 11)); p.setPen(_pen("#fff", 2)); p.drawLine(23.5, 19, 23.5, 26); p.drawLine(20, 22.5, 27, 22.5)
    return _done(p, pm)


def i_processing():
    pm, p = _new(); path = QPainterPath(QPointF(6, 8)); path.cubicTo(24, 2, 4, 18, 26, 12); path.cubicTo(8, 28, 26, 20, 22, 28)
    p.setPen(_pen(RED, 2.6)); p.setBrush(Qt.NoBrush); p.drawPath(path); p.setPen(_pen(BLUE, 1.6)); p.drawLine(6, 28, 26, 28)
    return _done(p, pm)


# ===================================================== onglet Data (Techdata / Techdata+)
def _table(p, x=4, y=5, w=24, h=22, head="#1b7fd0", cols=3, rows=4):
    p.setPen(_pen("#555", 1.1)); p.setBrush(QColor("#fff")); p.drawRect(QRectF(x, y, w, h))
    p.setPen(Qt.NoPen); p.setBrush(QColor(head)); p.drawRect(QRectF(x, y, w, 5))
    p.setPen(_pen("#9a9a9a", 0.9))
    for c in range(1, cols): p.drawLine(QPointF(x + w * c / cols, y), QPointF(x + w * c / cols, y + h))
    for r in range(1, rows): p.drawLine(QPointF(x, y + 5 + (h - 5) * r / rows), QPointF(x + w, y + 5 + (h - 5) * r / rows))


def i_data_editor():
    pm, p = _new(); _table(p); p.setPen(_pen(ORANGE, 2)); p.drawLine(18, 27, 28, 17); return _done(p, pm)


def i_zone_table():
    pm, p = _new(); _table(p, head="#c0392b")
    p.setPen(Qt.NoPen)
    for i, c in enumerate(["#f1c40f", "#2ecc71", "#e67e22"]): p.setBrush(QColor(c)); p.drawRect(QRectF(5, 11 + i * 5, 7, 4))
    return _done(p, pm)


def i_equation():
    pm, p = _new(); f = QFont("Times New Roman", 13); f.setItalic(True); p.setFont(f); p.setPen(QColor("#2a4d9b"))
    p.drawText(QRectF(2, 1, 28, 18), Qt.AlignCenter, "f(x)")
    path = QPainterPath(QPointF(3, 25)); path.cubicTo(10, 14, 16, 34, 29, 21)
    p.setPen(_pen(BLUE, 2.2)); p.setBrush(Qt.NoBrush); p.drawPath(path); return _done(p, pm)


def i_array_editor():
    pm, p = _new(16); p.setPen(_pen("#555", 1)); p.setBrush(QColor("#fff")); p.drawRect(QRectF(1, 2, 14, 12))
    p.setPen(Qt.NoPen); p.setBrush(QColor(RED)); p.drawRect(QRectF(1, 2, 14, 3)); p.setBrush(QColor(BLUE)); p.drawRect(QRectF(3, 7, 5, 4))
    return _done(p, pm)


def i_combiner():
    pm, p = _new(); p.setPen(_pen("#2a8c9b", 2.4)); p.setBrush(Qt.NoBrush)
    for y in (8, 16, 24): p.drawLine(4, y, 13, 16)
    p.drawLine(13, 16, 24, 16); _arrow(p, 22, 16, 6, 0, "#2a8c9b", 3.6); return _done(p, pm)


def i_toolbox():
    pm, p = _new(); p.setPen(_pen("#7a1d12", 1.2)); p.setBrush(QColor("#d6392b")); p.drawRoundedRect(QRectF(3, 10, 26, 17), 2.5, 2.5)
    p.setBrush(Qt.NoBrush); p.setPen(_pen("#333", 2)); p.drawRoundedRect(QRectF(11, 4, 10, 8), 2, 2)
    p.setPen(_pen("#f6c445", 2)); p.drawLine(3, 18, 29, 18); return _done(p, pm)


def i_splice():
    pm, p = _new(); p.setPen(_pen(BLUE, 2.6)); p.setBrush(Qt.NoBrush)
    for y in (8, 16, 24): p.drawLine(3, y, 11, y)
    p.drawLine(11, 8, 17, 16); p.drawLine(11, 24, 17, 16); p.drawLine(11, 16, 17, 16)
    _arrow(p, 17, 16, 11, 0, DBLUE, 3.6); return _done(p, pm)


def i_resampling():
    pm, p = _new(16); p.setPen(_pen("#555", 1)); p.setBrush(QColor("#fff")); p.drawRoundedRect(QRectF(1, 1, 14, 14), 1.5, 1.5)
    p.setPen(Qt.NoPen); p.setBrush(QColor(BLUE))
    for (x, y) in ((4, 4), (10, 4), (4, 10), (10, 10)): p.drawEllipse(QRectF(x - 1.4, y - 1.4, 2.8, 2.8))
    return _done(p, pm)


def i_mathpack():
    pm, p = _new(16); f = QFont("Arial", 10); f.setBold(True); p.setFont(f); p.setPen(QColor("#222")); p.drawText(QRectF(0, 0, 16, 16), Qt.AlignCenter, "√")
    p.setPen(_pen(BLUE, 1.6)); p.drawPoint(QPointF(12.5, 11)); return _done(p, pm)


def i_refcoords():
    pm, p = _new(); p.setPen(Qt.NoPen); p.setBrush(QColor("#9b59b6"))
    p.drawPolygon(_poly([(7, 5), (14, 5), (14, 27), (7, 27)])); p.setBrush(QColor("#c39bd3"))
    p.drawPolygon(_poly([(14, 8), (24, 4), (24, 26), (14, 24)])); p.setPen(_pen("#fff", 1.2)); p.drawLine(9, 11, 12, 11); p.drawLine(9, 17, 12, 17)
    return _done(p, pm)


def i_families():
    pm, p = _new(16); p.setPen(Qt.NoPen)
    for i, (h, c) in enumerate([(7, "#2ca02c"), (12, "#1b7fd0"), (9, "#d9382b")]): p.setBrush(QColor(c)); p.drawRect(QRectF(2 + i * 4.6, 14 - h, 3.8, h))
    return _done(p, pm)


def i_aliases():
    pm, p = _new(16); p.setPen(_pen(GREEN, 2.4)); p.setBrush(Qt.NoBrush)
    path = QPainterPath(QPointF(11, 2)); path.cubicTo(2, 2, 11, 8, 6, 8); path.cubicTo(2, 8, 11, 14, 4, 14); p.drawPath(path)
    p.setPen(_pen("#222", 1.4)); p.drawLine(11, 13, 15, 9); return _done(p, pm)


def _db(p, x, y, c1, c2):
    p.setPen(_pen("#8a5a00", 1)); 
    for k in range(3):
        p.setBrush(QColor(c1 if k % 2 == 0 else c2)); p.drawRoundedRect(QRectF(x, y + k * 6, 18, 8), 4, 4)


def i_mining():
    pm, p = _new(); _db(p, 6, 4, "#f4b43c", "#e69a1f"); p.setPen(_pen("#555", 1.4)); p.setBrush(Qt.NoBrush); p.drawEllipse(QRectF(16, 16, 9, 9))
    p.setPen(_pen("#333", 2.4)); p.drawLine(23, 24, 28, 29); return _done(p, pm)


def i_harmonization():
    pm, p = _new(); _db(p, 5, 4, "#f4b43c", "#e69a1f"); p.setPen(Qt.NoPen); p.setBrush(QColor(RED)); p.drawEllipse(QRectF(17, 15, 12, 12))
    p.setPen(_pen("#fff", 1.6)); p.setBrush(Qt.NoBrush); p.drawArc(QRectF(19.5, 17.5, 7, 7), 40 * 16, 270 * 16); return _done(p, pm)


def i_query_rename():
    pm, p = _new(); p.setPen(_pen("#555", 1.2)); p.setBrush(QColor("#fff")); p.drawRect(QRectF(3, 9, 26, 14))
    p.setPen(_pen("#111", 1.8)); p.drawLine(16, 5, 16, 27); p.drawLine(12, 5, 20, 5); p.drawLine(12, 27, 20, 27); return _done(p, pm)


def i_firstlast():
    pm, p = _new(); p.setPen(_pen("#555", 1)); p.setBrush(QColor(BLUE)); p.drawPolygon(_poly([(4, 14), (16, 8), (16, 20)]))
    p.setBrush(QColor(RED)); p.drawRoundedRect(QRectF(18, 4, 11, 11), 2, 2); p.setPen(_pen("#fff", 2)); p.drawLine(21, 7, 26, 12); p.drawLine(26, 7, 21, 12)
    return _done(p, pm)


def i_wellpredict():
    pm, p = _new(); p.setPen(_pen(DBLUE, 2)); p.drawLine(12, 3, 4, 29); p.drawLine(12, 3, 20, 29)
    for y, hw in ((12, 3.5), (20, 6)): p.drawLine(12 - hw, y, 12 + hw, y)
    p.setPen(Qt.NoPen); p.setBrush(QColor(BLUE)); p.drawEllipse(QRectF(17, 4, 12, 12))
    f = QFont("Arial", 8); f.setBold(True); p.setFont(f); p.setPen(QColor("#fff")); p.drawText(QRectF(17, 4, 12, 12), Qt.AlignCenter, "?")
    return _done(p, pm)


def i_python():
    pm, p = _new(); p.setPen(Qt.NoPen); p.setBrush(QColor("#2e6ba6")); p.drawRoundedRect(QRectF(5, 4, 14, 14), 4, 4)
    p.setBrush(QColor("#f5c518")); p.drawRoundedRect(QRectF(13, 14, 14, 14), 4, 4)
    p.setBrush(QColor("#fff")); p.drawEllipse(QRectF(8, 7, 3, 3)); p.drawEllipse(QRectF(21, 21, 3, 3)); return _done(p, pm)


def i_sp_auto():
    pm, p = _new(); _wiggle(p, 9, 4, 28, 3, DBLUE, 1.8); p.setPen(_pen("#2f8fd6", 2.4)); p.drawLine(4, 16, 28, 16)
    _arrow(p, 22, 8, 0, 6, "#2f8fd6", 3); return _done(p, pm)


def i_sp_close():
    pm, p = _new(); _sheet(p, 4, 5, 24, 22); p.setPen(_pen(RED, 3)); p.drawLine(11, 12, 21, 22); p.drawLine(21, 12, 11, 22); return _done(p, pm)
