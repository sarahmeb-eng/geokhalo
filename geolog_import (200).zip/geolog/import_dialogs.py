"""Petites boîtes de dialogue de l'import / export : sélection conditionnelle, Selective DLIS, export, tableau de données."""
import os
import re

import pandas as pd
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QComboBox, QPushButton,
                               QTreeWidget, QTreeWidgetItem, QFileDialog, QCheckBox, QTableWidget,
                               QTableWidgetItem, QWidget, QAbstractItemView, QMessageBox, QListWidget,
                               QListWidgetItem)


class ConditionalSelectionDialog(QDialog):
    """« Create a conditional selection » : sélectionne les datasets dont le nom / le puits répond à une condition."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create a conditional selection")
        v = QVBoxLayout(self)
        row = QHBoxLayout()
        self.field = QComboBox(); self.field.addItems(["Dataset name", "Well name"])
        self.op = QComboBox(); self.op.addItems(["equals", "contains", "starts with", "ends with",
                                                  "does not contain", "matches regex"])
        self.op.setCurrentText("contains")
        self.text = QLineEdit()
        row.addWidget(self.field); row.addWidget(self.op); row.addWidget(self.text, 1)
        v.addLayout(row)
        self.case = QCheckBox("Case sensitive"); v.addWidget(self.case)
        b = QHBoxLayout(); b.addStretch()
        ok, cancel = QPushButton("Select"), QPushButton("Cancel"); ok.setDefault(True)
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        b.addWidget(ok); b.addWidget(cancel); v.addLayout(b)
        self.setMinimumWidth(460)

    def matcher(self):
        op, txt, cs = self.op.currentText(), self.text.text(), self.case.isChecked()
        norm = (lambda s: s) if cs else (lambda s: s.casefold())
        t = norm(txt)

        def test(value):
            s = norm(value)
            return {"equals": s == t, "contains": t in s, "starts with": s.startswith(t),
                    "ends with": s.endswith(t), "does not contain": t not in s,
                    "matches regex": bool(re.search(txt, value, 0 if cs else re.I))}[op]
        return self.field.currentText(), test


class SelectiveDlisDialog(QDialog):
    """Selective DLIS import : on voit les frames / canaux avant de charger les données."""

    def __init__(self, frames, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Selective DLIS import")
        v = QVBoxLayout(self)
        self.tree = QTreeWidget(); self.tree.setHeaderLabels(["Frame / channel", "Unit", "Description"])
        for name, well, chans in frames:
            top = QTreeWidgetItem(self.tree, [f"{name}   [{well}]"]); top.setData(0, Qt.UserRole, name)
            top.setFlags(top.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate); top.setCheckState(0, Qt.Checked)
            for k, (cn, cu, cd) in enumerate(chans):
                it = QTreeWidgetItem(top, [cn, cu, cd]); it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                it.setCheckState(0, Qt.Checked)
                if k == 0:
                    it.setToolTip(0, "Index (reference) channel")
        self.tree.resizeColumnToContents(0)
        v.addWidget(QLabel("Tick the frames and channels to load (the first channel is the reference):"))
        v.addWidget(self.tree)
        b = QHBoxLayout(); b.addStretch()
        ok, cancel = QPushButton("OK"), QPushButton("Cancel"); ok.setDefault(True)
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        b.addWidget(ok); b.addWidget(cancel); v.addLayout(b)
        self.resize(640, 480)

    def selection(self):
        sel = {}
        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            chans = {top.child(k).text(0) for k in range(top.childCount())
                     if top.child(k).checkState(0) == Qt.Checked}
            if chans:
                sel[top.data(0, Qt.UserRole)] = chans
        return sel


class ExportDialog(QDialog):
    """Export (LAS, CSV, TXT, XLSX) des datasets choisis."""
    FORMATS = ["LAS 2.0 (*.las)", "CSV (*.csv)", "ASCII tab-delimited (*.txt)", "Excel (*.xlsx)"]

    def __init__(self, names, preselected, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Export")
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Datasets to export:"))
        self.lst = QListWidget()
        for n in names:
            it = QListWidgetItem(n); it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if n in preselected else Qt.Unchecked); self.lst.addItem(it)
        v.addWidget(self.lst)
        row = QHBoxLayout(); row.addWidget(QLabel("Format:"))
        self.fmt = QComboBox(); self.fmt.addItems(self.FORMATS); row.addWidget(self.fmt, 1); v.addLayout(row)
        row = QHBoxLayout(); self.folder = QLineEdit(); b = QPushButton("...")
        b.clicked.connect(lambda: self.folder.setText(QFileDialog.getExistingDirectory(self, "Export folder") or self.folder.text()))
        row.addWidget(QLabel("Folder:")); row.addWidget(self.folder, 1); row.addWidget(b); v.addLayout(row)
        bb = QHBoxLayout(); bb.addStretch()
        ok, cancel = QPushButton("Export"), QPushButton("Cancel"); ok.setDefault(True)
        ok.clicked.connect(self._ok); cancel.clicked.connect(self.reject)
        bb.addWidget(ok); bb.addWidget(cancel); v.addLayout(bb)
        self.resize(460, 420)

    def _ok(self):
        if not self.folder.text().strip():
            QMessageBox.information(self, "Export", "Choose an export folder."); return
        self.accept()

    def chosen(self):
        return [self.lst.item(i).text() for i in range(self.lst.count()) if self.lst.item(i).checkState() == Qt.Checked]


def export_dataset(df, name, well, ref_name, ref_unit, units, folder, fmt):
    """Écrit un dataset ; retourne le chemin du fichier."""
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{well}_{name}" if well else name)
    out = df.copy(); out.index.name = ref_name or "MD"
    if fmt.startswith("LAS"):
        import lasio
        las = lasio.LASFile()
        las.well["WELL"].value = well or name
        du = "F" if str(ref_unit).lower().startswith("f") else (ref_unit or "M")
        las.append_curve(out.index.name, out.index.values, unit=du, descr="Reference")
        for c in out.columns:
            if pd.api.types.is_numeric_dtype(out[c]):
                las.append_curve(str(c), out[c].values, unit=units.get(str(c), ""), descr="")
        path = os.path.join(folder, safe + ".las")
        las.write(path, version=2.0)
    elif fmt.startswith("CSV"):
        path = os.path.join(folder, safe + ".csv"); out.to_csv(path)
    elif fmt.startswith("ASCII"):
        path = os.path.join(folder, safe + ".txt"); out.to_csv(path, sep="\t")
    else:
        path = os.path.join(folder, safe + ".xlsx"); out.to_excel(path)
    return path


class DataTableWidget(QWidget):
    """Visualisation d'un dataset en tableau (contrôle qualité / « Data editor » en lecture)."""

    def __init__(self, df, title, units=None, max_rows=20000):
        super().__init__()
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0)
        shown = df.iloc[:max_rows]
        t = QTableWidget(len(shown), len(shown.columns) + 1)
        units = units or {}
        t.setHorizontalHeaderLabels([f"{df.index.name or 'REF'}"] + [f"{c}\n[{units.get(str(c), '')}]" for c in df.columns])
        t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for r, (idx, row) in enumerate(shown.iterrows()):
            t.setItem(r, 0, QTableWidgetItem(f"{idx:g}" if isinstance(idx, float) else str(idx)))
            for c, val in enumerate(row.values, 1):
                txt = "" if pd.isna(val) else (f"{val:.6g}" if isinstance(val, float) else str(val))
                it = QTableWidgetItem(txt)
                if txt == "":
                    it.setBackground(Qt.lightGray)
                t.setItem(r, c, it)
        t.resizeColumnsToContents()
        v.addWidget(t)
        note = f"{len(df)} rows" + (f" (first {max_rows} shown)" if len(df) > max_rows else "")
        v.addWidget(QLabel(f"  {title}  -  {note}  -  {len(df.columns)} variable(s)"))
