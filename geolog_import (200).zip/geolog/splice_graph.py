"""Fenêtre « Graphical variable splice » : les logs d'entrée + le log fusionné, frontières déplaçables."""
import numpy as np
from PySide6.QtCore import Qt, QRectF, QLineF
from PySide6.QtGui import QColor, QBrush, QPen

import las_info
from logview import LogViewWidget, REF_W
from logview_model import CurveItem
from splice import (used_interval, make_grid, merge_row, auto_bounds, sorted_series, SEG_COLORS)


class SpliceInteractor:
    """Déplacement des lignes bleues : frontières entre positions + limites haute / basse (chopping)."""

    def __init__(self, w):
        self.w = w
        self.drag = None

    def lines(self):
        r = self.w.row
        out = [("b", i, d) for i, d in enumerate(r.bounds)]
        out.append(("top", 0, r.segs[0].top))
        out.append(("bottom", len(r.segs) - 1, r.segs[-1].bottom))
        return out

    def hit(self, pos):
        cv = self.w.canvas
        if cv.mode != "select" or pos.x() < REF_W or pos.y() < cv.header_h():
            return None
        for kind, i, d in self.lines():
            if abs(cv.y_of(d) - pos.y()) <= 4:
                return (kind, i)
        return None

    def hover(self, pos):
        return Qt.SizeVerCursor if self.hit(pos) else None

    def press(self, pos):
        h = self.hit(pos)
        if h:
            self.drag = h
            return True
        return False

    def move(self, pos):
        if not self.drag:
            return False
        w, r = self.w, self.w.row
        d = w.canvas.depth_at_y(pos.y())
        kind, i = self.drag
        if kind == "b":
            lo = r.bounds[i - 1] if i > 0 else -np.inf
            hi = r.bounds[i + 1] if i + 1 < len(r.bounds) else np.inf
            r.bounds[i] = float(min(max(d, lo), hi))
            r.manual = True
        elif kind == "top":
            hi = r.bounds[0] if r.bounds else r.segs[0].bottom
            r.segs[0].top = float(min(d, hi))
        else:
            lo = r.bounds[-1] if r.bounds else r.segs[-1].top
            r.segs[-1].bottom = float(max(d, lo))
        w.refresh_merged()
        return True

    def release(self, pos):
        if not self.drag:
            return False
        self.drag = None
        w = self.w
        w.tool.rebuild_limits()                # les colonnes Top / Bottom du tableau suivent
        return True


class SpliceGraphWidget(LogViewWidget):
    def __init__(self, host, tool, row, spec):
        super().__init__(provider=None)
        self.host, self.tool, self.row, self.spec = host, tool, row, spec
        self.sd = []                           # (profondeurs, valeurs) de chaque position
        cv = self.canvas
        fam = las_info.family_of(row.var)
        well = spec.get("well", "")
        for i, seg in enumerate(row.segs):
            info = host.dataset_info(seg.key)
            col = next(c for c in info["df"].columns if str(c) == seg.var)
            d, v = sorted_series(info["df"], col)
            self.sd.append((d, v))
            c = CurveItem(seg.key, seg.var, d, v, info["units"].get(seg.var, row.out_unit), info["well"],
                          seg.dsname, fam, 0)
            c.depth_unit = info["depth_unit"]
            c.style.title = f"{seg.dsname}.{seg.var}"
            cv.add_curve(c, None)
        self.merged = CurveItem("__splice__", row.out_name, np.array([0.0, 1.0]), np.array([np.nan, np.nan]),
                                row.out_unit, well, spec["name"], fam, 0)
        self.merged.depth_unit = spec["depth_unit"]
        self.merged.style.title = row.out_name
        cv.add_curve(self.merged, None)
        for t in cv.tracks:
            t.width = 150
        cv.pre_hook, cv.post_hook = self._pre, self._post
        cv.interactor = SpliceInteractor(self)
        self.refresh_merged()
        cv.top = min(s.top for s in row.segs)
        cv.vertical_adjust()
        self.sync_bars()

    # ----------------------------------------------------------- calcul
    def refresh_merged(self):
        grid = make_grid([self.row], self.spec["step"])
        vals = merge_row(self.row, grid, lambda i: self.sd[i]) if grid.size else np.array([])
        if grid.size < 2:
            grid, vals = np.array([0.0, 1.0]), np.array([np.nan, np.nan])
        m = self.merged
        m.depth, m.values = grid, vals
        fin = vals[np.isfinite(vals)]
        if fin.size:
            m.vmin, m.vmax = float(fin.min()), float(fin.max())
        self.canvas.update()

    def reset_bounds(self):
        auto_bounds(self.row)
        for s in self.row.segs:
            s.top, s.bottom = s.data_top, s.data_bottom
        self.refresh_merged()
        self.tool.rebuild_limits()

    def window_title(self):
        return f"Graphical variable splice [{self.row.var}]"

    # -------------------------------------------------------- dessin
    def _band(self, p, data, y0, y1, lo, hi, color, alpha):
        cv = self.canvas
        ya, yb = max(cv.y_of(lo), y0), min(cv.y_of(hi), y1)
        if yb > ya:
            col = QColor(color); col.setAlpha(alpha)
            p.fillRect(QRectF(data.left(), ya, data.width(), yb - ya), col)

    def _pre(self, p, idx, data, y0, y1):
        r, n = self.row, len(self.row.segs)
        if idx < n:
            iv = used_interval(r, idx)
            if iv:
                self._band(p, data, y0, y1, iv[0], iv[1], SEG_COLORS[idx % len(SEG_COLORS)], 120)
            s = r.segs[idx]
            for lo, hi in ((s.data_top, s.top), (s.bottom, s.data_bottom)):      # partie écartée (chopping)
                if hi > lo:
                    cv = self.canvas
                    ya, yb = max(cv.y_of(lo), y0), min(cv.y_of(hi), y1)
                    if yb > ya:
                        rr = QRectF(data.left(), ya, data.width(), yb - ya)
                        p.fillRect(rr, QColor(60, 110, 200, 60))
                        p.fillRect(rr, QBrush(QColor(20, 60, 160, 190), Qt.Dense5Pattern))
        else:
            for i in range(n):
                iv = used_interval(r, i)
                if iv:
                    self._band(p, data, y0, y1, iv[0], iv[1], SEG_COLORS[i % len(SEG_COLORS)], 90)

    def _post(self, p, idx, data, y0, y1):
        cv, r = self.canvas, self.row
        p.setPen(QPen(QColor("#2f8fd6"), 2))
        for d in r.bounds:
            y = cv.y_of(d)
            if y0 <= y <= y1:
                p.drawLine(QLineF(data.left(), y, data.right(), y))
        p.setPen(QPen(QColor("#233f9a"), 2))
        for d in (r.segs[0].top, r.segs[-1].bottom):
            y = cv.y_of(d)
            if y0 <= y <= y1:
                p.drawLine(QLineF(data.left(), y, data.right(), y))
