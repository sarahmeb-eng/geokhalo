"""Panneau d'import (le "container" à droite du Project browser) + icônes."""
import os
from PySide6.QtCore import Qt, QSettings, QPointF, QRectF, QSize
from PySide6.QtGui import QIcon, QPixmap, QPainter, QPen, QColor, QPolygonF, QFont, QShortcut, QKeySequence
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QComboBox,
                               QToolButton, QTreeWidget, QTreeWidgetItem, QFileDialog,
                               QMessageBox, QAbstractItemView, QMenu, QInputDialog)

import tempfile
import las_info
import datasets_io
import dlis_import
from import_dialogs import ConditionalSelectionDialog, SelectiveDlisDialog

ROLE_PATHS = Qt.UserRole + 1        # liste des chemins LAS portés par un noeud


# ------------------------------------------------------------------ icônes
def _canvas(size=16):
    pm = QPixmap(size, size); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    return pm, p


def well_icon():
    pm, p = _canvas()
    p.setPen(QPen(QColor("#1f6fb2"), 1.3))
    p.drawLine(8, 1, 3, 15); p.drawLine(8, 1, 13, 15)
    p.drawLine(5, 10, 11, 10); p.drawLine(6, 6, 10, 6)
    p.drawLine(5, 10, 10, 6); p.drawLine(11, 10, 6, 6)
    p.drawLine(2, 15, 14, 15)
    p.end(); return QIcon(pm)


def dataset_icon():
    pm, p = _canvas()
    p.setPen(QPen(QColor("#1aa7d8"), 2.2))
    p.drawEllipse(QRectF(2.5, 2.5, 11, 11))
    p.end(); return QIcon(pm)


def folder_icon():
    pm, p = _canvas(20)
    p.setPen(QPen(QColor("#b8860b"), 1)); p.setBrush(QColor("#f2c230"))
    p.drawRoundedRect(QRectF(1, 4, 7, 4), 1, 1)
    p.drawRoundedRect(QRectF(1, 6, 17, 11), 1.5, 1.5)
    p.end(); return QIcon(pm)


def arrow_left_icon():
    pm, p = _canvas(24)
    p.setPen(Qt.NoPen); p.setBrush(QColor("#1b9bd1"))
    p.drawPolygon(QPolygonF([QPointF(2, 12), QPointF(12, 3), QPointF(12, 8.5), QPointF(22, 8.5),
                             QPointF(22, 15.5), QPointF(12, 15.5), QPointF(12, 21)]))
    p.end(); return QIcon(pm)


def close_icon():
    pm, p = _canvas(20)
    p.setPen(QPen(QColor("#111"), 2.2))
    p.drawLine(4, 4, 16, 16); p.drawLine(16, 4, 4, 16)
    p.end(); return QIcon(pm)


def trash_icon():
    pm, p = _canvas(20)
    p.setPen(QPen(QColor("#1f6fb2"), 1.4)); p.setBrush(QColor("#d6e9f8"))
    p.drawRect(QRectF(5, 7, 10, 10)); p.drawLine(3, 6, 17, 6); p.drawLine(8, 3, 12, 3)
    p.drawLine(8, 9, 8, 15); p.drawLine(12, 9, 12, 15)
    p.end(); return QIcon(pm)


def dataset_type_icon(kind):
    """Icône du dataset selon son type : continuous / interval / point data / survey."""
    pm, p = _canvas()
    if kind == "interval":
        p.setPen(Qt.NoPen)
        for k, c in enumerate(["#c0392b", "#f39c12", "#f1c40f", "#8e44ad"]):
            p.setBrush(QColor(c)); p.drawRect(QRectF(2, 2 + k * 3.4, 12, 3))
    elif kind == "point data":
        p.setPen(Qt.NoPen)
        for (x, y, c) in ((4, 4, "#d9382b"), (11, 5, "#1b7fd0"), (6, 11, "#2ca02c"), (12, 12, "#8e44ad")):
            p.setBrush(QColor(c)); p.drawEllipse(QRectF(x - 2, y - 2, 4, 4))
    elif kind == "survey":
        p.setPen(QPen(QColor("#1f6fb2"), 1.6)); p.drawLine(3, 2, 3, 8); p.drawLine(3, 8, 12, 14)
        p.setPen(QPen(QColor("#d9382b"), 1.6)); p.drawEllipse(QRectF(10, 12, 3, 3))
    else:
        p.setPen(QPen(QColor("#c9a227"), 1.2)); p.setBrush(QColor("#fff3b0")); p.drawRoundedRect(QRectF(1.5, 1.5, 13, 13), 2, 2)
        p.setPen(QPen(QColor("#1f6fb2"), 1.2)); p.drawLine(5, 3, 5, 13); p.drawLine(8, 3, 8, 13); p.drawLine(11, 3, 11, 13)
    p.end(); return QIcon(pm)


def quality(c):
    """Qualité d'une variable (cours : noir = unité + famille, gris = un des deux manque, rouge = aucun)."""
    has_u, has_f = bool(str(c.get("unit", "")).strip()), bool(str(c.get("family", "")).strip())
    if has_u and has_f:
        return "ok"
    return "warn" if (has_u or has_f) else "bad"


def _tool(icon, tip, size=22):
    b = QToolButton(); b.setIcon(icon); b.setToolTip(tip); b.setAutoRaise(True)
    b.setIconSize(QSize(size, size))
    return b


# --------------------------------------------------- remplissage d'un arbre
def _curve_item(parent, c, path):
    ci = QTreeWidgetItem(parent, [c["mnemonic"], c["family"]])
    ci.setToolTip(0, f'{c["descr"]} [{c["unit"]}]'.strip())
    ci.setData(0, ROLE_PATHS, [path])
    q = quality(c)
    if q != "ok":                                 # gris : unité ou famille manquante ; rouge : les deux
        ci.setForeground(0, QColor("#8a8a8a" if q == "warn" else "#c0262d"))
        ci.setForeground(1, QColor("#8a8a8a" if q == "warn" else "#c0262d"))
        ci.setToolTip(0, ci.toolTip(0) + ("  -  unit or family missing" if q == "warn" else "  -  no unit and no family"))
    if c.get("derived"):                      # nouvelle version (GR_2...) : en gras
        f = ci.font(0); f.setBold(True); ci.setFont(0, f)
    return ci


def fill_groups(parent, infos, with_curves=False):
    """Crée  Well/Dataset-groupe -> datasets (-> courbes)  sous `parent` (item ou arbre)."""
    wi, di = well_icon(), dataset_icon()
    for kind, group, items in las_info.group_infos(infos):
        if kind == las_info.DATASET:       # dataset indépendant : un seul niveau
            for i in items:
                d = QTreeWidgetItem(parent, [i["name"]])
                d.setToolTip(0, i["stem"])
                d.setIcon(0, di if datasets_io.dataset_type(i) == "continuous" and not i.get("dtype") else dataset_type_icon(datasets_io.dataset_type(i)))
                d.setData(0, ROLE_PATHS, [i["path"]])
                d.setData(0, Qt.UserRole, i.get("key", i["stem"]))
                if with_curves:
                    for c in i["curves"]:
                        _curve_item(d, c, i["path"])
            continue
        g = QTreeWidgetItem(parent, [group])
        g.setIcon(0, wi if kind == las_info.WELL else di)
        g.setData(0, ROLE_PATHS, [i["path"] for i in items])
        if kind == las_info.WELL:
            f = g.font(0); f.setBold(True); g.setFont(0, f)
        for i in items:
            leaf = QTreeWidgetItem(g, [i["name"]])
            leaf.setToolTip(0, i["stem"])
            leaf.setIcon(0, dataset_type_icon(datasets_io.dataset_type(i)))
            leaf.setData(0, ROLE_PATHS, [i["path"]])
            leaf.setData(0, Qt.UserRole, i.get("key", i["stem"]))
            if with_curves:
                for c in i["curves"]:
                    _curve_item(leaf, c, i["path"])
        g.setExpanded(True)


def paths_of(item):
    """Tous les chemins LAS portés par un item (et ses descendants)."""
    out = list(item.data(0, ROLE_PATHS) or [])
    for k in range(item.childCount()):
        out += paths_of(item.child(k))
    return out


def filter_tree(tree, text):
    t = text.lower()

    def vis(item):
        ok = t in item.text(0).lower()
        for i in range(item.childCount()):
            ok = vis(item.child(i)) or ok
        item.setHidden(bool(t) and not ok)
        return ok
    for i in range(tree.topLevelItemCount()):
        vis(tree.topLevelItem(i))


# ------------------------------------------------------------- le panneau
class ImportPanel(QWidget):
    """Zone d'attente : on choisit des fichiers LAS, ils apparaissent classés
    (Well / Dataset), puis on les transfère vers le Project browser."""

    FILTER = "Data files (*.las *.la? *.las_* *.dlis *.gpds);;All files (*)"
    ASCII_FILTER = "Text / spreadsheet (*.txt *.csv *.dat *.asc *.prn *.tsv *.xlsx *.xls);;All files (*)"
    ASCII_EXT = (".txt", ".csv", ".dat", ".asc", ".prn", ".tsv", ".xlsx", ".xls")
    # liste du cours (Figure 14) ; les sources grisées ne sont pas encore disponibles
    SOURCES = [("File(s) import", True), ("ASCII file(s) import with wizard", True),
               ("Images import with wizard", False), ("Seismic data import", False),
               ("GeoLog project import", False), ("Compressed GeoLog project import", False),
               ("Files import - Folders selection", True), ("Multi well file import", False),
               ("Selective DLIS import", True), ("OpenSpirit project import", False)]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.infos = {}                    # path -> info
        self.is_known = lambda path: False # injecté par la fenêtre principale
        self.settings = QSettings("GeoLogApp", "GeoLog")

        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(3)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search")
        self.search.textChanged.connect(lambda t: filter_tree(self.tree, t))

        row = QHBoxLayout(); row.setSpacing(2)
        self.source = QComboBox()
        for label, enabled in self.SOURCES:
            self.source.addItem(label)
            if not enabled:
                self.source.model().item(self.source.count() - 1).setEnabled(False)
        self.btn_open = _tool(folder_icon(), "Open: browse the files to import", 20)
        self.btn_open.clicked.connect(self.browse)
        row.addWidget(self.source, 1); row.addWidget(self.btn_open)

        self.tree = QTreeWidget(); self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Name", "Family"])
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setColumnWidth(0, 170)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._menu)

        v.addWidget(self.search); v.addLayout(row); v.addWidget(self.tree)
        self._tmp_dir = None
        sc = QShortcut(QKeySequence("F2"), self.tree); sc.setContext(Qt.WidgetShortcut); sc.activated.connect(self.rename)
        self._rebuild()

    # -- fichiers
    def browse(self):
        """Bouton « Open » : le dialogue dépend de la source choisie dans la liste."""
        start = self.settings.value("import_dir", "")
        src = self.source.currentText()
        if src.startswith("Files import"):
            folder = QFileDialog.getExistingDirectory(self, "Folder to import", start)
            if folder:
                self.settings.setValue("import_dir", folder)
                found = [os.path.join(r, f) for r, _, fs in os.walk(folder) for f in sorted(fs)
                         if f.lower().endswith((".las", ".dlis", ".gpds")) or ".las" in f.lower()]
                self.add_files(found)
            return
        flt = self.ASCII_FILTER if src.startswith("ASCII") else (
            "DLIS files (*.dlis);;All files (*)" if src.startswith("Selective") else self.FILTER)
        paths, _ = QFileDialog.getOpenFileNames(self, "Import data", start, flt)
        if paths:
            self.settings.setValue("import_dir", os.path.dirname(paths[0]))
            self.add_files(paths, selective_dlis=src.startswith("Selective"))

    def tmp_dir(self):
        if not self._tmp_dir:
            self._tmp_dir = tempfile.mkdtemp(prefix="geolog_import_")
        return self._tmp_dir

    def _add_memory_datasets(self, datasets, source):
        """Datasets venus de l'assistant texte / DLIS : écrits en .gpds temporaires, relus pour le buffer."""
        for p in datasets_io.save_import(datasets, self.tmp_dir()):
            info = las_info.read_info(p)
            info["temp"], info["source"] = True, source
            self.infos[p] = info

    def add_files(self, paths, selective_dlis=False):
        bad, dup = [], 0
        for p in paths:
            p = os.path.normpath(p)
            low = p.lower()
            if p in self.infos or self.is_known(p):
                dup += 1
                continue
            try:
                if low.endswith(self.ASCII_EXT):                       # texte / tableur -> assistant
                    from ascii_wizard import AsciiWizard
                    dlg = AsciiWizard(p, self)
                    if dlg.exec():
                        self._add_memory_datasets(dlg.datasets, p)
                elif low.endswith(".dlis"):
                    sel = None
                    if selective_dlis:
                        d = SelectiveDlisDialog(dlis_import.list_frames(p), self)
                        if not d.exec():
                            continue
                        sel = d.selection()
                    data = dlis_import.read_dlis(p, sel)
                    if not data:
                        raise ValueError("no readable channel in this DLIS file")
                    self._add_memory_datasets(data, p)
                else:
                    self.infos[p] = las_info.read_info(p)
            except Exception as e:
                bad.append(f"{os.path.basename(p)}: {e}")
        self._rebuild()
        self.tree.selectAll()              # par défaut : tout est prêt à être transféré
        if bad:
            QMessageBox.warning(self, "Import", "Unreadable file(s):\n" + "\n".join(bad))

    def remove_paths(self, paths):
        for p in paths:
            self.infos.pop(p, None)
        self._rebuild()

    def selected_paths(self):
        seen, out = set(), []
        for it in self.tree.selectedItems():
            for p in paths_of(it):
                if p not in seen:
                    seen.add(p); out.append(p)
        return out

    def rename(self):
        """F2 : renomme le dataset sélectionné (ex. « DATAFULL_ » -> « DATAFULL »)."""
        paths = self.selected_paths()
        if len(paths) != 1:
            return
        info = self.infos[paths[0]]
        name, ok = QInputDialog.getText(self, "Rename", "New dataset name:", text=info["name"])
        if ok and name.strip():
            info["name"], info["renamed"] = name.strip(), True
            self._rebuild(); self.tree.selectAll()

    def conditional_selection(self):
        """Clic droit > Create a conditional selection : sélectionne les datasets qui répondent à la condition."""
        dlg = ConditionalSelectionDialog(self)
        if not dlg.exec():
            return
        field, test = dlg.matcher()
        match = set()
        for p, i in self.infos.items():
            value = i["name"] if field == "Dataset name" else (i["group"] if i["kind"] == las_info.WELL else "")
            if test(value):
                match.add(p)
        self.tree.clearSelection()

        def walk(it):
            for k in range(it.childCount()):
                c = it.child(k)
                ps = c.data(0, ROLE_PATHS) or []
                if c.data(0, Qt.UserRole) is not None and len(ps) == 1 and ps[0] in match:
                    c.setSelected(True)
                walk(c)
        walk(self.tree.invisibleRootItem())
        self.tree.setFocus()

    def _menu(self, pos):
        if not self.selected_paths():
            return
        m = QMenu(self)
        m.addAction("Rename\tF2", self.rename)
        m.addAction("Create a conditional selection...", self.conditional_selection)
        m.addSeparator()
        m.addAction("Assign to well...", self.assign_well)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    def assign_well(self):
        """Corrige à la main le puits des fichiers sélectionnés."""
        paths = self.selected_paths()
        wells = sorted({i["group"] for i in self.infos.values() if i["kind"] == las_info.WELL})
        name, ok = QInputDialog.getItem(
            self, "Assign to well", "Well name (leave empty = standalone dataset):",
            wells, 0, True)
        if not ok:
            return
        for p in paths:
            las_info.reassign(self.infos[p], name)
        self._rebuild(); self.tree.selectAll()

    def _rebuild(self):
        self.tree.clear()
        root = QTreeWidgetItem(self.tree, ["Datasets"])
        fill_groups(root, list(self.infos.values()), with_curves=True)
        root.setExpanded(True)
        # les datasets sont repliés (courbes visibles via la flèche), comme dans Techlog
        for g in range(root.childCount()):
            for d in range(root.child(g).childCount()):
                root.child(g).child(d).setExpanded(False)
