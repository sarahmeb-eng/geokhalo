"""Lecture légère de l'en-tête d'un fichier LAS et classement Well / Dataset.

Le classement ne dépend JAMAIS de la forme du nom de fichier :
  - le champ WELL de la section ~Well donne le nom du puits ;
  - fichiers avec le même WELL -> UN puits contenant plusieurs datasets ;
  - fichier sans nom de puits valide (vide, UNKNOWN, NULL...) -> dataset
    indépendant, nommé d'après son fichier, SANS aucun regroupement deviné.
  - l'utilisateur peut corriger à la main (reassign) si l'en-tête est faux.
"""
import re
from pathlib import Path

WELL, DATASET = "well", "dataset"
_GENERIC_DESCR = {"well", "well name", "name", "name of well", "well id",
                  "well identifier", "well number", "current well"}
_NO_WELL = {"", "unknown", "null", "none", "undefined", "?", "n/a", "na", "-"}

# mnémonique -> famille (indicatif, extensible)
_FAMILIES = [
    (r"^(GR|CGR|SGR|GRC|GAMMA)", "Gamma Ray"),
    (r"^(RHOB|RHOZ|DEN|DENS|ZDEN)", "Bulk Density"),
    (r"^(NPHI|TNPH|NPOR|CNL)", "Neutron Porosity"),
    (r"^(DT|DTC|DTCO|DTS|AC|SONIC)", "Sonic"),
    (r"^(CALI|CAL|HCAL|BS)", "Caliper"),
    (r"^(ILD|ILM|LLD|LLS|RD|RT|RXO|MSFL|RES|AT\d+|AO\d+)", "Resistivity"),
    (r"^(SP)$", "Spontaneous Potential"),
    (r"^(PEF|PE)$", "Photoelectric Factor"),
    (r"^(DEPT|DEPTH|MD)$", "Measured Depth"),
    (r"^(TVD|TVDSS)", "True Vertical Depth"),
    (r"^(INCL|DEVI|AZIM|AZI)", "Deviation"),
]


def family_of(mnemonic):
    m = mnemonic.upper()
    for rx, fam in _FAMILIES:
        if re.match(rx, m):
            return fam
    return ""


def _sections(path):
    """Découpe l'en-tête en {section: [lignes]} ; s'arrête à ~A (données)."""
    secs, cur = {}, None
    with open(path, "r", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("~"):
                cur = line[1:2].upper()
                if cur == "A":
                    break
                secs.setdefault(cur, [])
                continue
            if cur:
                secs[cur].append(line)
    return secs


def _parse_line(line):
    """'WELL.   Well-1x : WELL NAME' -> ('WELL', 'Well-1x', 'WELL NAME')."""
    m = re.match(r"^\s*([^.\s:]+)\s*\.([^\s:]*)\s*(.*?)\s*:\s*(.*)$", line)
    if not m:
        return None
    mnem, unit, value, descr = m.groups()
    return mnem.strip(), unit.strip(), value.strip(), descr.strip()


def _clean_well(name):
    n = (name or "").strip().strip("'\"")
    if n.lower() in _NO_WELL or re.fullmatch(r"-?999(\.0+|\.25)?", n):
        return ""
    return n


def _strip_prefix(stem, prefix):
    """Retire le nom du puits au début du nom de fichier SEULEMENT s'il est suivi
    d'un séparateur ; sinon on garde le nom de fichier complet."""
    if prefix and stem.lower().startswith(prefix.lower()):
        rest = stem[len(prefix):]
        if rest[:1] in (" ", "_", "-", "."):
            rest = rest.strip(" _-.")
            if rest:
                return rest
    return None


def read_info(path):
    """Retourne un dict décrivant le fichier LAS (lève une exception si illisible)."""
    if str(path).lower().endswith(".gpds"):             # datasets importés par l'assistant texte / DLIS
        import datasets_io
        return datasets_io.read_info(path)
    p = Path(path)
    secs = _sections(p)
    if "C" not in secs and "W" not in secs:
        raise ValueError("not a LAS file (no ~Curve / ~Well section)")

    well = ""
    for line in secs.get("W", []):
        r = _parse_line(line)
        if r and r[0].upper() == "WELL":
            well = " ".join(_clean_well(r[2]).split())
            if not well and r[3].strip().lower() not in _GENERIC_DESCR:
                well = _clean_well(r[3])      # format "WELL. : NOM"
            break

    curves = []
    for line in secs.get("C", []):
        r = _parse_line(line)
        if r:
            curves.append({"mnemonic": r[0], "unit": r[1], "descr": r[3],
                           "family": family_of(r[0])})

    stem = p.stem
    if well:
        kind, group = WELL, well
        name = _strip_prefix(stem, well) or stem
    else:
        kind, group, name = DATASET, stem, stem
    return {"path": str(p), "stem": stem, "kind": kind, "group": group,
            "name": name, "curves": curves}


def read_info_safe(path):
    """Comme read_info mais ne plante jamais : repli = dataset indépendant."""
    try:
        return read_info(path)
    except Exception:
        stem = Path(path).stem
        return {"path": str(path), "stem": stem, "kind": DATASET, "group": stem,
                "name": stem, "curves": []}


def natural_key(text):
    """Tri naturel insensible à la casse : 'hole 8' < 'hole 12'."""
    return [int(t) if t.isdigit() else t.casefold() for t in re.split(r"(\d+)", text)]


def well_key(name):
    """Clé de regroupement : 'Bakken', 'BAKKEN ' et 'bakken' = même puits."""
    return " ".join(name.split()).casefold()


def group_infos(infos):
    """[(kind, group_name, [info, ...]), ...] en gardant l'ordre d'arrivée.
    Un dataset indépendant forme toujours son propre groupe."""
    out, idx = [], {}
    for i in infos:
        k = (i["kind"], well_key(i["group"]) if i["kind"] == WELL else i["path"])
        if k not in idx:
            idx[k] = len(out)
            out.append((i["kind"], i["group"], []))
        out[idx[k]][2].append(i)
    for _, _, items in out:
        items.sort(key=lambda x: natural_key(x["name"]))
    out.sort(key=lambda g: natural_key(g[1]))      # ordre alphabétique, comme Techlog
    return out


def reassign(info, well):
    """Correction manuelle : rattache le fichier à `well` ('' = dataset indépendant)."""
    well = (well or "").strip()
    if well:
        info["kind"], info["group"] = WELL, well
        info["name"] = _strip_prefix(info["stem"], well) or info["stem"]
    else:
        info["kind"], info["group"], info["name"] = DATASET, info["stem"], info["stem"]
