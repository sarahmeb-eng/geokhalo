"""Petites boîtes de dialogue : Smooth..."""
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit,
                               QComboBox, QPushButton, QMessageBox)


class SmoothDialog(QDialog):
    """Smooth  -  Variable <nom> / Smooth window size (in ft) / Transformation using / OK Cancel."""
    SCALES = ["values in linear scale", "values in logarithmic scale"]

    def __init__(self, parent, title, icon, variables, unit="m", window=10.0):
        super().__init__(parent)
        self.setWindowTitle("Smooth")
        self.setWindowIcon(icon)
        self.setModal(True)
        self.setMinimumWidth(340)

        v = QVBoxLayout(self)
        v.setContentsMargins(8, 8, 8, 8); v.setSpacing(6)

        head = QLabel(("Variable  <b>%s</b>" % variables[0]) if len(variables) == 1
                      else ("Variables  <b>%s</b>" % ", ".join(variables[:3]) +
                            (" ... (%d)" % len(variables) if len(variables) > 3 else "")))
        head.setStyleSheet("background:#e4e8ec; padding:4px;")
        head.setToolTip(title)
        v.addWidget(head)

        g = QGridLayout(); g.setHorizontalSpacing(8)
        g.addWidget(QLabel("Smooth window size (in %s):" % unit), 0, 0)
        self.size = QLineEdit("%.2f" % window)
        g.addWidget(self.size, 0, 1)
        g.addWidget(QLabel("Transformation using:"), 1, 0)
        self.scale = QComboBox(); self.scale.addItems(self.SCALES)
        g.addWidget(self.scale, 1, 1)
        g.setColumnStretch(1, 1)
        v.addLayout(g)

        row = QHBoxLayout(); row.addStretch()
        ok = QPushButton("OK"); ok.setDefault(True); ok.clicked.connect(self._accept)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        row.addWidget(ok); row.addWidget(cancel)
        v.addLayout(row)

    def _accept(self):
        try:
            if float(self.size.text().replace(",", ".")) <= 0:
                raise ValueError
        except ValueError:
            QMessageBox.warning(self, "Smooth", "The window size must be a positive number.")
            return
        self.accept()

    def values(self):
        """(taille de fenêtre, True si transformation logarithmique)"""
        return float(self.size.text().replace(",", ".")), self.scale.currentIndex() == 1
