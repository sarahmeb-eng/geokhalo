"""Calculs sans interface : lissage (smoothing) et décalage en profondeur (depth shift).

Toutes les fonctions travaillent sur des tableaux numpy et sont testables sans Qt.
"""
import math

import numpy as np


# ------------------------------------------------------------------ utilitaires
def step_of(depth):
    """Pas d'échantillonnage médian (en unités de profondeur)."""
    d = np.diff(np.asarray(depth, float))
    d = d[np.isfinite(d) & (d > 0)]
    return float(np.median(d)) if d.size else 1.0


def on_valid_depth(depth, values, fn):
    """Applique fn(depth_triée, values_triées) -> tableau, en ignorant les profondeurs invalides.

    Le résultat est ré-aligné sur les tableaux d'origine (NaN là où la profondeur est invalide).
    """
    depth = np.asarray(depth, float)
    values = np.asarray(values, float)
    out = np.full(values.shape, np.nan)
    idx = np.flatnonzero(np.isfinite(depth))
    if idx.size == 0:
        return out
    order = idx[np.argsort(depth[idx], kind="stable")]
    out[order] = fn(depth[order], values[order])
    return out


# ------------------------------------------------------------------ smoothing
def _kernel(n):
    """Noyau gaussien tronqué à ±n/2 échantillons (±2 sigma), normalisé."""
    n = max(1.0, float(n))
    half = n / 2.0
    sigma = max(n / 4.0, 0.5)
    m = max(1, int(math.floor(half)))
    x = np.arange(-m, m + 1, dtype=float)
    w = np.exp(-0.5 * (x / sigma) ** 2)
    w[np.abs(x) > half] = 0.0
    s = w.sum()
    return w / s if s > 0 else np.array([1.0])


def gaussian(values, n_samples, fill_missing=False):
    """Lissage gaussien avec convolution normalisée (gère les NaN et les bords)."""
    v = np.asarray(values, float)
    if v.size == 0:
        return v.copy()
    k = _kernel(n_samples)
    if k.size > v.size:                       # np.convolve(mode='same') exige len(k) <= len(v)
        m = (v.size - 1) // 2
        c = k.size // 2
        k = k[c - m:c + m + 1]
        k = k / k.sum()
    ok = np.isfinite(v)
    num = np.convolve(np.where(ok, v, 0.0), k, mode="same")
    den = np.convolve(ok.astype(float), k, mode="same")
    with np.errstate(all="ignore"):
        out = num / den
    out[den <= 1e-9] = np.nan
    if fill_missing:
        out[den < 0.05] = np.nan             # on ne comble que les trous réellement proches de données
    else:
        out[~ok] = np.nan                    # les trous restent des trous
    return out


def median(values, n_samples):
    """Lissage par médiane glissante centrée (fenêtre impaire)."""
    import pandas as pd
    v = np.asarray(values, float)
    n = max(1, int(round(n_samples)))
    if n % 2 == 0:
        n += 1
    out = np.array(pd.Series(v).rolling(n, center=True, min_periods=1).median(), dtype=float)
    out[~np.isfinite(v)] = np.nan
    return out


def smooth(depth, values, window, kind="gauss", log=False):
    """kind : 'gauss' | 'gauss_mv' (comble les trous) | 'median'. window en unités de profondeur."""
    depth = np.asarray(depth, float)
    v = np.asarray(values, float)
    n = max(1.0, float(window) / step_of(depth))
    if log:
        with np.errstate(all="ignore"):
            v = np.where(v > 0, np.log10(np.where(v > 0, v, 1.0)), np.nan)
    out = median(v, n) if kind == "median" else gaussian(v, n, fill_missing=(kind == "gauss_mv"))
    if log:
        with np.errstate(all="ignore"):
            out = np.power(10.0, out)
    return out


# ------------------------------------------------------------------ depth shift
def normalize_anchors(anchors, eps=1e-3):
    """Trie par profondeur source, remplace les doublons et force des profondeurs cibles croissantes
    (pour que le décalage reste une transformation monotone)."""
    pts = sorted((float(s), float(t)) for s, t in anchors)
    out = []
    for s, t in pts:
        if out and s - out[-1][0] < 1e-6:
            out[-1] = (s, t)
        else:
            out.append((s, t))
    for i in range(1, len(out)):
        if out[i][1] <= out[i - 1][1] + eps:
            out[i] = (out[i][0], out[i - 1][1] + eps)
    return out


def shift_depth(depth, anchors):
    """Nouvelle profondeur de chaque échantillon.

    Entre deux points d'ancrage le décalage varie linéairement ; en dehors il reste constant.
    """
    depth = np.asarray(depth, float)
    a = normalize_anchors(anchors)
    if not a:
        return depth.copy()
    src = np.array([p[0] for p in a])
    delta = np.array([p[1] - p[0] for p in a])
    return depth + np.interp(depth, src, delta)


def resample_shifted(depth, values, new_depth, grid=None):
    """Valeurs de la courbe décalée, ré-échantillonnées sur la grille d'origine.

    Les trous (NaN) de la courbe d'origine restent des trous ; hors de la plage décalée : NaN.
    """
    depth = np.asarray(depth, float)
    v = np.asarray(values, float)
    nd = np.asarray(new_depth, float)
    grid = depth if grid is None else np.asarray(grid, float)
    ok = np.isfinite(v)
    if ok.sum() < 2:
        return np.full(grid.shape, np.nan)
    out = np.interp(grid, nd[ok], v[ok], left=np.nan, right=np.nan)
    flag = np.interp(grid, nd, ok.astype(float), left=0.0, right=0.0)
    out[flag < 0.999] = np.nan
    return out


def auto_shift(ref_d, ref_v, var_d, var_v, max_shift, max_points=20000):
    """Décalage constant qui maximise la corrélation (en valeur absolue) entre la référence et la variable.

    Convention : valeur_décalée(d) = variable(d - s). Retourne (s, corrélation).
    """
    ref_d, ref_v = np.asarray(ref_d, float), np.asarray(ref_v, float)
    var_d, var_v = np.asarray(var_d, float), np.asarray(var_v, float)
    ro, vo = np.isfinite(ref_v) & np.isfinite(ref_d), np.isfinite(var_v) & np.isfinite(var_d)
    if ro.sum() < 10 or vo.sum() < 10:
        return 0.0, 0.0
    ref_d, ref_v, var_d, var_v = ref_d[ro], ref_v[ro], var_d[vo], var_v[vo]
    lo, hi = max(ref_d.min(), var_d.min()), min(ref_d.max(), var_d.max())
    if hi <= lo:
        return 0.0, 0.0
    step = max(step_of(ref_d), step_of(var_d), (hi - lo) / max_points)
    grid = np.arange(lo, hi, step)
    if grid.size < 10:
        return 0.0, 0.0
    ref = np.interp(grid, ref_d, ref_v)
    best_s, best_c = 0.0, -1.0
    n = int(max(1, round(max_shift / step)))
    for k in range(-n, n + 1):
        s = k * step
        sh = np.interp(grid - s, var_d, var_v, left=np.nan, right=np.nan)
        m = np.isfinite(sh)
        if m.sum() < max(10, grid.size // 4):
            continue
        a, b = ref[m], sh[m]
        if a.std() == 0 or b.std() == 0:
            continue
        c = abs(float(np.corrcoef(a, b)[0, 1]))
        if c > best_c:
            best_s, best_c = s, c
    return float(best_s), float(max(best_c, 0.0))
