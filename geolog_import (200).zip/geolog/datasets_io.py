"""Format de dataset GeoLog (.gpds) : 1re ligne = JSON (puits, dataset, type, unités...), puis tableau CSV.
Sert pour les données importées par l'assistant texte / DLIS (zones avec noms, points, intervalles...)."""
import json
import os
import re
from pathlib import Path

import pandas as pd

import las_info

EXT = ".gpds"
SURVEY_NAMES = {"AZI", "AZIM", "AZIMUTH", "HAZI", "INCL", "INCLINATION", "DEVI", "DEV", "DIP"}


def write_gpds(path, meta, df):
    meta = dict(meta)
    meta.setdefault("dtype", "continuous")
    meta["index"] = meta.get("ref_name") or df.index.name or "MD"
    out = df.copy()
    out.index.name = meta["index"]
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(json.dumps(meta, ensure_ascii=False) + "\n")
        out.to_csv(f, lineterminator="\n")


def _meta(path):
    with open(path, encoding="utf-8") as f:
        return json.loads(f.readline())


def read_df(path):
    meta = _meta(path)
    df = pd.read_csv(path, skiprows=1, index_col=0)
    df.index = pd.to_numeric(df.index, errors="coerce")
    df.index.name = meta["index"]
    for c in df.columns:                      # on garde les colonnes texte (noms de zones)
        conv = pd.to_numeric(df[c], errors="coerce")
        if conv.notna().sum() == df[c].notna().sum():
            df[c] = conv
    return df


def read_info(path):
    m, p = _meta(path), Path(path)
    well = (m.get("well") or "").strip()
    curves = [{"mnemonic": m["index"], "unit": m.get("ref_unit", ""), "descr": "Reference",
               "family": "Measured Depth"}]
    for name, c in m.get("columns", {}).items():
        curves.append({"mnemonic": name, "unit": c.get("unit", ""), "descr": c.get("descr", ""),
                       "family": c.get("family") or las_info.family_of(name)})
    name = m.get("name") or p.stem
    kind, group = (las_info.WELL, well) if well else (las_info.DATASET, p.stem)
    return {"path": str(p), "stem": p.stem, "kind": kind, "group": group, "name": name,
            "curves": curves, "dtype": m.get("dtype", "continuous")}


def dataset_type(info):
    """continuous | point data | interval | survey (déduit des noms de courbes pour un survey)."""
    t = info.get("dtype", "continuous")
    if t != "continuous":
        return t
    names = {c["mnemonic"].upper() for c in info.get("curves", [])}
    if len(names & SURVEY_NAMES) >= 2:
        return "survey"
    return "continuous"


def save_import(datasets, folder):
    """Écrit chaque dataset importé (dict de ascii_import / dlis_import) en .gpds ; retourne les chemins."""
    os.makedirs(folder, exist_ok=True)
    paths = []
    for d in datasets:
        base = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{d['well']}_{d['name']}" if d["well"] else d["name"])
        path, n = os.path.join(folder, base + EXT), 2
        while os.path.exists(path):
            path = os.path.join(folder, f"{base}_{n}{EXT}"); n += 1
        meta = {"well": d["well"], "name": d["name"], "dtype": d["dtype"], "ref_name": d["ref_name"],
                "ref_unit": d["ref_unit"], "columns": d["columns"]}
        write_gpds(path, meta, d["df"])
        paths.append(os.path.normpath(path))
    return paths
