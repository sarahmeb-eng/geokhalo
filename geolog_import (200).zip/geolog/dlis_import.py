"""Import DLIS (Lesson 2 du cours) avec dlisio : un dataset par frame, un puits par origine."""
import re
from pathlib import Path

import numpy as np
import pandas as pd

import las_info

_UNIT = re.compile(r"^\s*([0-9.]+)?\s*([A-Za-z]+)\s*$")


def convert_reference(values, unit):
    """'0.1 in' -> ft ; 'm' -> m ; etc. Retourne (valeurs, unité)."""
    m = _UNIT.match(unit or "")
    if not m:
        return values, unit or ""
    scale = float(m.group(1)) if m.group(1) else 1.0
    base = m.group(2).lower()
    if base in ("in", "inch", "inches"):
        return values * scale / 12.0, "ft"
    if base in ("ft", "feet", "foot"):
        return values * scale, "ft"
    if base in ("m", "meter", "metre", "meters"):
        return values * scale, "m"
    if base == "cm":
        return values * scale / 100.0, "m"
    if base == "mm":
        return values * scale / 1000.0, "m"
    return values, unit or ""


def list_frames(path):
    """[(frame, well, [(canal, unité, description)])] sans charger les données (Selective DLIS import)."""
    from dlisio import dlis
    out = []
    with dlis.load(str(path)) as files:
        for f in files:
            well = (f.origins[0].well_name if f.origins else "") or Path(path).stem
            for fr in f.frames:
                out.append((fr.name, well, [(c.name, c.units or "", c.long_name or "") for c in fr.channels]))
    return out


def read_dlis(path, selection=None, mv=-999.25):
    """selection : {nom_de_frame: {canaux}} ou None = tout. Retourne la liste de datasets."""
    from dlisio import dlis
    stem, out = Path(path).stem, []
    with dlis.load(str(path)) as files:
        for f in files:
            well = (f.origins[0].well_name if f.origins else "") or stem
            for fr in f.frames:
                if selection is not None and fr.name not in selection:
                    continue
                curves = fr.curves()
                chans = [c for c in fr.channels]
                if not chans:
                    continue
                idx_name = chans[0].name
                ref, ref_unit = convert_reference(np.asarray(curves[idx_name], float), chans[0].units or "")
                data, cols = {}, {}
                for c in chans[1:]:
                    if selection is not None and c.name not in selection[fr.name]:
                        continue
                    a = np.asarray(curves[c.name])
                    if a.ndim != 1 or a.dtype.kind not in "fiu":       # tableaux (Array) : pas encore gérés
                        continue
                    a = a.astype(float)
                    a[np.isclose(a, mv)] = np.nan
                    data[c.name] = a
                    cols[c.name] = {"unit": c.units or "", "family": las_info.family_of(c.name),
                                    "descr": c.long_name or ""}
                if data:
                    out.append({"well": well, "name": fr.name, "dtype": "continuous", "ref_name": idx_name,
                                "ref_unit": ref_unit, "df": pd.DataFrame(data, index=ref).sort_index(),
                                "columns": cols})
    return out
