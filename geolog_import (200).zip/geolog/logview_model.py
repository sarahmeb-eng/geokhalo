"""Modèle de données du LogView : familles, style d'une courbe, tracks."""
import copy
import time
from dataclasses import dataclass, fields

import numpy as np

# famille -> limites "family" (lo = bord gauche, hi = bord droit), unité, échelle, ...
FAMILIES = {
    "Gamma Ray":             dict(lo=0,    hi=150,  unit="GAPI", scale="linear", color="#000000",
                                  fill="baseline", base=75.0),
    "Bulk Density":          dict(lo=1.95, hi=2.95, unit="G/C3", scale="linear", color="#c0392b"),
    "Neutron Porosity":      dict(lo=0.45, hi=-0.15, unit="V/V", scale="linear", color="#1f4fd8"),
    "Sonic":                 dict(lo=140,  hi=40,   unit="US/F", scale="linear", color="#b0189c"),
    "Caliper":               dict(lo=6,    hi=16,   unit="IN",   scale="linear", color="#c0392b",
                                  style="dash"),
    "Resistivity":           dict(lo=0.2,  hi=2000, unit="OHMM", scale="log",    color="#d62728"),
    "Spontaneous Potential": dict(lo=-100, hi=100,  unit="MV",   scale="linear", color="#1f77b4"),
    "Photoelectric Factor":  dict(lo=0,    hi=10,   unit="B/E",  scale="linear", color="#000000"),
}
FAMILY_LIST = [""] + list(FAMILIES)          # "" = famille inconnue
UNITS = ["GAPI", "G/C3", "V/V", "US/F", "IN", "OHMM", "MV", "B/E", "M", "FT", "%", "API"]
LINE_STYLES = ["solid", "dash", "dot", "dash dot", "dash dot dot"]
POINT_TYPES = ["circle", "square", "triangle", "cross", "plus"]
FILL_MODES = {"none": "none", "baseline": "baseline",
              "to left edge": "left", "to right edge": "right"}
PALETTE = ["#000000", "#d62728", "#1f77b4", "#2ca02c", "#9467bd", "#ff7f0e", "#8c564b"]


@dataclass
class CurveStyle:
    # ---------------- Limits
    title: str = ""
    family: str = ""
    axis_type: str = "variable"       # variable | user | family
    user_lo: float = 0.0
    user_hi: float = 1.0
    scale: str = "linear"
    unit: str = ""
    inverted: bool = False
    conserve_user: bool = True
    ref_limit: bool = False
    ref_top: float = 0.0
    ref_bottom: float = 0.0
    # ---------------- Display options
    decimation: bool = False
    color_mode: str = "global"        # global | variable
    color: str = "#000000"
    color_var: str = ""
    line_coloration: bool = True
    show_points: bool = False
    point_type: str = "circle"
    point_size: int = 5
    point_var_on: bool = False
    point_var: str = ""
    show_line: bool = True
    line_style: str = "solid"
    thickness: float = 1.0
    opacity: int = 100
    only_fill: bool = False
    optimized: bool = True
    vthr_on: bool = False
    vthr: float = 5.0
    part_start: int = 0
    part_end: int = 100
    fill_mode: str = "none"           # none | baseline | left | right
    base_value: float = 0.0
    fill_a: str = "#ffe800"           # sous la ligne de base (jaune)
    fill_b: str = "#a52a2a"           # au-dessus (marron)
    fill_opacity: int = 100


@dataclass
class GridSettings:
    """Grille de référence (Main / Secondary / Tertiary)."""
    spacing: float = 25.0
    thickness: int = 1
    visible: bool = True
    color: str = "#b4b4b4"


def default_grids(unit="M"):
    sp = (25.0, 5.0, 1.0) if str(unit).lower().startswith("f") else (5.0, 1.0, 0.2)
    cols = ("#a9a9a9", "#cbcbcb", "#e3e3e3")
    return [GridSettings(s, 1, True, c) for s, c in zip(sp, cols)]


class WellSettings:
    """Réglages d'un puits dans le layout : limitation de référence + grilles."""

    def __init__(self, grids):
        self.ref_limit = False
        self.top = 0.0
        self.bottom = 0.0
        self.grids = [copy.copy(g) for g in grids]


class CurveItem:
    """Une courbe affichée dans un track : données + style + historique."""

    def __init__(self, key, name, depth, values, unit="", well="", dataset="",
                 family="", color_index=0):
        depth, values = np.asarray(depth, float), np.asarray(values, float)
        good = np.isfinite(depth)                      # on ignore les profondeurs invalides
        depth, values = depth[good], values[good]
        order = np.argsort(depth)
        self.key, self.name = key, name
        self.depth = depth[order]
        self.values = values[order]
        self.well, self.dataset = well, dataset
        self.file_unit = unit
        self.history = []
        self.depth_unit = "M"
        self.modified = False     # valeurs modifiées, pas encore sauvegardées
        self.orig_values = None
        self.siblings = []        # noms des autres variables du même dataset
        self.loader = None        # loader(name) -> (depth, values) | None
        self._aux = {}
        self.style = CurveStyle(family=family, unit=unit)
        fin = self.values[np.isfinite(self.values)]
        self.vmin = float(fin.min()) if fin.size else 0.0
        self.vmax = float(fin.max()) if fin.size else 1.0
        self.apply_family(family, color_index)

    # -- valeurs par défaut selon la famille
    def apply_family(self, family, color_index=0):
        s = self.style
        s.family = family
        f = FAMILIES.get(family)
        if f:
            s.axis_type, s.unit, s.scale = "family", f["unit"], f["scale"]
            s.color = f["color"]
            s.line_style = f.get("style", "solid")
            if f.get("fill") == "baseline":
                s.fill_mode, s.base_value = "baseline", f["base"]
        else:
            s.axis_type, s.unit, s.scale = "variable", self.file_unit, "linear"
            s.color = PALETTE[color_index % len(PALETTE)]
        s.user_lo, s.user_hi = self.effective_limits()
        s.base_value = s.base_value or (s.user_lo + s.user_hi) / 2

    # -- limites réellement utilisées pour l'affichage
    def variable_limits(self):
        lo, hi = self.vmin, self.vmax
        return (lo, hi if hi != lo else lo + 1.0)

    def family_limits(self):
        f = FAMILIES.get(self.style.family)
        return (f["lo"], f["hi"]) if f else None

    def effective_limits(self):
        s = self.style
        if s.axis_type == "user":
            lo, hi = s.user_lo, s.user_hi
        elif s.axis_type == "family" and self.family_limits():
            lo, hi = self.family_limits()
        else:
            lo, hi = self.variable_limits()
        if lo == hi:
            hi = lo + 1.0
        return float(lo), float(hi)

    def aux(self, name):
        """Valeurs d'une variable voisine, ré-échantillonnées sur la profondeur de cette courbe."""
        if name in self._aux:
            return self._aux[name]
        arr = None
        got = self.loader(name) if (self.loader and name) else None
        if got is not None:
            d, v = np.asarray(got[0], float), np.asarray(got[1], float)
            ok = np.isfinite(d) & np.isfinite(v)
            if ok.sum() > 1:
                o = np.argsort(d[ok])
                arr = np.interp(self.depth, d[ok][o], v[ok][o])
        self._aux[name] = arr
        return arr

    def display_name(self):
        return self.style.title or self.name

    def log(self, text):
        self.history.append(f"{time.strftime('%H:%M:%S')}   {text}")


class Track:
    def __init__(self, title=""):
        self.title = title
        self.curves = []
        self.width = 190
        self.grid_lines = 4               # nombre d'intervalles de la grille verticale
