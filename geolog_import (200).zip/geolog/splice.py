"""Logique du « Variables splice » : segments, frontières entre positions, fusion.

Pour une variable (ex. GR) on a plusieurs segments, un par dataset (17 hole, 12 hole, 8 hole...),
classés par profondeur croissante : position 1, 2, 3...
Entre deux positions voisines il y a une FRONTIÈRE (par défaut au milieu du recouvrement) :
au-dessus on prend la position i, en dessous la position i+1.
"""
import re
from dataclasses import dataclass, field

import numpy as np

SEG_COLORS = ["#f2b8c0", "#a9d8ee", "#b9e3b0", "#e8d49b"]       # rose, bleu clair, vert clair, sable


def natural_key(text):
    return [int(t) if t.isdigit() else t.casefold() for t in re.split(r"(\d+)", str(text))]


@dataclass
class Seg:
    key: str            # clé du dataset dans le projet
    dsname: str
    var: str
    top: float          # limite haute utilisée (modifiable)
    bottom: float       # limite basse utilisée (modifiable)
    data_top: float     # étendue réelle des données
    data_bottom: float


@dataclass
class SpliceRow:
    var: str
    used: bool = True
    segs: list = field(default_factory=list)
    bounds: list = field(default_factory=list)       # n-1 frontières entre positions voisines
    out_name: str = ""
    out_unit: str = ""
    manual: bool = False                              # frontières déplacées à la main


def valid_extent(depth, values):
    d, v = np.asarray(depth, float), np.asarray(values, float)
    ok = np.isfinite(d) & np.isfinite(v)
    return (float(d[ok].min()), float(d[ok].max())) if ok.any() else None


def sorted_series(df, col):
    """(profondeurs triées, valeurs) d'une colonne d'un dataset."""
    d, v = df.index.values.astype(float), df[col].values.astype(float)
    ok = np.isfinite(d)
    d, v = d[ok], v[ok]
    o = np.argsort(d, kind="stable")
    return d[o], v[o]


def build_rows(datasets):
    """datasets : [{key, name, df, units}] -> une ligne par variable (union des colonnes)."""
    variables = []
    for ds in datasets:
        for c in ds["df"].columns:
            if str(c) not in variables:
                variables.append(str(c))
    variables.sort(key=natural_key)
    rows = []
    for v in variables:
        segs, unit = [], ""
        for ds in datasets:
            col = next((c for c in ds["df"].columns if str(c) == v), None)
            if col is None:
                continue
            ext = valid_extent(ds["df"].index.values, ds["df"][col].values)
            if ext:
                segs.append(Seg(ds["key"], ds["name"], v, ext[0], ext[1], ext[0], ext[1]))
                unit = unit or ds.get("units", {}).get(v, "")
        if not segs:
            continue
        segs.sort(key=lambda s: (s.data_top, natural_key(s.dsname)))
        row = SpliceRow(v, True, segs, [], f"{v}_Merged", unit)
        auto_bounds(row)
        rows.append(row)
    return rows


def auto_bounds(row):
    """Frontière = milieu du recouvrement (ou de l'espace vide) entre deux positions voisines."""
    b = [(row.segs[i + 1].top + row.segs[i].bottom) / 2.0 for i in range(len(row.segs) - 1)]
    row.bounds = [float(x) for x in np.maximum.accumulate(b)] if b else []
    row.manual = False


def used_interval(row, i):
    """Intervalle réellement retenu pour la position i (None si vide)."""
    n, s = len(row.segs), row.segs[i]
    lo = s.top if i == 0 else max(s.top, row.bounds[i - 1])
    hi = s.bottom if i == n - 1 else min(s.bottom, row.bounds[i])
    return (lo, hi) if hi > lo else None


def make_grid(rows, step):
    los, his = [], []
    for r in rows:
        for i in range(len(r.segs)):
            iv = used_interval(r, i)
            if iv:
                los.append(iv[0]); his.append(iv[1])
    if not los or step <= 0:
        return np.array([])
    lo = min(los)
    n = int(np.floor((max(his) - lo) / step + 1e-9)) + 1
    return lo + step * np.arange(n)


def merge_row(row, grid, seg_data):
    """Courbe fusionnée sur `grid`. seg_data(i) -> (profondeurs triées, valeurs) de la position i."""
    out = np.full(len(grid), np.nan)
    n = len(row.segs)
    for i in range(n):
        iv = used_interval(row, i)
        if not iv:
            continue
        lo, hi = iv
        m = (grid >= lo - 1e-9) & ((grid < hi - 1e-9) if i < n - 1 else (grid <= hi + 1e-9))
        if not m.any():
            continue
        d, v = seg_data(i)
        out[m] = np.interp(grid[m], d, v, left=np.nan, right=np.nan)
    return out


def default_step(datasets):
    steps = []
    for ds in datasets:
        d = np.diff(np.sort(ds["df"].index.values.astype(float)))
        d = d[d > 0]
        if d.size:
            steps.append(float(np.median(d)))
    return min(steps) if steps else 0.5
