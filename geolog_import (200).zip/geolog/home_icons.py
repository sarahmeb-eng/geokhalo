"""Icônes colorées (style Techlog) dessinées en code pour l'onglet Home.

Chaque icône est dessinée dans un repère 32x32 puis rendue en 96x96 px
pour rester nette quel que soit le zoom / l'écran HiDPI.
"""
import math
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import (QIcon, QPixmap, QPainter, QPen, QColor, QPolygonF, QPainterPath,
                           QLinearGradient, QBrush, QFont)

OUT = "#4a4f57"        # contour gris foncé
PAPER = "#ffffff"
BLUE, DBLUE, LBLUE = "#2b79c9", "#1c4f94", "#8cc4f2"
RED, ORANGE, YELLOW = "#d9382b", "#f08c1a", "#f7d33a"
GREEN, DGREEN = "#3aa845", "#237a30"
GRAY, LGRAY, DGRAY = "#a9afb8", "#e4e7eb", "#5b616b"

PX = 96
K = PX / 32.0


def _new():
    pm = QPixmap(PX, PX)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
    p.scale(K, K)
    return pm, p


def _end(p, pm):
    p.end()
    return QIcon(pm)


def _pen(c=OUT, w=1.2):
    return QPen(QColor(c), w, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)


def _grad(x0, y0, x1, y1, *stops):
    g = QLinearGradient(x0, y0, x1, y1)
    for pos, col in stops:
        g.setColorAt(pos, QColor(col))
    return QBrush(g)


def _poly(pts):
    return QPolygonF([QPointF(x, y) for x, y in pts])


def _rect(p, x, y, w, h, fill, line=OUT, r=1.5, lw=1.1):
    p.setPen(_pen(line, lw) if line else Qt.NoPen)
    p.setBrush(fill if isinstance(fill, QBrush) else QColor(fill))
    p.drawRoundedRect(QRectF(x, y, w, h), r, r)


def _page(p, x=7, y=3, w=18, h=25, lines=True, fold=True):
    """Feuille blanche avec coin corné."""
    f = 5 if fold else 0
    path = QPainterPath(QPointF(x, y))
    path.lineTo(x + w - f, y); path.lineTo(x + w, y + f)
    path.lineTo(x + w, y + h); path.lineTo(x, y + h); path.closeSubpath()
    p.setPen(_pen(OUT, 1.1)); p.setBrush(_grad(x, y, x + w, y + h, (0, "#ffffff"), (1, "#dfe3e8")))
    p.drawPath(path)
    if fold:
        p.setBrush(QColor("#c9cfd6"))
        p.drawPolygon(_poly([(x + w - f, y), (x + w - f, y + f), (x + w, y + f)]))
    if lines:
        p.setPen(_pen("#9aa1ab", 1.0))
        for i in range(4):
            yy = y + 9 + i * 3.6
            p.drawLine(QPointF(x + 3, yy), QPointF(x + w - 3, yy))


def _arrow_fill(p, pts, c1, c2):
    p.setPen(_pen(c2, 1.0)); p.setBrush(_grad(0, 0, 0, 32, (0, c1), (1, c2)))
    p.drawPolygon(_poly(pts))


# ---------------------------------------------------------------- Project
def i_save():
    pm, p = _new()
    _rect(p, 4, 4, 24, 24, _grad(0, 4, 0, 28, (0, "#3f8ee0"), (1, DBLUE)), DBLUE, 2.5)
    _rect(p, 9, 4, 14, 9, _grad(0, 4, 0, 13, (0, "#f4f6f8"), (1, "#b9c0c8")), "#7a828c", 1)
    _rect(p, 18, 5.5, 3, 6, DGRAY, None, 0.5)
    _rect(p, 8, 17, 16, 11, PAPER, "#c9d3df", 1.2)
    p.setPen(Qt.NoPen); p.setBrush(QColor(RED)); p.drawEllipse(QPointF(13, 22.5), 3.2, 3.2)
    p.setBrush(QColor("#ffffff")); p.drawEllipse(QPointF(13, 22.5), 1.2, 1.2)
    p.setPen(_pen("#b3bcc8", 1)); p.drawLine(QPointF(18, 21), QPointF(22, 21)); p.drawLine(QPointF(18, 24), QPointF(22, 24))
    return _end(p, pm)


def i_import():
    pm, p = _new()
    _page(p, 9, 3, 19, 25)
    _arrow_fill(p, [(2, 14), (8, 14), (8, 9), (15, 17), (8, 25), (8, 20), (2, 20)], "#58c866", DGREEN)
    return _end(p, pm)


def i_export():
    pm, p = _new()
    _page(p, 4, 3, 19, 25)
    _arrow_fill(p, [(17, 14), (23, 14), (23, 9), (30, 17), (23, 25), (23, 20), (17, 20)], "#ffb34d", "#d9731a")
    return _end(p, pm)


def i_print():
    pm, p = _new()
    _rect(p, 9, 3, 14, 10, PAPER, OUT, 1)
    p.setPen(_pen("#9aa1ab", 1))
    for yy in (6, 8.5, 11):
        p.drawLine(QPointF(11.5, yy), QPointF(20.5, yy))
    _rect(p, 3, 12, 26, 12, _grad(0, 12, 0, 24, (0, "#8f97a3"), (1, "#4f5661")), "#3b4048", 3)
    _rect(p, 8, 20, 16, 9, PAPER, OUT, 1)
    p.setPen(_pen("#9aa1ab", 1))
    p.drawLine(QPointF(10.5, 23.5), QPointF(21.5, 23.5)); p.drawLine(QPointF(10.5, 26), QPointF(18, 26))
    p.setPen(Qt.NoPen); p.setBrush(QColor("#5fe06a")); p.drawEllipse(QPointF(25, 15.5), 1.3, 1.3)
    return _end(p, pm)


# ---------------------------------------------------------------- Techreport
def i_camera():
    pm, p = _new()
    _rect(p, 10, 5, 12, 5, DGRAY, "#2d3138", 1.5)
    _rect(p, 3, 8, 26, 19, _grad(0, 8, 0, 27, (0, "#5a606b"), (1, "#2d3138")), "#23272d", 3.5)
    _rect(p, 5.5, 10.5, 5, 3, "#e8eaee", None, 1)
    p.setPen(_pen("#d8dce2", 2)); p.setBrush(QColor("#20242a")); p.drawEllipse(QPointF(16, 18), 7, 7)
    p.setPen(Qt.NoPen); p.setBrush(_grad(10, 12, 22, 24, (0, "#8fd0ff"), (1, "#1d5fb0")))
    p.drawEllipse(QPointF(16, 18), 4.8, 4.8)
    p.setBrush(QColor(255, 255, 255, 200)); p.drawEllipse(QPointF(14.3, 16.3), 1.5, 1.5)
    return _end(p, pm)


def i_composer():
    pm, p = _new()
    _rect(p, 3, 4, 26, 24, _grad(0, 4, 0, 28, (0, "#4a8fdb"), (1, DBLUE)), DBLUE, 2)
    for (x, y, w, h) in ((6, 7, 9, 8), (17, 7, 9, 8), (6, 17, 9, 8), (17, 17, 9, 8)):
        _rect(p, x, y, w, h, "#f2f6fb", None, 0.8)
    p.setPen(_pen(BLUE, 1))
    for (x, y) in ((8, 10), (19, 10), (8, 20), (19, 20)):
        p.drawLine(QPointF(x, y), QPointF(x + 5, y)); p.drawLine(QPointF(x, y + 2.5), QPointF(x + 4, y + 2.5))
    return _end(p, pm)


def _pencil(p, x, y, s=1.0, color=ORANGE):
    """Crayon incliné dont la pointe est en (x, y)."""
    p.save(); p.translate(x, y); p.rotate(-45); p.scale(s, s)
    _rect(p, 2, -2, 11, 4, color, "#a85a0c", 0.8)
    p.setBrush(QColor("#f3d9b0")); p.setPen(_pen("#a85a0c", 0.8))
    p.drawPolygon(_poly([(2, -2), (2, 2), (-3, 0)]))
    p.setBrush(QColor("#333")); p.setPen(Qt.NoPen); p.drawPolygon(_poly([(-0.5, -0.8), (-0.5, 0.8), (-3, 0)]))
    _rect(p, 13, -2, 2.5, 4, "#e57a7a", "#a85a0c", 0.8)
    p.restore()


def i_header():
    pm, p = _new()
    _page(p, 4, 4, 20, 24, lines=False)
    _rect(p, 7, 8, 14, 4, LBLUE, None, 0.8)
    p.setPen(_pen("#9aa1ab", 1))
    for yy in (16, 19.5, 23):
        p.drawLine(QPointF(7, yy), QPointF(17, yy))
    _pencil(p, 16, 27, 1.15)
    return _end(p, pm)


def i_batch():
    pm, p = _new()
    _rect(p, 9, 2, 17, 11, "#f4f5f7", OUT, 1)
    _rect(p, 6, 5, 17, 11, "#fafafb", OUT, 1)
    _rect(p, 3, 13, 26, 12, _grad(0, 13, 0, 25, (0, "#8f97a3"), (1, "#4f5661")), "#3b4048", 3)
    _rect(p, 8, 21, 16, 8, PAPER, OUT, 1)
    p.setPen(_pen("#9aa1ab", 1)); p.drawLine(QPointF(10, 25), QPointF(22, 25))
    return _end(p, pm)


def i_report():
    pm, p = _new()
    _page(p, 4, 3, 20, 25, lines=False)
    _rect(p, 7, 7, 14, 5, _grad(0, 7, 0, 12, (0, "#4a8fdb"), (1, DBLUE)), None, 0.8)
    p.setPen(_pen("#9aa1ab", 1))
    for yy in (16, 19.5, 23):
        p.drawLine(QPointF(7, yy), QPointF(17, yy))
    p.setPen(_pen("#2d3138", 2.2)); p.drawLine(QPointF(24, 24), QPointF(29, 29))
    p.setPen(_pen("#4b5360", 1.6)); p.setBrush(QColor(200, 230, 255, 200)); p.drawEllipse(QPointF(21, 21), 5, 5)
    return _end(p, pm)


# ---------------------------------------------------------------- Tools
def i_patterns():
    pm, p = _new()
    clip = QPainterPath(); clip.addRoundedRect(QRectF(3, 4, 26, 24), 2, 2)
    p.save(); p.setClipPath(clip)
    cols = ["#f7d33a", "#7a5a1b", "#f08c1a", "#7a5a1b"]
    for i in range(8):
        path = QPainterPath(QPointF(3, 4 + i * 3.2))
        for k in range(1, 14):
            path.lineTo(3 + k * 2, 4 + i * 3.2 + (1.0 if k % 2 else -1.0))
        p.setPen(_pen(cols[i % 4], 2.0)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    p.restore()
    p.setPen(_pen("#5b4410", 1.3)); p.setBrush(Qt.NoBrush); p.drawRoundedRect(QRectF(3, 4, 26, 24), 2, 2)
    return _end(p, pm)


def i_symbols():
    pm, p = _new()
    p.setPen(_pen("#1a1a1a", 1.6)); p.setBrush(QColor("#ffffff")); p.drawEllipse(QPointF(16, 16), 8, 8)
    p.setPen(_pen("#1a1a1a", 2.4))
    p.drawLine(QPointF(16, 2.5), QPointF(16, 29.5)); p.drawLine(QPointF(2.5, 16), QPointF(29.5, 16))
    p.setPen(Qt.NoPen); p.setBrush(QColor("#1a1a1a"))
    for (x, y) in ((16, 2.5), (16, 29.5), (2.5, 16), (29.5, 16)):
        p.drawEllipse(QPointF(x, y), 1.6, 1.6)
    return _end(p, pm)


def i_zones():
    pm, p = _new()
    _rect(p, 5, 3, 22, 26, _grad(0, 3, 0, 29, (0, "#e0301f"), (0.4, "#f08c1a"), (0.7, "#f7d33a"), (1, "#f7e98a")),
          "#5b616b", 1.5)
    p.setPen(Qt.NoPen); p.setBrush(QColor(255, 255, 255, 90)); p.drawRect(QRectF(6, 4, 7, 24))
    _rect(p, 5, 22, 22, 7, _grad(0, 22, 0, 29, (0, "#5aa0e8"), (1, DBLUE)), "#5b616b", 1.5)
    p.setPen(_pen("#ffffff", 1)); p.drawLine(QPointF(5, 14), QPointF(27, 14)); p.drawLine(QPointF(5, 8.5), QPointF(27, 8.5))
    return _end(p, pm)


def i_menus():
    pm, p = _new()
    _page(p, 5, 3, 20, 25, lines=False)
    _rect(p, 8, 7, 14, 3.5, BLUE, None, 0.8)
    for yy, c in ((13.5, "#d9dfe6"), (17.5, "#d9dfe6"), (21.5, "#d9dfe6")):
        _rect(p, 8, yy, 14, 3, c, None, 0.8)
    p.setPen(_pen("#2d3138", 1)); p.drawLine(QPointF(9.5, 15), QPointF(18, 15))
    _pencil(p, 22, 28, 1.0, BLUE)
    return _end(p, pm)


# ---------------------------------------------------------------- View
def i_fullscreen():
    pm, p = _new()
    _rect(p, 5, 6, 22, 20, _grad(0, 6, 0, 26, (0, "#ffffff"), (1, "#e4e7eb")), "#2d3138", 1.5, 1.8)
    p.setPen(_pen("#2d3138", 2.6))
    for (x, y, dx, dy) in ((3, 4, 5, 0), (3, 4, 0, 5), (29, 4, -5, 0), (29, 4, 0, 5),
                           (3, 28, 5, 0), (3, 28, 0, -5), (29, 28, -5, 0), (29, 28, 0, -5)):
        p.drawLine(QPointF(x, y), QPointF(x + dx, y + dy))
    return _end(p, pm)


def i_props():
    pm, p = _new()
    path = QPainterPath(QPointF(4, 8)); path.lineTo(20, 8); path.lineTo(28, 16)
    path.lineTo(20, 24); path.lineTo(4, 24); path.closeSubpath()
    p.setPen(_pen(DBLUE, 1.2)); p.setBrush(_grad(0, 8, 0, 24, (0, "#68aef0"), (1, BLUE))); p.drawPath(path)
    p.setPen(Qt.NoPen); p.setBrush(QColor("#ffffff")); p.drawEllipse(QPointF(13, 16), 5, 5)
    p.setBrush(QColor(DBLUE)); p.drawRect(QRectF(12.2, 15, 1.7, 4.2)); p.drawEllipse(QPointF(13, 13.2), 1, 1)
    return _end(p, pm)


def i_actions():
    pm, p = _new()
    p.setPen(_pen(DGREEN, 1.2)); p.setBrush(_grad(0, 3, 0, 29, (0, "#5fd06b"), (1, DGREEN)))
    p.drawEllipse(QPointF(16, 16), 12, 12)
    p.setPen(_pen("#ffffff", 3.4)); p.setBrush(Qt.NoBrush)
    p.drawPolyline(_poly([(9.5, 16.5), (14, 21), (22.5, 11.5)]))
    return _end(p, pm)


def i_dock():
    pm, p = _new()
    _rect(p, 3, 5, 26, 22, "#f6f7f9", OUT, 2)
    _rect(p, 3, 5, 26, 6, _grad(0, 5, 0, 11, (0, "#6b7380"), (1, "#464c56")), OUT, 2)
    _rect(p, 5, 13, 8, 12, LBLUE, "#5b616b", 0.8)
    p.setPen(_pen("#9aa1ab", 1))
    for yy in (15, 18, 21):
        p.drawLine(QPointF(16, yy), QPointF(26, yy))
    return _end(p, pm)


def i_save_layout():
    pm, p = _new()
    _rect(p, 4, 4, 24, 24, _grad(0, 4, 0, 28, (0, "#3f8ee0"), (1, DBLUE)), DBLUE, 3)
    _rect(p, 9, 4, 14, 9, "#e4e8ee", "#7a828c", 1)
    _rect(p, 8, 17, 16, 11, PAPER, None, 1)
    return _end(p, pm)


def i_reset_layout():
    pm, p = _new()
    p.setPen(_pen(BLUE, 3)); p.setBrush(Qt.NoBrush)
    p.drawArc(QRectF(6, 6, 20, 20), 40 * 16, 270 * 16)
    p.setPen(Qt.NoPen); p.setBrush(QColor(BLUE))
    p.drawPolygon(_poly([(24, 4), (27, 13), (17, 11)]))
    p.setBrush(QColor(GREEN)); p.drawEllipse(QPointF(16, 16), 3, 3)
    return _end(p, pm)


def i_layout_mgr():
    pm, p = _new()
    _rect(p, 4, 4, 24, 24, "#f6f7f9", OUT, 2)
    for (x, y, w, h, c) in ((6, 6, 9, 9, LBLUE), (17, 6, 9, 9, "#b6e3b8"), (6, 17, 9, 9, "#ffd9a0"), (17, 17, 9, 9, "#e0c6f0")):
        _rect(p, x, y, w, h, c, "#7a828c", 0.8)
    return _end(p, pm)


# ---------------------------------------------------------------- Window
def i_dashboard():
    pm, p = _new()
    _rect(p, 3, 4, 26, 24, "#fbfbfc", "#3b4048", 2, 1.4)
    for (x, y, w, h) in ((5, 6, 22, 7), (5, 15, 10, 11), (17, 15, 10, 11)):
        _rect(p, x, y, w, h, _grad(0, y, 0, y + h, (0, "#ffffff"), (1, "#e4e7eb")), "#6b7380", 0.9, 1)
    return _end(p, pm)


def i_tile():
    pm, p = _new()
    _rect(p, 3, 4, 26, 24, "#fbfbfc", "#3b4048", 2, 1.4)
    for (x, y, w, h) in ((5, 6, 10, 9), (17, 6, 10, 9), (5, 17, 10, 9), (17, 17, 10, 9)):
        _rect(p, x, y, w, h, _grad(0, y, 0, y + h, (0, "#ffffff"), (1, "#dde1e6")), "#6b7380", 0.9, 1)
    return _end(p, pm)


def i_cascade():
    pm, p = _new()
    _rect(p, 9, 3, 20, 17, "#f2f4f7", "#3b4048", 2, 1.3)
    _rect(p, 6, 8, 20, 17, "#f8f9fb", "#3b4048", 2, 1.3)
    _rect(p, 3, 13, 20, 16, _grad(0, 13, 0, 29, (0, "#ffffff"), (1, "#dde1e6")), "#3b4048", 2, 1.3)
    _rect(p, 3, 13, 20, 4, "#6b7380", "#3b4048", 2, 1.2)
    return _end(p, pm)


def i_windows():
    pm, p = _new()
    _rect(p, 3, 5, 26, 22, _grad(0, 5, 0, 27, (0, "#ffffff"), (1, "#dde1e6")), "#3b4048", 2, 1.4)
    _rect(p, 3, 5, 26, 5, "#6b7380", "#3b4048", 2, 1.2)
    p.setPen(Qt.NoPen); p.setBrush(QColor("#ffffff"))
    for x in (22, 25):
        p.drawEllipse(QPointF(x, 7.5), 1, 1)
    return _end(p, pm)


# ================================================================ onglets Variable / Depth shift
def _wave(p, cx, y0, y1, amp, col, w=2.0, cycles=1.5, phase=0.0, jitter=0.0):
    """Courbe verticale ondulée (une 'diagraphie') de y0 à y1, centrée en cx."""
    path = QPainterPath()
    n = 48
    for i in range(n + 1):
        t = i / n
        x = cx + amp * math.sin(2 * math.pi * cycles * t + phase) + jitter * math.sin(41 * t + phase)
        y = y0 + (y1 - y0) * t
        if i == 0:
            path.moveTo(x, y)
        else:
            path.lineTo(x, y)
    p.setPen(_pen(col, w)); p.setBrush(Qt.NoBrush); p.drawPath(path)


def i_variable():
    """Variable : S bleu (icône des variables dans le Project browser)."""
    pm, p = _new()
    _wave(p, 16, 3, 29, 7, "#1d6fc4", 3.4, 1.0)
    return _end(p, pm)


def i_processing():
    pm, p = _new()
    _wave(p, 16, 3, 29, 8, DBLUE, 3.6, 1.25, 0.0)
    _wave(p, 16, 3, 29, 8, "#ff5a4a", 1.6, 1.25, 0.0)
    _wave(p, 16, 4, 28, 7, "#2b8be0", 1.4, 1.25, 1.6)
    return _end(p, pm)


def i_smooth():
    pm, p = _new()
    _wave(p, 16, 3, 29, 6, "#9ab7d6", 1.2, 1.5, 0.0, jitter=2.2)
    _wave(p, 16, 3, 29, 6, "#d9382b", 2.8, 1.5, 0.0)
    return _end(p, pm)


def i_clean():
    pm, p = _new()
    _wave(p, 16, 3, 29, 7, "#d9382b", 2.6, 1.25, 0.0)
    p.setPen(_pen("#1d6fc4", 2.2))
    for (x, y) in ((8, 8), (24, 14), (9, 23)):
        p.drawLine(QPointF(x - 2.2, y - 2.2), QPointF(x + 2.2, y + 2.2)); p.drawLine(QPointF(x - 2.2, y + 2.2), QPointF(x + 2.2, y - 2.2))
    return _end(p, pm)


def i_interp():
    pm, p = _new()
    _wave(p, 16, 3, 29, 7, "#d9382b", 2.6, 1.25, 0.6)
    p.setPen(Qt.NoPen); p.setBrush(QColor("#1d6fc4"))
    for i in range(6):
        t = (i + 0.5) / 6
        p.drawEllipse(QPointF(16 + 7 * math.sin(2 * math.pi * 1.25 * t + 0.6), 3 + 26 * t), 1.9, 1.9)
    return _end(p, pm)


def i_deriv():
    pm, p = _new()
    _wave(p, 13, 3, 29, 6, "#1d6fc4", 2.8, 1.25, 0.0)
    _arrow_fill(p, [(21, 22), (28, 22), (28, 18), (31, 25), (28, 32), (28, 28), (21, 28)], "#ff8a7a", "#d9382b")
    return _end(p, pm)


def i_others():
    pm, p = _new()
    p.setPen(_pen(DGRAY, 1.2)); p.setBrush(_grad(0, 4, 0, 28, (0, "#c9ced6"), (1, "#7b828c")))
    path = QPainterPath()
    teeth = 8
    for i in range(teeth * 2):
        a = math.pi * i / teeth
        r = 12.5 if i % 2 == 0 else 9.5
        pt = QPointF(16 + r * math.cos(a), 16 + r * math.sin(a))
        path.moveTo(pt) if i == 0 else path.lineTo(pt)
    path.closeSubpath(); p.drawPath(path)
    p.setBrush(QColor("#ffffff")); p.drawEllipse(QPointF(16, 16), 4, 4)
    return _end(p, pm)


def i_compaction():
    pm, p = _new()
    _rect(p, 4, 14, 24, 4, "#8a919b", None, 1)
    _arrow_fill(p, [(11, 3), (21, 3), (21, 8), (24, 8), (16, 13), (8, 8), (11, 8)], "#ff9d4d", "#d9731a")
    _arrow_fill(p, [(11, 29), (21, 29), (21, 24), (24, 24), (16, 19), (8, 24), (11, 24)], "#ff9d4d", "#d9731a")
    return _end(p, pm)


def i_depthshift():
    """Deux colonnes de diagraphie décalées l'une par rapport à l'autre + flèche verticale."""
    pm, p = _new()
    _rect(p, 3, 5, 9, 22, "#eef2f7", "#6b7380", 1.2, 1)
    _rect(p, 20, 5, 9, 22, "#eef2f7", "#6b7380", 1.2, 1)
    _wave(p, 7.5, 6, 26, 2.3, "#1d6fc4", 1.5, 2.0)
    _wave(p, 24.5, 9, 29, 2.3, "#d9382b", 1.5, 2.0)
    p.setPen(_pen("#2d3138", 1.6))
    p.drawLine(QPointF(16, 6), QPointF(16, 26))
    p.setBrush(QColor("#2d3138")); p.setPen(Qt.NoPen)
    p.drawPolygon(_poly([(16, 2.5), (13, 7.5), (19, 7.5)])); p.drawPolygon(_poly([(16, 29.5), (13, 24.5), (19, 24.5)]))
    return _end(p, pm)


def i_data_editor():
    pm, p = _new()
    _rect(p, 3, 5, 24, 22, "#ffffff", OUT, 2, 1.1)
    _rect(p, 3, 5, 24, 5, "#2b79c9", None, 1.5)
    p.setPen(_pen("#9aa1ab", 1))
    for x in (11, 19):
        p.drawLine(QPointF(x, 10), QPointF(x, 27))
    for y in (15, 20):
        p.drawLine(QPointF(3, y), QPointF(27, y))
    _pencil(p, 21, 29, 1.0, ORANGE)
    return _end(p, pm)


def i_points():
    pm, p = _new()
    _wave(p, 16, 3, 29, 7, "#9aa1ab", 1.2, 1.25)
    p.setPen(_pen("#8a1f16", 1)); p.setBrush(QColor("#d9382b"))
    for i in range(7):
        t = (i + 0.5) / 7
        p.drawEllipse(QPointF(16 + 7 * math.sin(2 * math.pi * 1.25 * t), 3 + 26 * t), 2.2, 2.2)
    return _end(p, pm)


def i_plot_var():
    pm, p = _new()
    _rect(p, 3, 4, 26, 24, "#ffffff", OUT, 2, 1.1)
    for (x, h, c) in ((7, 10, "#f08c1a"), (12, 16, "#2b79c9"), (17, 7, "#d9382b"), (22, 13, "#3aa845")):
        _rect(p, x, 25 - h, 3.6, h, c, None, 0.6)
    return _end(p, pm)


def i_goref():
    pm, p = _new()
    p.setPen(QPen(QColor(OUT), 1.2, Qt.DashLine)); p.setBrush(QColor("#f6f7f9")); p.drawRoundedRect(QRectF(3, 4, 22, 22), 2, 2)
    p.setPen(_pen("#9aa1ab", 1))
    for y in (10, 14, 18):
        p.drawLine(QPointF(7, y), QPointF(19, y))
    p.setPen(_pen("#2d3138", 2.2)); p.drawLine(QPointF(23, 23), QPointF(29, 29))
    p.setPen(_pen("#4b5360", 1.6)); p.setBrush(QColor(200, 230, 255, 220)); p.drawEllipse(QPointF(19, 19), 6, 6)
    return _end(p, pm)


def i_check():
    pm, p = _new()
    p.setPen(_pen(DGREEN, 1.2)); p.setBrush(QColor(0, 0, 0, 0))
    p.setPen(_pen("#2f9a3c", 5.0)); p.drawPolyline(_poly([(5, 17), (12, 25), (27, 6)]))
    p.setPen(_pen("#5fd06b", 2.6)); p.drawPolyline(_poly([(5, 17), (12, 25), (27, 6)]))
    return _end(p, pm)


def i_modvars():
    pm, p = _new()
    _rect(p, 4, 4, 10, 24, "#cfd4db", "#6b7380", 1.5, 1)
    _rect(p, 18, 4, 10, 24, "#e8ebef", "#6b7380", 1.5, 1)
    _wave(p, 9, 5, 27, 2.2, "#6b7380", 1.4, 2.0)
    _wave(p, 23, 5, 27, 2.2, "#8a919b", 1.4, 2.0)
    return _end(p, pm)


def i_select_grid():
    pm, p = _new()
    p.setPen(QPen(QColor("#6b7380"), 1.1, Qt.DashLine)); p.setBrush(Qt.NoBrush)
    for (x, y) in ((3, 4), (17, 4), (3, 17), (17, 17)):
        p.drawRoundedRect(QRectF(x, y, 11, 11), 1.5, 1.5)
    _rect(p, 17, 4, 11, 11, QColor(90, 160, 232, 120), "#2b79c9", 1.5, 1.2)
    return _end(p, pm)


def i_auto():
    pm, p = _new()
    p.setPen(_pen("#1d6fc4", 2.4)); p.drawLine(QPointF(9, 6), QPointF(9, 26))
    p.setBrush(QColor("#1d6fc4")); p.setPen(Qt.NoPen)
    p.drawPolygon(_poly([(9, 2.5), (5, 8), (13, 8)])); p.drawPolygon(_poly([(9, 29.5), (5, 24), (13, 24)]))
    p.setPen(_pen("#2d3138", 1.8)); p.setBrush(QColor("#ffffff")); p.drawEllipse(QPointF(21, 16), 8, 8)
    p.setPen(_pen("#2d3138", 1.6)); p.drawLine(QPointF(21, 16), QPointF(21, 11)); p.drawLine(QPointF(21, 16), QPointF(25, 18))
    return _end(p, pm)


def i_removeall():
    pm, p = _new()
    _page(p, 4, 3, 19, 25, lines=True)
    p.setPen(_pen("#8a1f16", 4.4)); p.drawLine(QPointF(16, 16), QPointF(28, 28)); p.drawLine(QPointF(28, 16), QPointF(16, 28))
    p.setPen(_pen("#e5231b", 2.8)); p.drawLine(QPointF(16, 16), QPointF(28, 28)); p.drawLine(QPointF(28, 16), QPointF(16, 28))
    return _end(p, pm)


def i_recovery():
    pm, p = _new()
    _rect(p, 8, 3, 16, 26, _grad(0, 3, 0, 29, (0, "#2a2a2a"), (0.33, "#2b79c9"), (0.66, "#3aa845"), (1, "#d9382b")),
          "#3b4048", 2, 1.2)
    return _end(p, pm)
