"""Fenêtre principale GeoLog : ruban à onglets, Project browser, zone MDI."""
import os
from pathlib import Path

from PySide6.QtCore import Qt, QSize, QSettings, QUrl
from PySide6.QtGui import (QAction, QKeySequence, QBrush, QColor, QPainter, QFont,
                           QDesktopServices)
from PySide6.QtWidgets import (QMainWindow, QTabWidget, QWidget, QHBoxLayout,
                               QVBoxLayout, QToolButton, QLabel, QFrame, QStyle,
                               QMdiArea, QMdiSubWindow, QDockWidget, QTreeWidget,
                               QTreeWidgetItem, QMessageBox, QFileDialog, QMenu,
                               QInputDialog, QApplication, QAbstractItemView, QHeaderView, QTabBar, QStackedWidget, QLineEdit,
                               QFontComboBox, QComboBox, QGridLayout, QButtonGroup,
                               QTableWidget, QTableWidgetItem, QColorDialog, QSizePolicy)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT

import plots
from project import Project, EXT
from new_project_wizard import NewProjectWizard
import las_info
from import_panel import (ImportPanel, fill_groups, paths_of, filter_tree, _tool,
                          arrow_left_icon, close_icon, trash_icon)

APP = "GeoLog"
TABS = ["Home", "Plot", "Data", "Utility", "Petrophysics", "Geology",
        "Geomechanics", "Drilling", "Reservoir", "Geophysics"]
DEFAULT_FOLDER = str(Path.home() / "GeoLog-Projects")


class MdiArea(QMdiArea):
    """Zone centrale grise avec le logo quand aucune fenêtre n'est ouverte."""
    def paintEvent(self, e):
        super().paintEvent(e)
        if not self.subWindowList():
            p = QPainter(self.viewport())
            f = QFont("Arial Narrow", 60); f.setBold(True)
            p.setFont(f); p.setPen(QColor("#8c8c8c"))
            p.drawText(self.viewport().rect(), Qt.AlignCenter, "GeoLog")
            f2 = QFont("Times New Roman", 18); p.setFont(f2); p.setPen(QColor("#222"))
            r = self.viewport().rect().adjusted(14, 0, 0, -14)
            p.drawText(r, Qt.AlignLeft | Qt.AlignBottom, "Created by\nYour name")


class MainWindow(QMainWindow):
    windows = []          # toutes les fenêtres ouvertes

    def __init__(self, project=None):
        super().__init__()
        self.project = None
        self.dirty = False
        self.wells = {}   # clé -> DataFrame
        self.meta = {}    # chemin LAS -> info (well/dataset, clé, courbes)
        self.settings = QSettings("GeoLogApp", "GeoLog")
        MainWindow.windows.append(self)
        self.resize(1300, 780)

        self.mdi = MdiArea()
        self.mdi.setBackground(QBrush(QColor("#4a4a4a")))
        self.setCentralWidget(self.mdi)
        self._create_actions()
        self._build_ribbon()
        self._build_browser()
        self._build_properties()
        self.set_project(project)
        

    # ------------------------------------------------------------ actions
    def _act(self, text, icon, slot, shortcut=None, checkable=False):
        a = QAction(self.style().standardIcon(icon), text, self)
        if shortcut:
            a.setShortcut(QKeySequence(shortcut))
        a.setCheckable(checkable)
        a.triggered.connect(slot)
        self.addAction(a)
        return a

    def _create_actions(self):
        S = QStyle
        J = "Ctrl+Shift+J, "
        self.a_new = self._act("New...", S.SP_FileIcon, self.new_project, J + "N")
        self.a_open = self._act("Open...", S.SP_DirOpenIcon, self.open_project, J + "O")
        self.a_save = self._act("Save...", S.SP_DialogSaveButton, self.save, J + "S")
        self.a_saveas = self._act("Save as...", S.SP_DialogSaveButton, self.save_as, "Ctrl+Shift+S")
        self.a_close = self._act("Close...", S.SP_DialogCloseButton, self.close_project, J + "C")
        self.a_import = self._act("Import...", S.SP_ArrowDown, self.import_las, J + "I")
        self.a_export = self._act("Export...", S.SP_ArrowUp, self.export_csv, J + "E")
        self.a_print = self._act("Print...", S.SP_FileDialogContentsView, self._todo, "Ctrl+P, P")
        self.a_options = self._act("Options...", S.SP_FileDialogDetailedView, self._todo, J + "P")
        self.a_exit = self._act("Exit", S.SP_DialogCancelButton, self.exit_app, "Alt+F4")
        self.a_info = self._act("Project information", S.SP_MessageBoxInformation, self.project_info)
        self.a_folder = self._act("Open project folder", S.SP_DirIcon, self.open_folder)
        self.a_about = self._act("About GeoLog", S.SP_MessageBoxInformation, self.about)

        self.a_logplot = self._act("Log plot", S.SP_FileDialogListView, self.plot_log)
        self.a_hist = self._act("Histogram", S.SP_FileDialogInfoView, self.plot_hist)
        self.a_cross = self._act("Cross-plot", S.SP_FileDialogDetailedView, self.plot_cross)

        # Home
        self.a_screenshot = self._act("Window\nscreenshot", S.SP_DesktopIcon, self.screenshot)
        self.a_composer = self._act("Composer", S.SP_FileDialogContentsView, self._todo)
        self.a_header = self._act("Header editor", S.SP_FileDialogDetailedView, self._todo)
        self.a_batch = self._act("Batch printing", S.SP_FileDialogContentsView, self._todo)
        self.a_report = self._act("Report\neditor", S.SP_FileDialogDetailedView, self._todo)
        self.a_patterns = self._act("Patterns", S.SP_FileDialogListView, self._todo)
        self.a_symbols = self._act("Symbols", S.SP_DialogApplyButton, self._todo)
        self.a_zones = self._act("Zones", S.SP_FileDialogInfoView, self._todo)
        self.a_menus = self._act("Menus", S.SP_FileDialogDetailedView, self._todo)
        self.a_full = self._act("Full\nscreen", S.SP_TitleBarMaxButton, self.toggle_fullscreen, "F11", True)
        self.a_props = self._act("Properties editor", S.SP_FileDialogInfoView, self.toggle_props, None, True)
        self.a_actions = self._act("Actions widget", S.SP_DialogApplyButton, self._todo, None, True)
        self.a_dash = self._act("Dashboard\nmode", S.SP_FileDialogListView, self._todo, None, True)
        self.a_tile = self._act("Tile", S.SP_TitleBarNormalButton, self.mdi_tile)
        self.a_casc = self._act("Cascade", S.SP_TitleBarShadeButton, self.mdi_cascade)
        self.a_closeall = self._act("Close all windows", S.SP_DialogCloseButton, self.close_subwindows)
        self.a_tileh = self._act("Tile horizontally", S.SP_TitleBarNormalButton, lambda: self.mdi_tile("h"))
        self.a_tilev = self._act("Tile vertically", S.SP_TitleBarNormalButton, lambda: self.mdi_tile("v"))

    # ------------------------------------------------------------- ruban
    STYLE = """
    #ribbon { background:#f4f4f4; }
    #ribbonPage { background:white; border-top:1px solid #c8c8c8; border-bottom:1px solid #c8c8c8; }
    QTabBar::tab { padding:5px 14px; background:#2b2b2b; color:white; }
    QTabBar::tab:selected { background:white; color:black; }
    QTabBar::tab:disabled { color:#777; }
    #projBtn { background:#c8102e; color:white; font-weight:bold; padding:5px 14px; border:none; }
    #projBtn::menu-indicator { image:none; }
    #projBtn:pressed, #projBtn:hover { background:#e0233f; }
    QMenu::item { padding:5px 30px 5px 28px; }
    QMenu::item:selected { background:#cfe3f7; color:black; }
    """

    def _icon_btn(self, a, big):
        b = QToolButton()
        b.setDefaultAction(a)
        b.setAutoRaise(True)
        if big:
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setIconSize(QSize(32, 32)); b.setMinimumWidth(max(62, 9 * max(len(l) for l in a.text().split("\n")) + 16))
        else:
            b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            b.setIconSize(QSize(16, 16))
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        if a.menu():
            b.setPopupMode(QToolButton.InstantPopup)
        return b

    def big(self, *acts):
        return [self._icon_btn(a, True) for a in acts]

    def col(self, *acts):
        w = QWidget(); v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        for a in acts:
            v.addWidget(self._icon_btn(a, False))
        v.addStretch()
        return w

    def _group(self, title, widgets):
        box = QWidget()
        v = QVBoxLayout(box); v.setContentsMargins(6, 2, 6, 0); v.setSpacing(0)
        row = QHBoxLayout(); row.setSpacing(2)
        for w in widgets:
            row.addWidget(w)
        v.addLayout(row)
        lbl = QLabel(title); lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet("color:#666; font-size:11px;")
        v.addWidget(lbl)
        return box

    def _page(self, groups):
        w = QWidget(); w.setObjectName("ribbonPage")
        h = QHBoxLayout(w); h.setContentsMargins(4, 2, 4, 2); h.setSpacing(0)
        for i, g in enumerate(groups):
            if i:
                sep = QFrame(); sep.setFrameShape(QFrame.VLine); sep.setFrameShadow(QFrame.Sunken)
                h.addWidget(sep)
            h.addWidget(g)
        h.addStretch()
        w.setFixedHeight(96)
        return w

    def _make_menu_action(self, text, icon, menu):
        a = QAction(self.style().standardIcon(icon), text, self)
        a.setMenu(menu)
        return a

    def _font_group(self):
        S = QStyle
        w = QWidget(); g = QGridLayout(w); g.setContentsMargins(0, 4, 0, 0); g.setSpacing(3)
        self.font_box = QFontComboBox(); self.font_box.setCurrentFont(QFont("Verdana"))
        self.font_box.setFixedWidth(150)
        self.size_box = QComboBox(); self.size_box.setEditable(True)
        self.size_box.addItems([str(s) for s in (8, 9, 10, 11, 12, 14, 16, 18, 20)])
        self.size_box.setCurrentText("10"); self.size_box.setFixedWidth(55)
        g.addWidget(self.font_box, 0, 0, 1, 4); g.addWidget(self.size_box, 0, 4, 1, 3)
        self.btn_b, self.btn_i, self.btn_u = (QToolButton() for _ in range(3))
        for b, t, st in ((self.btn_b, "B", "font-weight:bold"), (self.btn_i, "I", "font-style:italic"),
                         (self.btn_u, "U", "text-decoration:underline")):
            b.setText(t); b.setCheckable(True); b.setStyleSheet(st); b.setAutoRaise(True)
            b.toggled.connect(self.apply_font)
        grp = QButtonGroup(w); grp.setExclusive(True)
        aligns = []
        for t in ("⯇", "≡", "⯈", "☰"):
            b = QToolButton(); b.setText(t); b.setCheckable(True); b.setAutoRaise(True)
            grp.addButton(b); aligns.append(b)
        aligns[0].setChecked(True)
        self.btn_color = QToolButton(); self.btn_color.setText("A"); self.btn_color.setAutoRaise(True)
        self.btn_color.setStyleSheet("font-weight:bold; text-decoration:underline; color:#c8102e")
        self.btn_color.clicked.connect(self.pick_color)
        for i, b in enumerate([self.btn_b, self.btn_i, self.btn_u] + aligns + [self.btn_color]):
            g.addWidget(b, 1, i)
        self.font_box.currentFontChanged.connect(self.apply_font)
        self.size_box.currentTextChanged.connect(self.apply_font)
        return w

    def _build_ribbon(self):
        # ---- menu du bouton Project (liste de commandes + raccourcis)
        S = QStyle
        m = QMenu(self)
        for a in (self.a_new, self.a_open, self.a_save, self.a_saveas, self.a_close):
            m.addAction(a)
        m.addSeparator()
        self.recent_menu = m.addMenu(self.style().standardIcon(S.SP_FileDialogDetailedView),
                                     "Recent projects")
        self.recent_menu.aboutToShow.connect(self._fill_recent)
        m.addSeparator(); m.addAction(self.a_import); m.addAction(self.a_export)
        m.addSeparator()
        mu = m.addMenu(self.style().standardIcon(S.SP_DirIcon), "Project utilities")
        mu.addAction(self.a_info); mu.addAction(self.a_folder)
        ml = m.addMenu(self.style().standardIcon(S.SP_MessageBoxInformation), "Licensing")
        ml.addAction(self.a_about)
        m.addSeparator(); m.addAction(self.a_print)
        m.addSeparator(); m.addAction(self.a_options)
        m.addSeparator(); m.addAction(self.a_exit)

        btn = QToolButton(); btn.setText("Project"); btn.setObjectName("projBtn")
        btn.setMenu(m); btn.setPopupMode(QToolButton.InstantPopup)

        # ---- menus des boutons du ruban
        dock_menu = QMenu(self)
        tile_menu = QMenu(self)
        for a in (self.a_tile, self.a_tileh, self.a_tilev):
            tile_menu.addAction(a)
        misc_menu = QMenu(self); misc_menu.addAction(self.a_casc); misc_menu.addAction(self.a_closeall)
        self.win_menu = QMenu(self); self.win_menu.aboutToShow.connect(self._fill_windows)
        batch_menu = QMenu(self); batch_menu.addAction("Print all layouts", self._todo)
        self._dock_menu = dock_menu

        self.a_batch.setMenu(batch_menu)
        a_dock = self._make_menu_action("Dock windows", S.SP_TitleBarNormalButton, dock_menu)
        a_tilem = self._make_menu_action("Tile", S.SP_TitleBarNormalButton, tile_menu)
        a_misc = self._make_menu_action("Miscellaneous", S.SP_FileDialogListView, misc_menu)
        a_win = self._make_menu_action("Windows", S.SP_TitleBarNormalButton, self.win_menu)
        a_s1 = self._act("Save layout", S.SP_DialogSaveButton, self._todo)
        a_s2 = self._act("Reset layout", S.SP_BrowserReload, self._todo)
        a_s3 = self._act("Layout manager", S.SP_FileDialogListView, self._todo)

        home = [
            self._group("Project", self.big(self.a_save, self.a_import, self.a_export, self.a_print)),
            self._group("Techreport", self.big(self.a_screenshot) +
                        [self.col(self.a_composer, self.a_header, self.a_batch)] + self.big(self.a_report)),
            self._group("Font", [self._font_group()]),
            self._group("Tools", self.big(self.a_patterns, self.a_symbols, self.a_zones, self.a_menus)),
            self._group("View", self.big(self.a_full) +
                        [self.col(self.a_props, self.a_actions, a_dock), self.col(a_s1, a_s2, a_s3)]),
            self._group("Window", self.big(self.a_dash, a_tilem, a_misc, a_win)),
        ]
        pages = {
            "Home": home,
            "Plot": [self._group("Single well", self.big(self.a_logplot, self.a_hist, self.a_cross))],
            "Data": [self._group("Data", self.big(self.a_import, self.a_export))],
        }

        self.tabbar = QTabBar(); self.tabbar.setExpanding(False); self.tabbar.setDrawBase(False)
        self.stack = QStackedWidget()
        for name in TABS:
            self.tabbar.addTab(name)
            if name in pages:
                self.stack.addWidget(self._page(pages[name]))
            else:
                ph = QLabel(f"   {name}: à venir"); ph.setObjectName("ribbonPage"); ph.setFixedHeight(96)
                self.stack.addWidget(ph)
        self.tabbar.currentChanged.connect(self.stack.setCurrentIndex)

        top = QWidget(); top.setObjectName("ribbon"); top.setStyleSheet(self.STYLE)
        v = QVBoxLayout(top); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        bar = QWidget(); bar.setStyleSheet("background:#2b2b2b;")
        h = QHBoxLayout(bar); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(0)
        h.addWidget(btn); h.addWidget(self.tabbar); h.addStretch()
        v.addWidget(bar); v.addWidget(self.stack)
        dock = QDockWidget(); dock.setTitleBarWidget(QWidget())
        dock.setWidget(top); dock.setFeatures(QDockWidget.NoDockWidgetFeatures)
        self.addDockWidget(Qt.TopDockWidgetArea, dock)

    def _build_browser(self):
        w = QWidget(); h = QHBoxLayout(w); h.setContentsMargins(2, 2, 2, 2); h.setSpacing(2)

        # --- colonne gauche : le projet
        left = QWidget(); v = QVBoxLayout(left); v.setContentsMargins(0, 0, 0, 0)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search")
        self.search.textChanged.connect(lambda t: filter_tree(self.tree, t))
        self.tree = QTreeWidget(); self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Name", "Family"])
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(self._tree_double_click)
        self.btn_trash = _tool(trash_icon(), "Delete selected from project", 20)
        self.btn_trash.clicked.connect(self.delete_selected)
        v.addWidget(self.search); v.addWidget(self.tree)
        v.addWidget(self.btn_trash, 0, Qt.AlignLeft)

        # --- colonne milieu : X (fermer l'import) et flèche (transférer)
        self.mid = QWidget(); m = QVBoxLayout(self.mid); m.setContentsMargins(0, 0, 0, 0)
        bx = _tool(close_icon(), "Close import panel", 20); bx.clicked.connect(self.close_import)
        self.btn_transfer = _tool(arrow_left_icon(), "Transfer to project", 28)
        self.btn_transfer.clicked.connect(self.transfer_import)
        m.addWidget(bx); m.addStretch(); m.addWidget(self.btn_transfer); m.addStretch()

        # --- colonne droite : le container d'import
        self.import_panel = ImportPanel()
        self.import_panel.is_known = lambda p: bool(self.project) and p in {
            os.path.normpath(x) for x in self.project.datasets}

        h.addWidget(left, 1); h.addWidget(self.mid); h.addWidget(self.import_panel, 1)
        self.mid.hide(); self.import_panel.hide()

        self.browser_dock = QDockWidget("Project browser")
        self.browser_dock.setWidget(w)
        self.addDockWidget(Qt.LeftDockWidgetArea, self.browser_dock)
        self._dock_menu.addAction(self.browser_dock.toggleViewAction())

    def _tree_double_click(self, item, _col):
        key = item.data(0, Qt.UserRole)
        if key in self.wells:
            self.plot_log(key)

    def _build_properties(self):
        self.props = QTableWidget(0, 2)
        self.props.horizontalHeader().setVisible(False); self.props.verticalHeader().setVisible(False)
        self.props.horizontalHeader().setStretchLastSection(True)
        self.props_dock = QDockWidget("Properties")
        self.props_dock.setWidget(self.props)
        self.addDockWidget(Qt.RightDockWidgetArea, self.props_dock)
        self.props_dock.hide()
        self.props_dock.visibilityChanged.connect(self.a_props.setChecked)
        self._dock_menu.addAction(self.props_dock.toggleViewAction())

    def _refresh_props(self):
        p = self.project
        rows = [] if not p else [("Name", p.name), ("Folder", p.folder), ("Status", p.status),
                                 ("Mode", p.mode), ("Units", p.units), ("Wells", str(len(self.wells)))]
        self.props.setRowCount(len(rows))
        for i, (k, val) in enumerate(rows):
            self.props.setItem(i, 0, QTableWidgetItem(k)); self.props.setItem(i, 1, QTableWidgetItem(val))

    def _refresh_tree(self):
        self.tree.clear()
        if not self.project:
            return
        root = QTreeWidgetItem([self.project.name])
        self.tree.addTopLevelItem(root)
        ds = None
        for n in ("Datasets", "Layouts", "Cross-plots", "Python scripts"):
            node = QTreeWidgetItem(root, [n])
            if n == "Datasets":
                ds = node
                infos = [self.meta[p] for p in self.project.datasets if p in self.meta]
                fill_groups(node, infos, with_curves=True)
        root.setExpanded(True)
        ds.setExpanded(True)

    # ------------------------------------------- fonctions du ruban Home
    def apply_font(self, *_):
        f = QFont(self.font_box.currentFont())
        try:
            f.setPointSize(int(self.size_box.currentText()))
        except ValueError:
            pass
        f.setBold(self.btn_b.isChecked()); f.setItalic(self.btn_i.isChecked())
        f.setUnderline(self.btn_u.isChecked())
        self.tree.setFont(f)

    def pick_color(self):
        c = QColorDialog.getColor(parent=self)
        if c.isValid():
            self.tree.setStyleSheet(f"QTreeWidget {{ color:{c.name()}; }}")

    def screenshot(self):
        path, _ = QFileDialog.getSaveFileName(self, "Window screenshot", "screenshot.png", "PNG (*.png)")
        if path:
            self.grab().save(path)

    def toggle_fullscreen(self):
        self.showFullScreen() if self.a_full.isChecked() else self.showNormal()

    def toggle_props(self):
        self.props_dock.setVisible(self.a_props.isChecked())

    def _fill_windows(self):
        self.win_menu.clear()
        subs = self.mdi.subWindowList()
        if not subs:
            self.win_menu.addAction("(no window)").setEnabled(False)
        for s in subs:
            self.win_menu.addAction(s.windowTitle(), lambda s=s: self.mdi.setActiveSubWindow(s))

    def close_subwindows(self):
        for s in self.mdi.subWindowList():
            s.close()

    def project_info(self):
        p = self.project
        if p:
            QMessageBox.information(self, APP, f"Name: {p.name}\nFile: {p.path}\nStatus: {p.status}\n"
                                    f"Mode: {p.mode}\nUnits: {p.units}\nDatasets: {len(p.datasets)}")

    def open_folder(self):
        if self.project:
            QDesktopServices.openUrl(QUrl.fromLocalFile(self.project.project_dir))

    def about(self):
        QMessageBox.about(self, APP, "GeoLog 1.0\nGeophysics / petrophysics desktop software.")

    def export_csv(self):
        if not self._need_wells():
            return
        well = self._pick("Well to export", list(self.wells))
        if well:
            path, _ = QFileDialog.getSaveFileName(self, "Export", f"{well}.csv", "CSV (*.csv)")
            if path:
                self.wells[well].to_csv(path)

# ----------------------------------------------------- état du projet
    def set_project(self, project):
        self.project = project
        self.dirty = False
        self.wells = {}
        self.meta = {}
        if project:
            project.datasets = [os.path.normpath(p) for p in project.datasets]
        for sub in self.mdi.subWindowList():
            sub.close()
        if project:
            for p in project.datasets:
                self._load_las(p, register=False)
            self._add_recent(project.path)
        self.stack.setEnabled(project is not None)
        for a in (self.a_save, self.a_saveas, self.a_close, self.a_import, self.a_export,
                  self.a_print, self.a_info, self.a_folder):
            a.setEnabled(project is not None)
        self._refresh_tree()
        self._refresh_props()
        self.update_title()

    def update_title(self):
        if not self.project:
            self.setWindowTitle(f"{APP} - no project")
            return
        p = self.project
        star = " *" if self.dirty else ""
        self.setWindowTitle(f"{APP} 1.0 | Project: {p.name}{star} | Status: {p.status} "
                            f"| Workspace: {APP} workspace")

    def set_dirty(self, d=True):
        self.dirty = d
        self.update_title()

    def maybe_save(self):
        """True si on peut continuer (sauvé ou ignoré), False si annulé."""
        if not (self.project and self.dirty):
            return True
        box = QMessageBox(QMessageBox.Question, APP,
                          f'Do you want to save changes to the project "{self.project.name}"?',
                          parent=self)
        save = box.addButton("Save", QMessageBox.AcceptRole)
        dont = box.addButton("Don't save", QMessageBox.DestructiveRole)
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is save:
            return self.save()
        return box.clickedButton() is dont

    # ------------------------------------------------- actions du menu Project
    def new_project(self):
        wiz = NewProjectWizard(self.settings.value("folder", DEFAULT_FOLDER), self)
        if wiz.exec() != NewProjectWizard.Accepted:
            return
        proj = wiz.project()
        proj.save()
        self.settings.setValue("folder", proj.folder)
        self._show_project(proj)

    def open_project(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open project", self.settings.value("folder", DEFAULT_FOLDER),
            f"GeoLog project (*{EXT})")
        if path:
            self.open_path(path)

    def open_path(self, path):
        try:
            proj = Project.load(path)
        except Exception as e:
            QMessageBox.critical(self, APP, f"Cannot open project:\n{e}")
            return
        self._show_project(proj)

    def _show_project(self, proj):
        """Comme Word/Excel : fenêtre vide -> on l'utilise ; sinon on demande."""
        if self.project is None:
            self.set_project(proj)
            return
        box = QMessageBox(QMessageBox.Question, APP,
                          f'The project "{self.project.name}" is already open.\n\n'
                          "Do you want to replace the current project or open the "
                          f"project into a new {APP}?", parent=self)
        rep = box.addButton("Replace the current", QMessageBox.AcceptRole)
        new = box.addButton(f"Open inside new {APP}", QMessageBox.ActionRole)
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is rep:
            if self.maybe_save():
                self.set_project(proj)
        elif box.clickedButton() is new:
            w = MainWindow(proj)
            w.show()

    def save(self):
        if not self.project:
            return False
        try:
            self.project.save()
        except Exception as e:
            QMessageBox.critical(self, APP, f"Cannot save:\n{e}")
            return False
        self.set_dirty(False)
        self.statusBar().showMessage("Project saved", 3000)
        return True

    def save_as(self):
        if not self.project:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save project as", self.project.default_path(),
                                              f"GeoLog project (*{EXT})")
        if path:
            self.project.name = Path(path).stem
            self.project.folder = str(Path(path).parent.parent)
            self.project.save(path)
            self._add_recent(path)
            self._refresh_tree()
            self.set_dirty(False)

    def close_project(self):
        if self.maybe_save():
            self.set_project(None)

    def exit_app(self):
        for w in list(MainWindow.windows):
            if not w.close():
                break

    def closeEvent(self, e):
        if self.maybe_save():
            MainWindow.windows.remove(self)
            e.accept()
        else:
            e.ignore()

    # ------------------------------------------------------- projets récents
    def _recent(self):
        r = self.settings.value("recent", [])
        return [r] if isinstance(r, str) else list(r or [])

    def _add_recent(self, path):
        if not path:
            return
        r = [p for p in self._recent() if p != path]
        self.settings.setValue("recent", ([path] + r)[:10])

    def _fill_recent(self):
        self.recent_menu.clear()
        items = [p for p in self._recent() if os.path.exists(p)]
        if not items:
            self.recent_menu.addAction("(none)").setEnabled(False)
        for p in items:
            self.recent_menu.addAction(p, lambda p=p: self.open_path(p))

    # ------------------------------------------------------- données LAS
    def import_las(self):
        """Ouvre le container d'import à droite du Project browser."""
        if not self.project:
            return
        self.mid.show(); self.import_panel.show()
        self.browser_dock.setMinimumWidth(720)
        self.resizeDocks([self.browser_dock], [760], Qt.Horizontal)

    def close_import(self):
        self.mid.hide(); self.import_panel.hide()
        self.browser_dock.setMinimumWidth(0)
        self.resizeDocks([self.browser_dock], [260], Qt.Horizontal)

    def transfer_import(self):
        """Flèche : container d'import -> projet."""
        paths = self.import_panel.selected_paths()
        if not paths:
            self.statusBar().showMessage("Select the data to transfer first", 3000)
            return
        ok = []
        for p in paths:
            if self._load_las(p):
                self.project.datasets.append(p)
                ok.append(p)
        n = len(ok)
        self.import_panel.remove_paths(ok)     # les fichiers en erreur restent dans le container
        if n:
            self.set_dirty()
        self._refresh_tree(); self._refresh_props()
        self.statusBar().showMessage(f"{n} dataset(s) transferred to the project", 4000)

    def delete_selected(self):
        paths = {p for it in self.tree.selectedItems() for p in paths_of(it)}
        if not paths:
            return
        if QMessageBox.question(self, APP, f"Remove {len(paths)} dataset(s) from the project?"
                                ) != QMessageBox.Yes:
            return
        for p in paths:
            info = self.meta.pop(p, None)
            if info:
                self.wells.pop(info["key"], None)
            if p in self.project.datasets:
                self.project.datasets.remove(p)
        self.set_dirty(); self._refresh_tree(); self._refresh_props()

    def _load_las(self, path, register=True):
        path = os.path.normpath(path)
        try:
            import lasio
            df = lasio.read(path).df()
        except ImportError:
            QMessageBox.warning(self, APP, "Install lasio:  pip install lasio")
            return False
        except Exception as e:
            QMessageBox.warning(self, APP, f"Cannot read {path}:\n{e}")
            return False
        info = las_info.read_info_safe(path)
        key, n = info["stem"], 2
        while key in self.wells:           # deux fichiers de même nom, dossiers différents
            key = f'{info["stem"]} ({n})'; n += 1
        info["key"] = key
        self.meta[path] = info
        self.wells[key] = df
        return True

    # ------------------------------------------------------------ plots
    def _pick(self, label, items):
        item, ok = QInputDialog.getItem(self, APP, label, items, 0, False)
        return item if ok else None

    def _need_wells(self):
        if not self.wells:
            QMessageBox.information(self, APP, "Import a LAS dataset first.")
            return False
        return True

    def _show_fig(self, fig, title):
        canvas = FigureCanvasQTAgg(fig)
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(NavigationToolbar2QT(canvas, w)); v.addWidget(canvas)
        sub = QMdiSubWindow(); sub.setWidget(w); sub.setWindowTitle(title)
        sub.setAttribute(Qt.WA_DeleteOnClose)
        self.mdi.addSubWindow(sub); sub.resize(700, 500); sub.show()

    def plot_log(self, well=None):
        if not self._need_wells():
            return
        well = well if isinstance(well, str) else self._pick("Well", list(self.wells))
        if well:
            self._show_fig(plots.log_plot(self.wells[well], well), f"Log plot - {well}")

    def plot_hist(self):
        if not self._need_wells():
            return
        well = self._pick("Well", list(self.wells))
        if well:
            c = self._pick("Curve", list(self.wells[well].columns))
            if c:
                self._show_fig(plots.histogram(self.wells[well], c, well), f"Histogram - {c}")

    def plot_cross(self):
        if not self._need_wells():
            return
        well = self._pick("Well", list(self.wells))
        if well:
            cols = list(self.wells[well].columns)
            x = self._pick("X curve", cols)
            y = x and self._pick("Y curve", cols)
            if x and y:
                self._show_fig(plots.cross_plot(self.wells[well], x, y, well), f"Cross-plot {x}/{y}")

    def mdi_tile(self, mode=None):
        subs = self.mdi.subWindowList()
        if mode and subs:
            area = self.mdi.viewport().rect(); n = len(subs)
            for i, s in enumerate(subs):
                s.showNormal()
                if mode == "h":
                    s.setGeometry(0, i * area.height() // n, area.width(), area.height() // n)
                else:
                    s.setGeometry(i * area.width() // n, 0, area.width() // n, area.height())
        else:
            self.mdi.tileSubWindows()
    def mdi_cascade(self): self.mdi.cascadeSubWindows()
    def _todo(self): QMessageBox.information(self, APP, "Not implemented yet.")
