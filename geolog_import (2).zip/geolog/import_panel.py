"""Panneau d'import (le "container" à droite du Project browser) + icônes."""
import os
from PySide6.QtCore import Qt, QSettings, QPointF, QRectF, QSize
from PySide6.QtGui import QIcon, QPixmap, QPainter, QPen, QColor, QPolygonF, QFont
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QComboBox,
                               QToolButton, QTreeWidget, QTreeWidgetItem, QFileDialog,
                               QMessageBox, QAbstractItemView, QMenu, QInputDialog)

import las_info

ROLE_PATHS = Qt.UserRole + 1        # liste des chemins LAS portés par un noeud


# ------------------------------------------------------------------ icônes
def _canvas(size=16):
    pm = QPixmap(size, size); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    return pm, p


def well_icon():
    pm, p = _canvas()
    p.setPen(QPen(QColor("#1f6fb2"), 1.3))
    p.drawLine(8, 1, 3, 15); p.drawLine(8, 1, 13, 15)
    p.drawLine(5, 10, 11, 10); p.drawLine(6, 6, 10, 6)
    p.drawLine(5, 10, 10, 6); p.drawLine(11, 10, 6, 6)
    p.drawLine(2, 15, 14, 15)
    p.end(); return QIcon(pm)


def dataset_icon():
    pm, p = _canvas()
    p.setPen(QPen(QColor("#1aa7d8"), 2.2))
    p.drawEllipse(QRectF(2.5, 2.5, 11, 11))
    p.end(); return QIcon(pm)


def folder_icon():
    pm, p = _canvas(20)
    p.setPen(QPen(QColor("#b8860b"), 1)); p.setBrush(QColor("#f2c230"))
    p.drawRoundedRect(QRectF(1, 4, 7, 4), 1, 1)
    p.drawRoundedRect(QRectF(1, 6, 17, 11), 1.5, 1.5)
    p.end(); return QIcon(pm)


def arrow_left_icon():
    pm, p = _canvas(24)
    p.setPen(Qt.NoPen); p.setBrush(QColor("#1b9bd1"))
    p.drawPolygon(QPolygonF([QPointF(2, 12), QPointF(12, 3), QPointF(12, 8.5), QPointF(22, 8.5),
                             QPointF(22, 15.5), QPointF(12, 15.5), QPointF(12, 21)]))
    p.end(); return QIcon(pm)


def close_icon():
    pm, p = _canvas(20)
    p.setPen(QPen(QColor("#111"), 2.2))
    p.drawLine(4, 4, 16, 16); p.drawLine(16, 4, 4, 16)
    p.end(); return QIcon(pm)


def trash_icon():
    pm, p = _canvas(20)
    p.setPen(QPen(QColor("#1f6fb2"), 1.4)); p.setBrush(QColor("#d6e9f8"))
    p.drawRect(QRectF(5, 7, 10, 10)); p.drawLine(3, 6, 17, 6); p.drawLine(8, 3, 12, 3)
    p.drawLine(8, 9, 8, 15); p.drawLine(12, 9, 12, 15)
    p.end(); return QIcon(pm)


def _tool(icon, tip, size=22):
    b = QToolButton(); b.setIcon(icon); b.setToolTip(tip); b.setAutoRaise(True)
    b.setIconSize(QSize(size, size))
    return b


# --------------------------------------------------- remplissage d'un arbre
def fill_groups(parent, infos, with_curves=False):
    """Crée  Well/Dataset-groupe -> datasets (-> courbes)  sous `parent` (item ou arbre)."""
    wi, di = well_icon(), dataset_icon()
    for kind, group, items in las_info.group_infos(infos):
        if kind == las_info.DATASET:       # dataset indépendant : un seul niveau
            for i in items:
                d = QTreeWidgetItem(parent, [i["name"]])
                d.setToolTip(0, i["stem"])
                d.setIcon(0, di)
                d.setData(0, ROLE_PATHS, [i["path"]])
                d.setData(0, Qt.UserRole, i.get("key", i["stem"]))
                if with_curves:
                    for c in i["curves"]:
                        ci = QTreeWidgetItem(d, [c["mnemonic"], c["family"]])
                        ci.setToolTip(0, f'{c["descr"]} [{c["unit"]}]'.strip())
                        ci.setData(0, ROLE_PATHS, [i["path"]])
            continue
        g = QTreeWidgetItem(parent, [group])
        g.setIcon(0, wi if kind == las_info.WELL else di)
        g.setData(0, ROLE_PATHS, [i["path"] for i in items])
        if kind == las_info.WELL:
            f = g.font(0); f.setBold(True); g.setFont(0, f)
        for i in items:
            leaf = QTreeWidgetItem(g, [i["name"]])
            leaf.setToolTip(0, i["stem"])
            leaf.setData(0, ROLE_PATHS, [i["path"]])
            leaf.setData(0, Qt.UserRole, i.get("key", i["stem"]))
            if with_curves:
                for c in i["curves"]:
                    ci = QTreeWidgetItem(leaf, [c["mnemonic"], c["family"]])
                    ci.setToolTip(0, f'{c["descr"]} [{c["unit"]}]'.strip())
                    ci.setData(0, ROLE_PATHS, [i["path"]])
        g.setExpanded(True)


def paths_of(item):
    """Tous les chemins LAS portés par un item (et ses descendants)."""
    out = list(item.data(0, ROLE_PATHS) or [])
    for k in range(item.childCount()):
        out += paths_of(item.child(k))
    return out


def filter_tree(tree, text):
    t = text.lower()

    def vis(item):
        ok = t in item.text(0).lower()
        for i in range(item.childCount()):
            ok = vis(item.child(i)) or ok
        item.setHidden(bool(t) and not ok)
        return ok
    for i in range(tree.topLevelItemCount()):
        vis(tree.topLevelItem(i))


# ------------------------------------------------------------- le panneau
class ImportPanel(QWidget):
    """Zone d'attente : on choisit des fichiers LAS, ils apparaissent classés
    (Well / Dataset), puis on les transfère vers le Project browser."""

    FILTER = "LAS files (*.la? *.las_* *.LAS);;All files (*)"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.infos = {}                    # path -> info
        self.is_known = lambda path: False # injecté par la fenêtre principale
        self.settings = QSettings("GeoLogApp", "GeoLog")

        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(3)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search")
        self.search.textChanged.connect(lambda t: filter_tree(self.tree, t))

        row = QHBoxLayout(); row.setSpacing(2)
        self.source = QComboBox(); self.source.addItem("File(s) import")
        self.btn_open = _tool(folder_icon(), "Browse LAS files...", 20)
        self.btn_open.clicked.connect(self.browse)
        row.addWidget(self.source, 1); row.addWidget(self.btn_open)

        self.tree = QTreeWidget(); self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Name", "Family"])
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setColumnWidth(0, 170)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._menu)

        v.addWidget(self.search); v.addLayout(row); v.addWidget(self.tree)
        self._rebuild()

    # -- fichiers
    def browse(self):
        start = self.settings.value("import_dir", "")
        paths, _ = QFileDialog.getOpenFileNames(self, "Import data", start, self.FILTER)
        if paths:
            self.settings.setValue("import_dir", os.path.dirname(paths[0]))
            self.add_files(paths)

    def add_files(self, paths):
        bad, dup = [], 0
        for p in paths:
            p = os.path.normpath(p)
            if p in self.infos or self.is_known(p):
                dup += 1
                continue
            try:
                self.infos[p] = las_info.read_info(p)
            except Exception as e:
                bad.append(f"{os.path.basename(p)}: {e}")
        self._rebuild()
        self.tree.selectAll()              # par défaut : tout est prêt à être transféré
        if bad:
            QMessageBox.warning(self, "Import", "Unreadable file(s):\n" + "\n".join(bad))

    def remove_paths(self, paths):
        for p in paths:
            self.infos.pop(p, None)
        self._rebuild()

    def selected_paths(self):
        seen, out = set(), []
        for it in self.tree.selectedItems():
            for p in paths_of(it):
                if p not in seen:
                    seen.add(p); out.append(p)
        return out

    def _menu(self, pos):
        if not self.selected_paths():
            return
        m = QMenu(self)
        m.addAction("Assign to well...", self.assign_well)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    def assign_well(self):
        """Corrige à la main le puits des fichiers sélectionnés."""
        paths = self.selected_paths()
        wells = sorted({i["group"] for i in self.infos.values() if i["kind"] == las_info.WELL})
        name, ok = QInputDialog.getItem(
            self, "Assign to well", "Well name (leave empty = standalone dataset):",
            wells, 0, True)
        if not ok:
            return
        for p in paths:
            las_info.reassign(self.infos[p], name)
        self._rebuild(); self.tree.selectAll()

    def _rebuild(self):
        self.tree.clear()
        root = QTreeWidgetItem(self.tree, ["Datasets"])
        fill_groups(root, list(self.infos.values()), with_curves=True)
        root.setExpanded(True)
        # les datasets sont repliés (courbes visibles via la flèche), comme dans Techlog
        for g in range(root.childCount()):
            for d in range(root.child(g).childCount()):
                root.child(g).child(d).setExpanded(False)
