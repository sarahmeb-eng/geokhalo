"""Fenêtre Properties d'une variable (courbe) du LogView : onglets Limits et Display options."""
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QColor, QDoubleValidator, QFont, QIcon, QPixmap, QPainter
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
                               QComboBox, QCheckBox, QSpinBox, QDoubleSpinBox, QPushButton,
                               QTabWidget, QScrollArea, QListWidget, QColorDialog, QStackedLayout,
                               QFrame)

import logview_icons as ic
from logview_model import (FAMILIES, FAMILY_LIST, UNITS, LINE_STYLES, POINT_TYPES, FILL_MODES)

AXIS_TYPES = ["variable", "user", "family"]


def glyph_icon(text, color, size=16):
    pm = QPixmap(size, size); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen); p.setBrush(QColor(color)); p.drawRoundedRect(0, 0, size, size, 3, 3)
    f = QFont("Arial", 7); f.setBold(True); p.setFont(f); p.setPen(QColor("#fff"))
    p.drawText(pm.rect(), Qt.AlignCenter, text); p.end()
    return QIcon(pm)


def fmt(v):
    return f"{v:.6g}"


class Section(QWidget):
    """En-tête grisé repliable + formulaire (comme les groupes de Techlog)."""

    def __init__(self, title, icon=None, sub=False, expanded=True):
        super().__init__()
        self.title = title
        v = QVBoxLayout(self); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        self.head = QPushButton(icon or QIcon(), f"▾  {title}")
        self.head.setFlat(True)
        self.head.setStyleSheet(
            "QPushButton { text-align:left; padding:3px 6px; border:none; font-weight:bold;"
            f"background:{'#f3f3f3' if sub else '#e4e4e4'}; }}")
        self.body = QWidget()
        self.form = QFormLayout(self.body)
        self.form.setContentsMargins(22 if sub else 10, 4, 6, 4)
        self.form.setLabelAlignment(Qt.AlignLeft)
        self.form.setVerticalSpacing(4)
        v.addWidget(self.head); v.addWidget(self.body)
        self.head.clicked.connect(self.toggle)
        self.set_expanded(expanded)

    def set_expanded(self, on):
        self.body.setVisible(on)
        self.head.setText(("▾  " if on else "▸  ") + self.title)

    def toggle(self):
        self.set_expanded(not self.body.isVisible())


class PropertiesPanel(QWidget):
    """Affiche et modifie le style de la courbe sélectionnée."""

    def __init__(self):
        super().__init__()
        self.curve = None
        self.notify = lambda: None
        self._loading = False
        self.loaders = []                 # fonctions qui rechargent un widget depuis le style
        self.rows = []                    # (label, widget, texte) pour la recherche

        root = QVBoxLayout(self); root.setContentsMargins(4, 4, 4, 4); root.setSpacing(4)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search")
        self.search.textChanged.connect(self._filter)
        root.addWidget(self.search)
        head = QHBoxLayout()
        self.head_icon = QLabel(); self.head_icon.setPixmap(ic.i_curve_var().pixmap(18, 18))
        self.head_label = QLabel("Variable"); f = self.head_label.font(); f.setBold(True); self.head_label.setFont(f)
        head.addWidget(self.head_icon); head.addWidget(self.head_label); head.addStretch()
        root.addLayout(head)

        self.tabs = QTabWidget(); self.tabs.setDocumentMode(True)
        self.tabs.addTab(self._scroll(self._build_limits()), glyph_icon("1", "#1b7fd0"), "Limits")
        self.tabs.addTab(self._scroll(self._build_display()), glyph_icon("◆", "#8e44ad"), "Display options")
        self.tabs.addTab(self._placeholder("Text mode"), glyph_icon("12", "#444"), "Text mode")
        self.tabs.addTab(self._placeholder("Appearance"), glyph_icon("A", "#8e44ad"), "Appearance")
        self.history = QListWidget()
        self.tabs.addTab(self.history, glyph_icon("H", "#c0392b"), "History")
        root.addWidget(self.tabs, 1)
        self.setEnabled(False)

    # ------------------------------------------------------------ utilitaires
    def _scroll(self, w):
        sa = QScrollArea(); sa.setWidgetResizable(True); sa.setFrameShape(QFrame.NoFrame)
        sa.setWidget(w); return sa

    def _placeholder(self, name):
        l = QLabel(f"{name}\n\nNot available yet."); l.setAlignment(Qt.AlignCenter)
        l.setStyleSheet("color:#888;"); return l

    def _page(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(2)
        return w, v

    def _row(self, sec, label, widget):
        lab = QLabel(label)
        sec.form.addRow(lab, widget)
        self.rows.append((lab, widget, label.lower()))
        return widget

    def _single(self, sec, widget, text):
        sec.form.addRow(widget)
        self.rows.append((widget, widget, text.lower()))

    def _filter(self, text):
        t = text.strip().lower()
        for lab, w, txt in self.rows:
            show = not t or t in txt
            lab.setVisible(show); w.setVisible(show)

    @property
    def st(self):
        return self.curve.style

    # ---------------------------------------------------------------- binding
    def _s(self, v):
        return fmt(v) if isinstance(v, float) else str(v)

    def _set(self, attr, value, label=None):
        if self._loading or not self.curve:
            return
        st = self.st
        old = getattr(st, attr)
        if old == value:
            return
        prev_limits = self.curve.effective_limits()
        setattr(st, attr, value)
        self.curve.log(f"{label or attr}: {self._s(old)} → {self._s(value)}")
        self._side_effects(attr, prev_limits)
        self.refresh()
        self.notify()

    def _side_effects(self, attr, prev_limits):
        st, c = self.st, self.curve
        fam = FAMILIES.get(st.family)
        if attr == "axis_type":
            if st.axis_type == "user":
                st.user_lo, st.user_hi = prev_limits
            elif st.axis_type == "family":
                if fam:
                    st.scale, st.unit = fam["scale"], fam["unit"]
                else:
                    st.axis_type = "variable"
                    c.log("family: no family defined for this variable -> back to 'variable'")
        elif attr == "family":
            if st.axis_type == "family" or (st.axis_type == "user" and not st.conserve_user):
                if fam:
                    st.axis_type, st.scale, st.unit = "family", fam["scale"], fam["unit"]
                else:
                    st.axis_type = "variable"
        elif attr == "ref_limit" and st.ref_limit and st.ref_top == st.ref_bottom:
            st.ref_top, st.ref_bottom = float(c.depth[0]), float(c.depth[-1])
        elif attr == "color_mode" and st.color_mode == "variable" and not st.color_var and c.siblings:
            st.color_var = c.siblings[0]

    def _check(self, sec, label, attr, text=None):
        cb = QCheckBox(text or "")
        cb.toggled.connect(lambda v: self._set(attr, bool(v), text or label))
        self.loaders.append(lambda: cb.setChecked(bool(getattr(self.st, attr))))
        if text:
            self._single(sec, cb, text)
        else:
            self._row(sec, label, cb)
        return cb

    def _combo(self, sec, label, attr, items, mapping=None):
        cb = QComboBox()
        cb.addItems(items)
        cb.currentTextChanged.connect(lambda t: self._set(attr, mapping[t] if mapping else t, label))
        inv = {v: k for k, v in mapping.items()} if mapping else None

        def load():
            v = getattr(self.st, attr)
            txt = inv[v] if inv else str(v)
            if cb.findText(txt) < 0:
                cb.addItem(txt)
            cb.setCurrentText(txt)
        self.loaders.append(load)
        self._row(sec, label, cb)
        return cb

    def _spin(self, sec, label, attr, lo, hi, step=1, double=False, decimals=2):
        sp = QDoubleSpinBox() if double else QSpinBox()
        sp.setRange(lo, hi); sp.setSingleStep(step)
        if double:
            sp.setDecimals(decimals)
        sp.setKeyboardTracking(False)
        sp.valueChanged.connect(lambda v: self._set(attr, float(v) if double else int(v), label))
        self.loaders.append(lambda: sp.setValue(getattr(self.st, attr)))
        self._row(sec, label, sp)
        return sp

    def _color(self, sec, label, attr):
        b = QPushButton(); b.setFixedSize(44, 18)

        def paint():
            b.setStyleSheet(f"background:{getattr(self.st, attr)}; border:1px solid #555;")

        def pick():
            col = QColorDialog.getColor(QColor(getattr(self.st, attr)), self, "Select Color")
            if col.isValid():
                self._set(attr, col.name(), label)
        b.clicked.connect(pick)
        self.loaders.append(paint)
        self._row(sec, label, b)
        return b

    def _var_combo(self, sec, label, attr):
        cb = QComboBox()
        cb.currentTextChanged.connect(lambda t: self._set(attr, t, label))

        def load():
            cb.clear(); cb.addItem("")
            cb.addItems(self.curve.siblings)
            cb.setCurrentText(getattr(self.st, attr))
        self.loaders.append(load)
        self._row(sec, label, cb)
        return cb

    def _ro_label(self, sec, label, getter):
        l = QLabel()
        self.loaders.append(lambda: l.setText(getter()))
        self._row(sec, label, l)
        return l

    def _ro_combo(self, sec, label, getter):
        cb = QComboBox(); cb.setEnabled(False)

        def load():
            cb.clear(); cb.addItem(getter())
        self.loaders.append(load)
        self._row(sec, label, cb)
        return cb

    def _limit_edit(self, sec, label, getter, setter):
        ed = QLineEdit(); ed.setValidator(QDoubleValidator())

        def done():
            if self._loading or not self.curve:
                return
            try:
                v = float(ed.text().replace(",", "."))
            except ValueError:
                self.refresh(); return
            setter(v)
        ed.editingFinished.connect(done)
        self.loaders.append(lambda: ed.setText(fmt(getter())))
        self._row(sec, label, ed)
        return ed

    # ----------------------------------------------------------- onglet Limits
    def _build_limits(self):
        w, v = self._page()
        sec0 = Section("", None); sec0.head.hide(); sec0.form.setContentsMargins(10, 6, 6, 4)
        ed = QLineEdit(); ed.editingFinished.connect(lambda: self._set("title", ed.text().strip(), "Title"))
        self.loaders.append(lambda: ed.setText(self.st.title))
        self._row(sec0, "Title", ed)
        self._ro_label(sec0, "Wells", lambda: self.curve.well or "-")
        self._ro_label(sec0, "Dataset", lambda: self.curve.dataset)
        self._ro_label(sec0, "Name", lambda: self.curve.name)
        v.addWidget(sec0)

        vm = Section("Variable management", ic.i_curve_var())
        cb = QComboBox(); cb.addItem("variable"); cb.setEnabled(False); self._row(vm, "Type", cb)
        self._ro_combo(vm, "Main family", lambda: self.st.family)
        self.cb_family = self._combo(vm, "Family", "family", FAMILY_LIST)
        self._ro_combo(vm, "Alias", lambda: self.curve.name)
        le = QLineEdit(); le.setEnabled(False); self.loaders.append(lambda: le.setText(self.curve.name))
        self._row(vm, "Variable", le)
        self._ro_combo(vm, "Variable list", lambda: f"{self.curve.dataset}.{self.curve.name}")
        ch = QCheckBox("Choose latest version"); ch.setEnabled(False); self._single(vm, ch, "Choose latest version")
        v.addWidget(vm)

        row = QWidget(); rl = QHBoxLayout(row); rl.setContentsMargins(10, 2, 6, 2)
        self.cb_conserve = QCheckBox("Conserve the user boundaries")
        self.cb_conserve.toggled.connect(lambda x: self._set("conserve_user", bool(x), "Conserve the user boundaries"))
        self.loaders.append(lambda: self.cb_conserve.setChecked(self.st.conserve_user))
        rl.addWidget(self.cb_conserve); v.addWidget(row)
        self.rows.append((row, row, "conserve the user boundaries"))

        ha = Section("Horizontal axis", glyph_icon("X", "#1f4f8f"))
        self._combo(ha, "Type", "axis_type", AXIS_TYPES)
        self.ed_lo = self._limit_edit(ha, "Lower limit", lambda: self.curve.effective_limits()[0],
                                      lambda x: self._set("user_lo", x, "Lower limit"))
        self.ed_hi = self._limit_edit(ha, "Upper limit", lambda: self.curve.effective_limits()[1],
                                      lambda x: self._set("user_hi", x, "Upper limit"))
        self._combo(ha, "Scale", "scale", ["linear", "log"])
        self._combo(ha, "Unit", "unit", UNITS)
        self._check(ha, "Inverted", "inverted", "Inverted")
        v.addWidget(ha)

        rf = Section("Reference", glyph_icon("I", "#333"))
        self._check(rf, "Limitation", "ref_limit", "Limitation")
        self.ed_top = self._limit_edit(
            rf, "Top", lambda: self.st.ref_top if self.st.ref_limit else float(self.curve.depth[0]),
            lambda x: self._set("ref_top", x, "Top"))
        self.ed_bot = self._limit_edit(
            rf, "Bottom", lambda: self.st.ref_bottom if self.st.ref_limit else float(self.curve.depth[-1]),
            lambda x: self._set("ref_bottom", x, "Bottom"))
        ru = QLabel("M"); self._row(rf, "Reference unit", ru)
        v.addWidget(rf); v.addStretch()
        return w

    # ------------------------------------------------------ onglet Display options
    def _build_display(self):
        w, v = self._page()
        top = Section("", None); top.head.hide()
        self._check(top, "Decimation", "decimation", "Decimation")
        v.addWidget(top)

        cm = Section("Color mode", glyph_icon("■", "#8e44ad"))
        self._combo(cm, "Display type", "color_mode", ["global", "variable"])
        self._color(cm, "Color", "color")
        self.cb_cvar = self._var_combo(cm, "Variable", "color_var")
        self.ck_linecol = self._check(cm, "Line coloration", "line_coloration", "Line coloration")
        v.addWidget(cm)

        pt = Section("Points", glyph_icon("∷", "#d9382b"))
        self.ck_pts = self._check(pt, "Display", "show_points", "Display")
        self.cb_ptype = self._combo(pt, "Type", "point_type", POINT_TYPES)
        self.sp_psize = self._spin(pt, "Size", "point_size", 1, 40)
        sub = Section("Color with variable", None, sub=True, expanded=True)
        self.ck_pvar = self._check(sub, "Activate", "point_var_on", "Activate")
        self.cb_pvar = self._var_combo(sub, "Variable", "point_var")
        pt.form.addRow(sub)
        v.addWidget(pt)

        cn = Section("Connection", glyph_icon("∿", "#1b7fd0"))
        self.ck_line = self._check(cn, "Display", "show_line", "Display line")
        self.cb_lstyle = self._combo(cn, "Line style", "line_style", LINE_STYLES)
        self.sp_thick = self._spin(cn, "Thickness", "thickness", 0.5, 12.0, 0.5, True, 1)
        self.sp_opac = self._spin(cn, "Opacity (%)", "opacity", 5, 100, 5)
        v.addWidget(cn)

        misc = Section("", None); misc.head.hide()
        self._check(misc, "Only fill", "only_fill", "Display only the area-fill")
        self._check(misc, "Optimized", "optimized", "Optimized display")
        v.addWidget(misc)

        vt = Section("Vertical threshold", glyph_icon("A", "#8e44ad"))
        self.ck_vthr = self._check(vt, "Activate", "vthr_on", "Activate")
        self.sp_vthr = self._spin(vt, "Gap (depth unit)", "vthr", 0.01, 100000.0, 0.5, True, 2)
        v.addWidget(vt)

        ptr = Section("Partial track", glyph_icon("|||", "#555"))
        self._spin(ptr, "Start percentage", "part_start", 0, 99)
        self._spin(ptr, "End percentage", "part_end", 1, 100)
        v.addWidget(ptr)

        fl = Section("Area fill", glyph_icon("▤", "#f39c12"))
        self.cb_fmode = self._combo(fl, "Mode", "fill_mode", list(FILL_MODES), FILL_MODES)
        self.sp_base = self._spin(fl, "Baseline value", "base_value", -1e9, 1e9, 1.0, True, 4)
        self.bt_fa = self._color(fl, "Color (below / edge)", "fill_a")
        self.bt_fb = self._color(fl, "Color (above)", "fill_b")
        self.sp_fop = self._spin(fl, "Opacity (%)", "fill_opacity", 5, 100, 5)
        v.addWidget(fl)
        v.addStretch()
        return w

    # ------------------------------------------------------------ rafraîchissement
    def set_curve(self, curve, notify=None):
        self.curve = curve
        self.notify = notify or (lambda: None)
        self.setEnabled(curve is not None)
        if curve is None:
            self.head_label.setText("Variable")
            self.history.clear()
            return
        self.refresh()

    def refresh(self):
        if not self.curve:
            return
        self._loading = True
        try:
            self.head_label.setText(f"Variable ({self.curve.name})")
            for load in self.loaders:
                load()
            self._refresh_enabled()
            self.history.clear()
            self.history.addItems(self.curve.history)
            self.history.scrollToBottom()
        finally:
            self._loading = False

    def _refresh_enabled(self):
        s = self.st
        self.ed_lo.setEnabled(s.axis_type == "user"); self.ed_hi.setEnabled(s.axis_type == "user")
        self.ed_top.setEnabled(s.ref_limit); self.ed_bot.setEnabled(s.ref_limit)
        byvar = s.color_mode == "variable"
        self.cb_cvar.setEnabled(byvar); self.ck_linecol.setEnabled(byvar)
        for wdg in (self.cb_ptype, self.sp_psize, self.ck_pvar):
            wdg.setEnabled(s.show_points)
        self.cb_pvar.setEnabled(s.show_points and s.point_var_on)
        for wdg in (self.cb_lstyle, self.sp_thick, self.sp_opac):
            wdg.setEnabled(s.show_line)
        self.sp_vthr.setEnabled(s.vthr_on)
        on = s.fill_mode != "none"
        self.sp_base.setEnabled(s.fill_mode == "baseline"); self.bt_fb.setEnabled(s.fill_mode == "baseline")
        self.bt_fa.setEnabled(on); self.sp_fop.setEnabled(on)
