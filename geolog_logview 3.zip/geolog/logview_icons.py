"""Icônes dessinées en code (barre d'outils LogView + ruban Plot)."""
import math
from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import (QIcon, QPixmap, QPainter, QPen, QColor, QPolygonF, QPainterPath,
                           QFont, QBrush)

BLUE, DBLUE, RED, ORANGE, GREEN, PURPLE, GRAY = ("#1b7fd0", "#1f4f8f", "#d9382b", "#f39c12",
                                                  "#2ca02c", "#8e44ad", "#666666")


def _new(size=32):
    pm = QPixmap(size, size); pm.fill(Qt.transparent)
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    return pm, p


def _pen(color, w=1.5):
    return QPen(QColor(color), w, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)


def _poly(pts):
    return QPolygonF([QPointF(x, y) for x, y in pts])


def _wiggle(p, x0, y0, y1, amp, color, w=1.4, phase=0.0):
    path = QPainterPath(QPointF(x0, y0))
    n = 14
    for i in range(1, n + 1):
        y = y0 + (y1 - y0) * i / n
        path.lineTo(x0 + amp * math.sin(i * 1.3 + phase), y)
    p.setPen(_pen(color, w)); p.setBrush(Qt.NoBrush); p.drawPath(path)


def _done(p, pm):
    p.end(); return QIcon(pm)


def _box(p, size=32):
    p.setPen(_pen("#333", 1.4)); p.setBrush(QColor("#fdfdfd"))
    p.drawRoundedRect(QRectF(5, 5, size - 10, size - 10), 2, 2)


def _arrow(p, x, y, dx, dy, color="#222", s=3.2):
    p.setPen(_pen(color, 1.4)); p.drawLine(QPointF(x, y), QPointF(x + dx, y + dy))
    ang = math.atan2(dy, dx); tip = QPointF(x + dx, y + dy)
    p.setBrush(QColor(color))
    p.drawPolygon(_poly([(tip.x(), tip.y()),
                         (tip.x() - s * 1.6 * math.cos(ang - .5), tip.y() - s * 1.6 * math.sin(ang - .5)),
                         (tip.x() - s * 1.6 * math.cos(ang + .5), tip.y() - s * 1.6 * math.sin(ang + .5))]))


# ------------------------------------------------------ barre d'outils LogView
def i_select():
    pm, p = _new()
    p.setPen(_pen("#ffffff", 3)); p.setBrush(QColor("#111"))
    pts = [(9, 5), (9, 25), (14, 20), (18, 28), (21, 26.5), (17, 19), (24, 19)]
    p.drawPolygon(_poly(pts)); p.setPen(_pen("#111", 1)); p.drawPolygon(_poly(pts))
    return _done(p, pm)


def i_interactive():
    pm, p = _new()
    pen = _pen(DBLUE, 2.2); pen.setStyle(Qt.DashLine); p.setPen(pen)
    p.drawEllipse(QRectF(6, 6, 20, 20))
    p.setPen(Qt.NoPen); p.setBrush(QColor(DBLUE)); p.drawEllipse(QRectF(13, 13, 6, 6))
    return _done(p, pm)


def i_eraser():
    pm, p = _new()
    p.save(); p.translate(16, 16); p.rotate(-40)
    p.setPen(_pen("#555", 1)); p.setBrush(QColor("#ef7f9a")); p.drawRoundedRect(QRectF(-12, -6, 12, 12), 2, 2)
    p.setBrush(QColor(BLUE)); p.drawRoundedRect(QRectF(0, -6, 12, 12), 2, 2)
    p.restore()
    return _done(p, pm)


def i_zoom():
    pm, p = _new()
    p.setPen(_pen(DBLUE, 3)); p.setBrush(QColor("#d8ecfb")); p.drawEllipse(QRectF(5, 5, 17, 17))
    p.setPen(_pen("#333", 4)); p.drawLine(QPointF(20, 20), QPointF(28, 28))
    p.setPen(_pen(DBLUE, 2)); p.drawLine(QPointF(10, 13.5), QPointF(17, 13.5)); p.drawLine(QPointF(13.5, 10), QPointF(13.5, 17))
    return _done(p, pm)


def i_hand():
    pm, p = _new()
    p.setPen(_pen("#222", 1.2)); p.setBrush(QColor("#fafafa"))
    for i, (x, h) in enumerate([(9, 11), (13, 14), (17, 14), (21, 12)]):
        p.drawRoundedRect(QRectF(x, 5 + (14 - h), 3.6, h + 6), 1.8, 1.8)
    p.drawRoundedRect(QRectF(8, 15, 17, 12), 5, 5)
    p.drawRoundedRect(QRectF(4.5, 14, 4, 10), 2, 2)
    return _done(p, pm)


def i_graph_mod():
    pm, p = _new(); _wiggle(p, 10, 4, 28, 5, DBLUE, 2.0)
    p.setPen(_pen("#555", 1)); p.setBrush(QColor(ORANGE)); p.drawPolygon(_poly([(16, 26), (27, 12), (30, 15), (19, 29)]))
    return _done(p, pm)


def i_annot():
    pm, p = _new()
    p.setPen(_pen("#444", 1.5)); p.setBrush(QColor("#f4f4f4"))
    p.drawRoundedRect(QRectF(5, 6, 22, 16), 4, 4); p.drawPolygon(_poly([(10, 22), (10, 28), (16, 22)]))
    p.setPen(_pen("#777", 1.3)); p.drawLine(9, 12, 23, 12); p.drawLine(9, 16, 20, 16)
    return _done(p, pm)


def i_zones(plus=True):
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, c in enumerate(["#c0392b", "#f39c12", "#f1c40f", "#8e44ad"]):
        p.setBrush(QColor(c)); p.drawRect(QRectF(5, 6 + i * 5, 20, 5))
    if plus:
        p.setBrush(QColor(GREEN)); p.setPen(_pen("#fff", 1)); p.drawEllipse(QRectF(17, 17, 12, 12))
        p.setPen(_pen("#fff", 2)); p.drawLine(23, 19.5, 23, 26.5); p.drawLine(19.5, 23, 26.5, 23)
    return _done(p, pm)


def i_zone_editor():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, c in enumerate(["#c0392b", "#f39c12", "#f1c40f", "#2980b9"]):
        p.setBrush(QColor(c)); p.drawRect(QRectF(5, 6 + i * 5, 20, 5))
    _arrow(p, 27, 8, 0, 6, "#222"); _arrow(p, 27, 26, 0, -6, "#222")
    return _done(p, pm)


def i_markers():
    pm, p = _new(); p.setPen(_pen(BLUE, 2.2))
    for y in (9, 15, 21): p.drawLine(6, y, 22, y)
    p.setPen(_pen("#555", 1)); p.setBrush(QColor(ORANGE)); p.drawPolygon(_poly([(15, 27), (25, 13), (28, 16), (18, 30)]))
    return _done(p, pm)


def i_split():
    pm, p = _new(); _wiggle(p, 7, 5, 27, 3, DBLUE, 2.0, 0.5)
    _arrow(p, 14, 16, 9, 0, RED); _wiggle(p, 25, 5, 27, 3, DBLUE, 2.0, 2.0)
    return _done(p, pm)


def i_depth_inter():
    pm, p = _new(); p.setPen(_pen("#222", 1.6))
    for y in (13, 19, 25): p.drawLine(5, y, 12, y)
    _arrow(p, 20, 15, 0, -9, "#222"); _arrow(p, 20, 17, 0, 10, "#222")
    p.setPen(_pen(DBLUE, 2)); p.drawLine(5, 6, 28, 6)
    return _done(p, pm)


def i_regression():
    pm, p = _new(); p.setPen(_pen(ORANGE, 3))
    p.drawLine(7, 24, 21, 8); p.setBrush(QColor(ORANGE)); p.setPen(Qt.NoPen)
    p.drawEllipse(QRectF(5, 7, 6, 6)); p.drawEllipse(QRectF(17, 19, 6, 6))
    p.setBrush(QColor(GREEN)); p.drawEllipse(QRectF(18, 18, 12, 12))
    p.setPen(_pen("#fff", 2)); p.drawLine(24, 20.5, 24, 27.5); p.drawLine(20.5, 24, 27.5, 24)
    return _done(p, pm)


def i_values():
    pm, p = _new()
    p.setPen(_pen(RED, 2)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(7, 6, 8, 8))
    p.setPen(_pen("#222", 1)); p.setBrush(QColor("#fff7c0")); p.drawRect(QRectF(7, 17, 19, 10))
    f = QFont("Arial", 6); f.setBold(True); p.setFont(f); p.drawText(QRectF(7, 17, 19, 10), Qt.AlignCenter, "1.7")
    return _done(p, pm)


def i_poslines():
    pm, p = _new(); p.setPen(_pen(RED, 2)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(10, 11, 10, 10))
    p.drawLine(3, 16, 10, 16); p.drawLine(20, 16, 29, 16)
    p.setPen(_pen(DBLUE, 1.4)); p.drawLine(15, 3, 15, 11); p.drawLine(15, 21, 15, 29)
    return _done(p, pm)


def i_vadj():
    pm, p = _new(); _box(p); _arrow(p, 16, 15, 0, -6); _arrow(p, 16, 17, 0, 6)
    return _done(p, pm)


def i_hadj():
    pm, p = _new(); _box(p); _arrow(p, 15, 16, -6, 0); _arrow(p, 17, 16, 6, 0)
    return _done(p, pm)


def i_gadj():
    pm, p = _new(); _box(p)
    for dx, dy in ((-5, -5), (5, -5), (-5, 5), (5, 5)):
        _arrow(p, 16 + dx * .35, 16 + dy * .35, dx, dy, "#222", 2.6)
    return _done(p, pm)


def i_auto_h():
    pm, p = _new(); _box(p); _arrow(p, 13, 14, -4, 0); _arrow(p, 15, 14, 4, 0)
    p.setPen(_pen("#222", 1)); p.setBrush(QColor(ORANGE)); p.drawRoundedRect(QRectF(17, 19, 11, 9), 1.5, 1.5)
    p.setBrush(Qt.NoBrush); p.setPen(_pen("#222", 1.5)); p.drawArc(QRectF(19, 14, 7, 9), 0, 180 * 16)
    return _done(p, pm)


def i_one_one():
    pm, p = _new(); _box(p)
    f = QFont("Arial", 8); f.setBold(True); p.setFont(f); p.setPen(QColor("#111"))
    p.drawText(QRectF(5, 5, 22, 22), Qt.AlignCenter, "1:1")
    return _done(p, pm)


# ------------------------------------------------------------- ruban Plot
def i_logview():
    pm, p = _new()
    p.setPen(_pen("#555", 1.3)); p.setBrush(QColor("#fff")); p.drawRoundedRect(QRectF(3, 3, 26, 26), 2, 2)
    for x in (11, 20): p.drawLine(x, 3, x, 29)
    _wiggle(p, 7, 6, 27, 2.3, DBLUE, 1.5); _wiggle(p, 15.5, 6, 27, 2.3, RED, 1.5, 1.0)
    _wiggle(p, 24.5, 6, 27, 2.3, GREEN, 1.5, 2.0)
    return _done(p, pm)


def i_scatter():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for (x, y, c) in [(6, 22, BLUE), (11, 15, RED), (15, 19, ORANGE), (19, 11, GREEN), (24, 7, PURPLE),
                      (9, 9, ORANGE), (22, 21, BLUE), (14, 8, GREEN), (26, 15, RED)]:
        p.setBrush(QColor(c)); p.drawEllipse(QRectF(x - 2.6, y - 2.6, 5.2, 5.2))
    p.setPen(_pen("#555", 1.4)); p.drawLine(3, 4, 3, 28); p.drawLine(3, 28, 29, 28)
    return _done(p, pm)


def i_lineplot():
    pm, p = _new(); _wiggle(p, 8, 5, 27, 4, RED, 2); _wiggle(p, 20, 5, 27, 4, DBLUE, 2, 1.2)
    return _done(p, pm)


def i_hist():
    pm, p = _new(); p.setPen(Qt.NoPen)
    for i, (h, c) in enumerate([(12, "#f39c12"), (22, "#8e44ad"), (17, "#1b7fd0"), (8, "#e74c3c")]):
        p.setBrush(QColor(c)); p.drawRect(QRectF(5 + i * 6.3, 28 - h, 5.2, h))
    return _done(p, pm)


def i_boxplot():
    pm, p = _new(); p.setPen(_pen("#222", 1.3))
    for x, c in ((10, GREEN), (22, BLUE)):
        p.drawLine(x, 4, x, 28); p.setBrush(QColor(c)); p.drawRect(QRectF(x - 5, 11, 10, 10))
        p.drawLine(x - 5, 16, x + 5, 16)
    return _done(p, pm)


def i_star():
    pm, p = _new()
    p.setPen(_pen("#555", 1.4)); p.setBrush(QColor("#f1f1f1")); p.drawEllipse(QRectF(4, 4, 24, 24))
    p.setPen(_pen(BLUE, 1.6))
    for k in range(6):
        a = k * math.pi / 3; p.drawLine(QPointF(16, 16), QPointF(16 + 11 * math.cos(a), 16 + 11 * math.sin(a)))
    return _done(p, pm)


def i_scatter_array():
    pm, p = _new(); p.setPen(_pen("#555", 1))
    for i in range(2):
        for j in range(2):
            p.setBrush(QColor("#fff")); p.drawRect(QRectF(4 + i * 13, 4 + j * 13, 11, 11))
            p.setPen(Qt.NoPen); p.setBrush(QColor([BLUE, RED, GREEN, ORANGE][i * 2 + j]))
            for dx, dy in ((3, 7), (6, 4), (8, 8)): p.drawEllipse(QRectF(4 + i * 13 + dx - 1.2, 4 + j * 13 + dy - 1.2, 2.4, 2.4))
            p.setPen(_pen("#555", 1))
    return _done(p, pm)


def i_more():
    pm, p = _new(); p.setPen(Qt.NoPen)
    cols = [BLUE, RED, GREEN, ORANGE, PURPLE, BLUE, RED, GREEN, ORANGE]
    for k in range(9):
        p.setBrush(QColor(cols[k])); p.drawRect(QRectF(5 + (k % 3) * 8.5, 5 + (k // 3) * 8.5, 6.5, 6.5))
    return _done(p, pm)


def i_cube():
    pm, p = _new(); p.setPen(_pen(DBLUE, 1.6)); p.setBrush(QColor("#e6f1fb"))
    p.drawPolygon(_poly([(16, 4), (28, 10), (28, 22), (16, 28), (4, 22), (4, 10)]))
    p.drawLine(16, 16, 16, 28); p.drawLine(16, 16, 4, 10); p.drawLine(16, 16, 28, 10)
    return _done(p, pm)


def i_curve_var():
    """Petite icône 'variable' (le $ bleu) pour l'en-tête des Properties."""
    pm, p = _new(20)
    path = QPainterPath(QPointF(13, 3)); path.cubicTo(3, 3, 14, 10, 8, 10); path.cubicTo(3, 10, 14, 17, 7, 17)
    p.setPen(_pen(BLUE, 2.4)); p.setBrush(Qt.NoBrush); p.drawPath(path)
    return _done(p, pm)
